// background.js — service worker
// Estratégia v0.4: ZERO injeção persistente. Usa chrome.scripting.executeScript
// pra rodar 1 função no contexto da página a cada 30s, lendo do window.WPP que
// a Wascript já carrega. Não conflita.

const ALARM_NAME = 'branorte-sync'
const ALARM_WORKER = 'branorte-worker'   // processa scheduled+reminders
const PERIOD_MIN = 0.5
const WORKER_PERIOD_MIN = 0.5
const ENDPOINT = 'https://flwbeevtvjiouxdjmziv.supabase.co/functions/v1/wa-sync-labels'
const HUB_ENDPOINT = 'https://flwbeevtvjiouxdjmziv.supabase.co/functions/v1/wa-contact-hub'
const SHARED_SECRET = 'branorte-wa-sync-2026'

console.log('[Branorte SW] background v0.9 started')

// ============================================================================
// Helpers
// ============================================================================
function compararVersao(a, b) {
  const pa = String(a).split('.').map(n => parseInt(n, 10) || 0)
  const pb = String(b).split('.').map(n => parseInt(n, 10) || 0)
  const len = Math.max(pa.length, pb.length)
  for (let i = 0; i < len; i++) {
    const va = pa[i] || 0, vb = pb[i] || 0
    if (va < vb) return -1
    if (va > vb) return 1
  }
  return 0
}

// Verifica chats com cliente aguardando resposta ha >30min em horario comercial
// e dispara desktop notification (1x por chat por dia)
async function checarAguardandoResposta(chats) {
  if (!Array.isArray(chats) || chats.length === 0) return

  // Horario comercial: 8h-18h, seg-sex (Brasilia)
  const agora = new Date()
  const hora = agora.getHours()
  const dow = agora.getDay()  // 0=dom, 6=sab
  const emHorarioComercial = dow >= 1 && dow <= 5 && hora >= 8 && hora < 18
  if (!emHorarioComercial) return

  const limiteMs = 30 * 60 * 1000  // 30min
  const agoraMs = Date.now()
  const hojeStr = agora.toISOString().split('T')[0]

  const stored = await chrome.storage.local.get(['notif_aguardando_dia', 'notif_aguardando_phones'])
  // Reset diario
  const phonesNotificados = stored.notif_aguardando_dia === hojeStr
    ? new Set(stored.notif_aguardando_phones || [])
    : new Set()

  const aNotificar = []
  for (const c of chats) {
    if (c.last_message_from_me !== false) continue  // so notifica se cliente foi o ultimo
    if (!c.last_message_at) continue
    const ts = new Date(c.last_message_at).getTime()
    if (!Number.isFinite(ts)) continue
    if (agoraMs - ts < limiteMs) continue
    if (phonesNotificados.has(c.phone)) continue
    aNotificar.push(c)
  }

  if (aNotificar.length === 0) return

  // Agrupa em uma so notificacao se forem varios
  const totalNovos = aNotificar.length
  if (totalNovos === 1) {
    const c = aNotificar[0]
    const minutos = Math.floor((agoraMs - new Date(c.last_message_at).getTime()) / 60000)
    chrome.notifications.create(`branorte-aguarda-${c.phone}`, {
      type: 'basic',
      iconUrl: chrome.runtime.getURL('branorte-logo-white.png'),
      title: 'Cliente aguardando resposta',
      message: `${c.name || c.phone} ha ${minutos}min: "${(c.last_message_preview || '').slice(0, 60)}"`,
      priority: 2,
    })
  } else {
    chrome.notifications.create(`branorte-aguarda-batch-${Date.now()}`, {
      type: 'basic',
      iconUrl: chrome.runtime.getURL('branorte-logo-white.png'),
      title: `${totalNovos} clientes aguardando resposta`,
      message: aNotificar.slice(0, 3).map(c => c.name || c.phone).join(', ') +
        (totalNovos > 3 ? ` +${totalNovos - 3}` : ''),
      priority: 2,
    })
  }

  // Marca como notificados
  for (const c of aNotificar) phonesNotificados.add(c.phone)
  await chrome.storage.local.set({
    notif_aguardando_dia: hojeStr,
    notif_aguardando_phones: [...phonesNotificados].slice(-500),  // limita memoria
  })
}

// Click na notificacao abre WhatsApp Web
chrome.notifications.onClicked.addListener((notifId) => {
  chrome.tabs.query({ url: 'https://web.whatsapp.com/*' }, (tabs) => {
    if (tabs.length > 0) {
      chrome.tabs.update(tabs[0].id, { active: true })
      chrome.windows.update(tabs[0].windowId, { focused: true })
    } else {
      chrome.tabs.create({ url: 'https://web.whatsapp.com/' })
    }
  })
  chrome.notifications.clear(notifId)
})

function ensureAlarms() {
  chrome.alarms.create(ALARM_NAME, { periodInMinutes: PERIOD_MIN })
  chrome.alarms.create(ALARM_WORKER, { periodInMinutes: WORKER_PERIOD_MIN })
}
chrome.runtime.onInstalled.addListener(ensureAlarms)
chrome.runtime.onStartup.addListener(ensureAlarms)
chrome.alarms.get(ALARM_NAME, (a) => { if (!a) ensureAlarms() })

// Função que roda no contexto da página WA (world: MAIN)
// 1. Se window.WPP existe (Wascript carregou) → usa direto, SEM injetar nada
// 2. Se não existe → injeta wa-js ÚNICA VEZ como fallback, então lê
async function lerEtiquetasNoContextoWA(waJsUrl) {
  // Fallback: injeta wa-js só se ninguém mais carregou
  if (!window.WPP) {
    if (!window.__branorteFallbackInjected) {
      window.__branorteFallbackInjected = true
      await new Promise((resolve) => {
        const s = document.createElement('script')
        s.src = waJsUrl
        s.onload = () => { s.remove(); resolve() }
        s.onerror = () => resolve()
        ;(document.head || document.documentElement).appendChild(s)
      })
      // Aguarda ficar ready (até 30s)
      await new Promise((resolve) => {
        const start = Date.now()
        const check = setInterval(() => {
          if (window.WPP?.isReady) { clearInterval(check); resolve() }
          else if (Date.now() - start > 30000) { clearInterval(check); resolve() }
        }, 500)
      })
    }
  }

  if (!window.WPP) return { ok: false, motivo: 'no_wpp' }
  if (!window.WPP.isReady) return { ok: false, motivo: 'not_ready' }
  if (!window.WPP.labels || !window.WPP.chat) return { ok: false, motivo: 'no_modules' }

  try {
    const labels = await window.WPP.labels.getAllLabels()
    const chats = await window.WPP.chat.list({ count: 5000 })

    const SYSTEM = ['NAO LIDAS', 'FAVORITOS', 'GRUPOS']
    const norm = (s) => s.normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[‎‏]/g, '').toUpperCase().trim()

    const realCount = new Map()
    let semEtiqueta = 0

    // Atividade diária: chats com mensagem hoje + map de lastTs por chat (pra diff)
    const hoje = new Date(); hoje.setHours(0, 0, 0, 0)
    const hojeMs = hoje.getTime()
    let chatsAtivosHoje = 0
    const chatTsMap = {}  // id -> lastTs em ms

    // Mapeamento por chat: pra cada chat COM etiqueta, guarda phone (e164) + label_ids
    // Usado pelo CRM pra mostrar a etiqueta WA na linha do Atendimento (match por telefone)
    const chatsEtiquetas = []  // [{phone, chat_id, label_ids: [str], name}]

    // ===== FIX v0.9: chat.list() base NÃO popula c.labels =====
    // wppconnect aceita opção { withLabels: [id] } como FILTRO em chat.list — chama 1× por label.
    // Fallback: tenta getChatsFromLabel se existir (versões mais novas do wppconnect).
    let chatToLabels = null  // chat_id -> Set<label_id>
    try {
      chatToLabels = new Map()
      for (const label of (labels || [])) {
        if (label?.id === undefined || label?.id === null) continue
        const labelKey = String(label.id)
        let taggedChats = []
        try {
          if (typeof window.WPP?.labels?.getChatsFromLabel === 'function') {
            const r = await window.WPP.labels.getChatsFromLabel(label.id)
            taggedChats = Array.isArray(r) ? r : []
          }
        } catch {}
        if (taggedChats.length === 0) {
          // Fallback principal: filtro do chat.list
          try {
            const r = await window.WPP.chat.list({ count: 5000, withLabels: [label.id] })
            taggedChats = Array.isArray(r) ? r : []
          } catch {}
        }
        realCount.set(labelKey, taggedChats.length)
        for (const tc of taggedChats) {
          const tid = tc?.id?._serialized
            || (typeof tc?.id === 'string' ? tc.id : '')
            || tc?.chatId?._serialized
            || ''
          if (!tid) continue
          if (!chatToLabels.has(tid)) chatToLabels.set(tid, new Set())
          chatToLabels.get(tid).add(labelKey)
        }
      }
    } catch {
      chatToLabels = null
    }

    for (const c of chats) {
      const id = c.id?._serialized ?? ''
      // Fix v0.8: usa chatToLabels (preenchido via getChatsFromLabel) com fallback
      const ls = (chatToLabels && chatToLabels.has(id))
        ? Array.from(chatToLabels.get(id))
        : (c.labels || [])
      const valido = id && !id.endsWith('@broadcast') && !id.startsWith('status@')
      if (ls.length === 0 && valido) semEtiqueta++
      // realCount já foi preenchido no loop de labels (v0.8). Fallback pra contar aqui se não rodou.
      if (!chatToLabels) {
        for (const lid of ls) {
          realCount.set(String(lid), (realCount.get(String(lid)) || 0) + 1)
        }
      }
      if (valido) {
        const tsSec = c.msgs?.last?.()?.t ?? c.t ?? null
        const lastTs = typeof tsSec === 'number' ? tsSec * 1000 : 0
        if (lastTs >= hojeMs) chatsAtivosHoje++
        chatTsMap[id] = lastTs
      }

      // Constrói lista de chats COM etiquetas (pra JOIN no CRM por telefone)
      // Aceita @c.us (legacy) e @lid (WA Business novo) — pra @lid, resolve o phone real
      if (valido && ls.length > 0) {
        let phone = ''
        if (id.endsWith('@c.us')) {
          phone = String(c.id?.user || '').replace(/[^\d]/g, '')
        } else if (id.endsWith('@lid') || id.endsWith('@l.id')) {
          // 1) tenta phoneNumber direto no chat (alguns @lid têm)
          if (c.phoneNumber) {
            phone = String(c.phoneNumber).replace(/[^\d]/g, '')
          }
          // 2) tenta contact.id se for @c.us
          if (!phone && c.contact?.id?._serialized && c.contact.id._serialized.endsWith('@c.us')) {
            phone = String(c.contact.id.user || '').replace(/[^\d]/g, '')
          }
          // 3) tenta WPP.contact.getPhoneFromLid (WA Business)
          if (!phone) {
            try {
              if (window.WPP?.contact?.getPhoneFromLid) {
                const p = await window.WPP.contact.getPhoneFromLid(c.id)
                if (p) phone = String(p).replace(/[^\d]/g, '')
              }
            } catch {}
          }
        }
        // Skip grupos (@g.us) e demais formatos
        if (phone && phone.length >= 10 && phone.length <= 15) {
          // Última msg: timestamp + direção (fromMe = vendedor) + preview
          const lastMsg = c.msgs?.last?.() ?? c.lastMessage ?? null
          let last_message_at = null
          let last_message_from_me = null
          let last_message_preview = ''
          if (lastMsg) {
            const lts = typeof lastMsg.t === 'number' ? lastMsg.t * 1000 : null
            last_message_at = lts ? new Date(lts).toISOString() : null
            last_message_from_me = lastMsg.id?.fromMe === true ? true : (lastMsg.id?.fromMe === false ? false : null)
            const body = typeof lastMsg.body === 'string' ? lastMsg.body : ''
            last_message_preview = body.replace(/[‎‏]/g, '').trim().slice(0, 100)
          }
          chatsEtiquetas.push({
            phone,
            chat_id: id,
            label_ids: ls.map(String),
            name: String(c.name || c.formattedTitle || c.contact?.pushname || '').replace(/[‎‏]/g, '').trim().slice(0, 100),
            last_message_at,
            last_message_from_me,
            last_message_preview,
          })
        }
      }
    }

    const payload = (labels || [])
      .filter(l => l && l.name && !SYSTEM.includes(norm(l.name)))
      .map(l => ({
        id: l.id,
        name: String(l.name).replace(/[‎‏]/g, '').trim(),
        color: l.color,
        count: realCount.get(String(l.id)) ?? 0,
      }))

    return {
      ok: true,
      payload,
      chats_etiquetas: chatsEtiquetas,
      total_chats: chats.length,
      sem_etiqueta: semEtiqueta,
      chats_ativos_hoje: chatsAtivosHoje,
      chat_ts_map: chatTsMap,
      wpp_version: window.WPP.version,
      fallback: !!window.__branorteFallbackInjected,
    }
  } catch (e) {
    return { ok: false, motivo: 'erro', erro: String(e) }
  }
}

async function executarSync() {
  const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' })
  if (!tabs.length) {
    await chrome.storage.local.set({ bg_status: 'sem_wa_aberto', bg_status_at: Date.now() })
    return
  }

  const cfg = await chrome.storage.local.get(['vendedor_nome', 'enabled', 'last_snapshot_key'])
  if (!cfg.vendedor_nome) {
    await chrome.storage.local.set({ bg_status: 'sem_vendedor', bg_status_at: Date.now() })
    return
  }
  if (cfg.enabled === false) return

  const waJsUrl = chrome.runtime.getURL('wppconnect-wa.js')

  for (const tab of tabs) {
    try {
      const [{ result }] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        world: 'MAIN',
        func: lerEtiquetasNoContextoWA,
        args: [waJsUrl],
      })

      // Heartbeat (sempre, mesmo sem mudança)
      await chrome.storage.local.set({
        last_heartbeat_at: Date.now(),
        last_chats_total: result?.total_chats,
        wpp_version: result?.wpp_version,
        mode_realtime: false,
        mode_polling_ms: 30000,
        last_status_at: Date.now(),
        bg_status: result?.ok ? 'ok' : (result?.motivo ?? 'erro'),
        bg_status_at: Date.now(),
      })

      if (!result?.ok) {
        console.log('[Branorte SW]', result?.motivo)
        continue
      }

      // Snapshot pra evitar POST sem mudança
      const key = [...result.payload].sort((a,b) => String(a.id).localeCompare(String(b.id)))
        .map(e => `${e.id}:${e.count}`).join('|')

      // ===== Atividade diária (msgs estimadas) =====
      const hojeStr = new Date().toISOString().slice(0, 10)
      const dailyPrev = (await chrome.storage.local.get(['daily_snapshot'])).daily_snapshot
      let msgsEstimadasAcum = 0
      const novoChatTsMap = result.chat_ts_map || {}

      if (dailyPrev && dailyPrev.dia === hojeStr) {
        msgsEstimadasAcum = dailyPrev.msgs_estimadas || 0
        const prevMap = dailyPrev.chat_ts_map || {}
        // Cada chat onde lastTs aumentou desde último sync = +1 msg estimada
        for (const [id, ts] of Object.entries(novoChatTsMap)) {
          const prevTs = prevMap[id] || 0
          if (ts > prevTs) msgsEstimadasAcum++
        }
      }
      // Salva snapshot atualizado
      await chrome.storage.local.set({
        daily_snapshot: {
          dia: hojeStr,
          chat_ts_map: novoChatTsMap,
          msgs_estimadas: msgsEstimadasAcum,
        },
      })

      // Snapshot key inclui também atividade diária pra forçar push quando muda
      const fullKey = `${key}|${result.chats_ativos_hoje}|${msgsEstimadasAcum}`
      if (fullKey === cfg.last_snapshot_key) {
        console.log('[Branorte SW] sem mudança, skip POST')
        continue
      }

      // ========================================================================
      // Detecta MOVIMENTOS de etiqueta (compara snapshot anterior vs atual)
      // ========================================================================
      const movimentos = []
      try {
        const stored = await chrome.storage.local.get(['chat_labels_snapshot'])
        const snapshotAnterior = stored.chat_labels_snapshot || {}  // { phone: [label_ids canonicos ordenados] }

        // Mapa id_label -> nome canonico (resolve typos e normaliza)
        const labelIdToCanon = {}
        const ALIASES = {
          'FALLOW UP': 'FOLLOW UP', 'FALLOWUP': 'FOLLOW UP', 'FOLLOWUP': 'FOLLOW UP',
          'COMPROU DO COMCORRENTE': 'COMPROU DO CONCORRENTE',
          'PROSPECCOES': 'PROSPECCAO', 'NOVOS LEADS': 'NOVO LEAD',
          'LEAD NOVO': 'NOVO LEAD', 'VENDIDOS': 'VENDIDO', 'RESOLVIDOS': 'RESOLVIDO',
        }
        for (const lbl of result.payload) {
          const norm = String(lbl.name || '').normalize('NFKD').replace(/[̀-ͯ]/g, '').toUpperCase().trim()
          labelIdToCanon[String(lbl.id)] = ALIASES[norm] ?? norm
        }

        // Snapshot atual em formato comparavel: phone -> [canonicos ordenados]
        const snapshotAtual = {}
        for (const c of (result.chats_etiquetas || [])) {
          const canons = (c.label_ids || [])
            .map(id => labelIdToCanon[String(id)])
            .filter(Boolean)
            .sort()
          snapshotAtual[c.phone] = { canons, chat_id: c.chat_id }
        }

        // Compara: pra cada phone, se conjunto mudou, gera 1 movimento por mudanca
        const detectadoEm = new Date().toISOString()
        for (const [phone, atual] of Object.entries(snapshotAtual)) {
          const antesArr = (snapshotAnterior[phone] || []).slice().sort()
          const depoisArr = atual.canons
          if (JSON.stringify(antesArr) === JSON.stringify(depoisArr)) continue
          const antesSet = new Set(antesArr)
          const depoisSet = new Set(depoisArr)
          // Adicionadas (etiqueta_de = null, etiqueta_para = nova)
          for (const novo of depoisArr) {
            if (!antesSet.has(novo)) {
              movimentos.push({
                phone, chat_id: atual.chat_id,
                etiqueta_de: antesArr.length > 0 ? antesArr[0] : null,
                etiqueta_para: novo,
                detectado_em: detectadoEm,
              })
            }
          }
          // Removidas (etiqueta_de = antiga, etiqueta_para = null se nao houver outra)
          for (const antigo of antesArr) {
            if (!depoisSet.has(antigo)) {
              const replacement = depoisArr.length > 0 ? depoisArr[0] : null
              // Se nao foi capturado como "adicionada" acima, registra como saida
              const jaCapturado = movimentos.some(m =>
                m.phone === phone && m.etiqueta_de === antigo && m.etiqueta_para === replacement
              )
              if (!jaCapturado) {
                movimentos.push({
                  phone, chat_id: atual.chat_id,
                  etiqueta_de: antigo,
                  etiqueta_para: replacement,
                  detectado_em: detectadoEm,
                })
              }
            }
          }
        }

        // Salva snapshot atualizado pra proxima comparacao
        const novoSnapshot = {}
        for (const [phone, info] of Object.entries(snapshotAtual)) {
          novoSnapshot[phone] = info.canons
        }
        await chrome.storage.local.set({ chat_labels_snapshot: novoSnapshot })

        if (movimentos.length > 0) {
          console.log('[Branorte SW] detectados', movimentos.length, 'movimentos de etiqueta')
        }
      } catch (e) {
        console.warn('[Branorte SW] erro detectando movimentos:', e.message)
      }

      // ========================================================================
      // Notificacoes: cliente aguardando resposta ha >30min em horario comercial
      // ========================================================================
      try {
        await checarAguardandoResposta(result.chats_etiquetas || [])
      } catch (e) {
        console.warn('[Branorte SW] erro notif aguardando:', e.message)
      }

      // Skip se WPP claramente ainda não hidratou (0 etiquetas + 0 chats = não pronto)
      if (result.payload.length === 0 && (result.total_chats ?? 0) === 0) {
        console.log('[Branorte SW] WPP sem dados (0 labels, 0 chats), skip POST até próximo ciclo')
        continue
      }

      // Envia pro backend
      try {
        const r = await fetch(ENDPOINT, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${SHARED_SECRET}`,
          },
          body: JSON.stringify({
            vendedor_nome: cfg.vendedor_nome.toUpperCase(),
            etiquetas: result.payload,
            chats_etiquetas: result.chats_etiquetas || [],
            movimentos,
            total_chats: result.total_chats,
            sem_etiqueta: result.sem_etiqueta,
            dia: hojeStr,
            chats_ativos_hoje: result.chats_ativos_hoje ?? 0,
            msgs_estimadas_hoje: msgsEstimadasAcum,
            client_version: chrome.runtime.getManifest().version,
            ts: new Date().toISOString(),
          }),
        })
        if (r.ok) {
          const respJson = await r.json().catch(() => ({}))
          const sortedDetail = [...result.payload]
            .map(e => ({ name: e.name, count: e.count || 0 }))
            .sort((a, b) => b.count - a.count)

          // Auto-update: compara versao atual com latest_version retornada pelo servidor
          const versaoAtual = chrome.runtime.getManifest().version
          const latestVersion = respJson.latest_version || versaoAtual
          const latestDownload = respJson.latest_download || ''
          const updateDisponivel = compararVersao(versaoAtual, latestVersion) < 0

          await chrome.storage.local.set({
            last_sync_at: Date.now(),
            last_count: result.payload.length,
            last_total_contatos: result.payload.reduce((s, e) => s + (e.count || 0), 0),
            last_etiquetas: sortedDetail,
            last_sem_etiqueta: result.sem_etiqueta,
            last_total_chats: result.total_chats,
            last_chats_ativos_hoje: result.chats_ativos_hoje ?? 0,
            last_msgs_estimadas_hoje: msgsEstimadasAcum,
            last_snapshot_key: fullKey,
            last_movimentos_count: movimentos.length,
            update_disponivel: updateDisponivel,
            update_versao: latestVersion,
            update_download: latestDownload,
            update_versao_atual: versaoAtual,
            last_error: null,
          })
          console.log('[Branorte SW] sync OK', result.payload.length, 'labels',
            movimentos.length > 0 ? `+${movimentos.length} movimentos` : '',
            updateDisponivel ? `[update ${latestVersion} disponivel]` : '')
        } else {
          const t = await r.text()
          await chrome.storage.local.set({ last_error: `${r.status} ${t.slice(0,80)}`, last_error_at: Date.now() })
          console.error('[Branorte SW] backend rejeitou', r.status, t)
        }
      } catch (e) {
        await chrome.storage.local.set({ last_error: String(e), last_error_at: Date.now() })
        console.error('[Branorte SW] erro fetch', e)
      }
      break // só usa a primeira aba que funcionou
    } catch (e) {
      console.log('[Branorte SW] tab', tab.id, 'erro executeScript:', e.message)
    }
  }
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === ALARM_NAME) {
    await executarSync()
  } else if (alarm.name === ALARM_WORKER) {
    await processarAgendamentos()
    await processarLembretes()
  }
})

// =====================================================================
// WORKER: processa mensagens agendadas que já vieram a hora
// =====================================================================
async function processarAgendamentos() {
  const cfg = await chrome.storage.local.get(['vendedor_nome'])
  if (!cfg.vendedor_nome) return
  try {
    // Busca pendentes do vendedor
    const r = await fetch(`${HUB_ENDPOINT}/scheduled?vendedor=${encodeURIComponent(cfg.vendedor_nome)}&status=pending`, {
      headers: { 'Authorization': 'Bearer ' + SHARED_SECRET },
    })
    if (!r.ok) return
    const j = await r.json().catch(() => ({}))
    const items = Array.isArray(j.items) ? j.items : []
    const agora = Date.now()
    const devidos = items.filter(m => new Date(m.scheduled_at).getTime() <= agora)
    if (devidos.length === 0) return

    // Verifica WhatsApp aberto
    const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' })
    if (!tabs.length) {
      console.log('[Branorte SW] worker: WhatsApp não aberto, pulando', devidos.length, 'envios')
      return
    }

    for (const msg of devidos) {
      console.log('[Branorte SW] worker: enviando agendada', msg.id, '->', msg.contato_nome)
      let result
      try {
        const PLACEHOLDER_RE = /^(🖼️ Imagem|🎥 Vídeo|🎵 Áudio|📎 Arquivo|📎 Mídia) · /
        const caption = PLACEHOLDER_RE.test(msg.body || '') ? '' : (msg.body || '')

        // Prioridade 1: media_url do Supabase Storage
        if (msg.media_url) {
          console.log('[Branorte SW] baixando do bucket:', msg.media_url)
          const resp = await fetch(msg.media_url)
          if (!resp.ok) throw new Error('download HTTP ' + resp.status)
          const blob = await resp.blob()
          const dataUrl = await new Promise((res, rej) => {
            const fr = new FileReader()
            fr.onload = () => res(fr.result)
            fr.onerror = () => rej(fr.error)
            fr.readAsDataURL(blob)
          })
          result = await enviarMidia(msg.chat_id, dataUrl, msg.media_filename || 'arquivo', caption, msg.media_type || 'document')
        } else {
          // Fallback: chrome.storage.local legado
          const k = 'sched_media_' + msg.id
          const stored = await chrome.storage.local.get(k)
          const media = stored[k]
          if (media?.dataUrl) {
            result = await enviarMidia(msg.chat_id, media.dataUrl, media.filename, caption, media.mediaType)
            if (result?.ok) await chrome.storage.local.remove(k).catch(() => {})
          } else {
            result = await enviarTexto(msg.chat_id, msg.body)
          }
        }
      } catch (e) {
        result = { ok: false, erro: String(e).slice(0, 200) }
      }
      const novoStatus = result?.ok ? 'sent' : 'failed'
      const patch = { status: novoStatus }
      if (result?.ok) patch.sent_at = new Date().toISOString()
      else patch.error = String(result?.erro || 'erro').slice(0, 200)
      await fetch(`${HUB_ENDPOINT}/scheduled?id=${msg.id}`, {
        method: 'PATCH',
        headers: { 'Authorization': 'Bearer ' + SHARED_SECRET, 'Content-Type': 'application/json' },
        body: JSON.stringify(patch),
      }).catch(() => {})
      // Notificação
      if (result?.ok) {
        try {
          chrome.notifications.create(`sched-${msg.id}`, {
            type: 'basic',
            iconUrl: 'branorte-logo-white.png',
            title: '✅ Mensagem agendada enviada',
            message: `Pra ${msg.contato_nome || msg.contato_numero || 'contato'}: ${(msg.body || '').slice(0, 80)}`,
          })
        } catch {}
      }
    }
  } catch (e) {
    console.error('[Branorte SW] worker scheduled erro:', e)
  }
}

// =====================================================================
// WORKER: processa lembretes que já chegaram a hora
// =====================================================================
async function processarLembretes() {
  const cfg = await chrome.storage.local.get(['vendedor_nome', 'reminders_notified'])
  if (!cfg.vendedor_nome) return
  try {
    const r = await fetch(`${HUB_ENDPOINT}/reminders?vendedor=${encodeURIComponent(cfg.vendedor_nome)}&status=pending`, {
      headers: { 'Authorization': 'Bearer ' + SHARED_SECRET },
    })
    if (!r.ok) return
    const j = await r.json().catch(() => ({}))
    const items = Array.isArray(j.items) ? j.items : []
    const agora = Date.now()
    const devidos = items.filter(rem => new Date(rem.remind_at).getTime() <= agora)
    if (devidos.length === 0) return

    const jaNotif = new Set(cfg.reminders_notified || [])

    // Pega o próprio ID do WhatsApp (do vendedor logado) — só uma vez
    let meuId = null
    try { meuId = await obterMeuWhatsId() } catch (_) {}

    for (const rem of devidos) {
      if (jaNotif.has(rem.id)) continue  // já notificou nessa sessão
      try {
        // 1) Notificação Chrome (visual)
        chrome.notifications.create(`rem-${rem.id}`, {
          type: 'basic',
          iconUrl: 'branorte-logo-white.png',
          title: '🔔 ' + (rem.title || 'Lembrete'),
          message: (rem.body || '') + (rem.contato_nome ? `\n👤 ${rem.contato_nome}` : ''),
          requireInteraction: true,
        })
        jaNotif.add(rem.id)

        // 2) Envia mensagem pro PRÓPRIO WhatsApp (vai aparecer no celular)
        // Só se notify_self for true ou indefinido (legado = default true)
        const enviarParaMim = (rem.notify_self !== false)
        if (meuId && enviarParaMim) {
          const linhas = []
          linhas.push('🔔 *LEMBRETE BRANORTE*')
          linhas.push('━━━━━━━━━━━━━━━━')
          linhas.push(`*${rem.title || ''}*`)
          if (rem.body) linhas.push(rem.body)
          if (rem.contato_nome || rem.contato_numero) {
            linhas.push('')
            linhas.push(`👤 ${rem.contato_nome || ''}`)
            if (rem.contato_numero) {
              linhas.push(`📞 +${rem.contato_numero}`)
              linhas.push(`💬 https://wa.me/${rem.contato_numero}`)
            }
          }
          linhas.push('')
          linhas.push(`⏰ ${new Date(rem.remind_at).toLocaleString('pt-BR')}`)
          const texto = linhas.join('\n')
          enviarTexto(meuId, texto).then((r) => {
            if (!r?.ok) console.warn('[Branorte SW] auto-msg falhou:', r?.erro)
          }).catch(() => {})
        }
      } catch (e) {
        console.error('[Branorte SW] notif erro:', e)
      }
    }
    await chrome.storage.local.set({ reminders_notified: [...jaNotif].slice(-200) })
  } catch (e) {
    console.error('[Branorte SW] worker reminders erro:', e)
  }
}

// Click na notificação → abre o WhatsApp
chrome.notifications.onClicked.addListener(async (notifId) => {
  try {
    const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' })
    if (tabs.length) {
      await chrome.tabs.update(tabs[0].id, { active: true })
      await chrome.windows.update(tabs[0].windowId, { focused: true })
    } else {
      await chrome.tabs.create({ url: 'https://web.whatsapp.com/' })
    }
    chrome.notifications.clear(notifId)
  } catch {}
})

// Função MAIN-world que devolve TODOS chats + labels + última msg pra Kanban
async function buscarKanbanCompletoNoContextoWA(waJsUrl) {
  if (!window.WPP) {
    if (!window.__branorteFallbackInjected) {
      window.__branorteFallbackInjected = true
      await new Promise(r => {
        const s = document.createElement('script')
        s.src = waJsUrl
        s.onload = () => { s.remove(); r() }
        s.onerror = () => r()
        ;(document.head || document.documentElement).appendChild(s)
      })
      await new Promise(r => {
        const t = setInterval(() => { if (window.WPP?.isReady) { clearInterval(t); r() } }, 500)
        setTimeout(() => { clearInterval(t); r() }, 30000)
      })
    }
  }
  if (!window.WPP?.isReady) return { ok: false, motivo: 'not_ready' }

  try {
    const labels = await window.WPP.labels.getAllLabels()
    const chats = await window.WPP.chat.list({ count: 5000 })
    const SYSTEM = ['NAO LIDAS', 'FAVORITOS', 'GRUPOS']
    const norm = (s) => s.normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[‎‏]/g, '').toUpperCase().trim()

    const labelsLimpos = (labels || [])
      .filter(l => l && l.name && !SYSTEM.includes(norm(l.name)))
      .map(l => ({
        id: String(l.id),
        name: String(l.name).replace(/[‎‏]/g, '').trim(),
        color: l.color,
        hex: l.hexColor,
      }))

    // Helper: tenta resolver LID → número real via mapeamentos internos do Store
    const Store = window.Store ?? window.WPP?.whatsapp?.Store
    function resolverNumeroLid(c) {
      try {
        // 1) c.contact.id pode ser @c.us mesmo quando chat é @lid
        if (c.contact?.id?._serialized?.endsWith?.('@c.us')) {
          return c.contact.id.user
        }
        // 2) c.contact.phoneNumber (campo direto em alguns wppconnect)
        if (c.contact?.phoneNumber) {
          return String(c.contact.phoneNumber).replace(/[^\d]/g, '')
        }
        // 3) Store.LidUtils.getPhoneNumber (mapeamento oficial do WhatsApp)
        const lidUtils = Store?.LidUtils ?? Store?.WidFactory
        if (lidUtils?.getPhoneNumber && c.id?._serialized) {
          try {
            const p = lidUtils.getPhoneNumber(c.id._serialized)
            if (p) return String(p).replace(/[^\d]/g, '')
          } catch {}
        }
        // 4) Pega do nome ou do título se tem dígitos
        const txt = c.name || c.formattedTitle || c.contact?.pushname || ''
        const m = String(txt).match(/(\+?\d{10,15})/)
        if (m) return m[1].replace(/[^\d]/g, '')
      } catch {}
      return ''
    }

    const chatsLimpos = (chats || [])
      .filter(c => {
        const id = c.id?._serialized ?? ''
        return id && !id.endsWith('@broadcast') && !id.startsWith('status@')
      })
      .map(c => {
        const id = c.id?._serialized ?? ''
        const last = c.msgs?.last?.() ?? c.lastMessage ?? null
        const tsSec = last?.t ?? c.t ?? null
        const isLid = id.endsWith('@lid')
        const isGroup = id.endsWith('@g.us')
        // Número: se @c.us pega user direto; se @lid tenta resolver
        let numero = c.id?.user ?? ''
        if (isLid || !numero || numero === id) {
          numero = resolverNumeroLid(c) || numero
        }
        // Se ainda não tem número, e o @c.us tem só dígitos, usa
        if (!numero && id.endsWith('@c.us')) {
          numero = id.split('@')[0]
        }
        return {
          id,
          isGroup,
          isLid,
          name: c.name ?? c.formattedTitle ?? c.contact?.name ?? c.contact?.pushname ?? c.contact?.shortName ?? '',
          pushname: c.contact?.pushname ?? '',
          formattedTitle: c.formattedTitle ?? '',
          labels: (c.labels || []).map(String),
          unreadCount: c.unreadCount ?? 0,
          lastTs: typeof tsSec === 'number' ? tsSec * 1000 : null,
          lastMessage: last ? {
            type: last.type,
            body: typeof last.body === 'string' ? last.body.slice(0, 100) : '',
            t: last.t,
            fromMe: last.id?.fromMe,
          } : null,
          number: numero,
          contactId: c.contact?.id?._serialized || null,
        }
      })

    return { ok: true, chats: chatsLimpos, labels: labelsLimpos, total: chats.length }
  } catch (e) {
    return { ok: false, motivo: 'erro', erro: String(e) }
  }
}

async function buscarKanban() {
  const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' })
  if (!tabs.length) return { ok: false, erro: 'Abra web.whatsapp.com primeiro' }
  const cfg = await chrome.storage.local.get(['vendedor_nome'])
  const waJsUrl = chrome.runtime.getURL('wppconnect-wa.js')

  for (const tab of tabs) {
    try {
      const [{ result }] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        world: 'MAIN',
        func: buscarKanbanCompletoNoContextoWA,
        args: [waJsUrl],
      })
      if (result?.ok) {
        return { ok: true, ...result, vendedor: cfg.vendedor_nome ?? '—' }
      }
      return { ok: false, erro: result?.motivo ?? 'erro_desconhecido' }
    } catch (e) {
      console.log('[Branorte SW] kanban falhou em tab', tab.id, e.message)
    }
  }
  return { ok: false, erro: 'Nenhuma aba do WA respondeu' }
}

// Permite popup forçar sync manualmente
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === 'BRANORTE_FORCE_SYNC') {
    executarSync().then(() => sendResponse({ ok: true }))
    return true // async
  }
  if (msg?.type === 'BRANORTE_TEST_NOTIF') {
    try {
      chrome.notifications.create('branorte-test-' + Date.now(), {
        type: 'basic',
        iconUrl: 'branorte-logo-white.png',
        title: '🔔 Branorte CRM',
        message: 'Notificação funcionando! Você vai receber assim quando lembretes dispararem.',
        requireInteraction: false,
      }, () => {
        if (chrome.runtime.lastError) sendResponse({ ok: false, erro: chrome.runtime.lastError.message })
        else sendResponse({ ok: true })
      })
    } catch (e) { sendResponse({ ok: false, erro: String(e) }) }
    return true
  }
  if (msg?.type === 'BRANORTE_GET_KANBAN_DATA') {
    buscarKanban().then(res => sendResponse(res))
    return true
  }
  if (msg?.type === 'BRANORTE_RESOLVER_LID') {
    resolverLid(msg.chatId).then(res => sendResponse(res))
    return true
  }
  if (msg?.type === 'BRANORTE_GET_PHOTO') {
    buscarFotoChat(msg.chatId).then(url => sendResponse({ url }))
    return true
  }
  if (msg?.type === 'BRANORTE_GET_MESSAGES') {
    buscarMensagens(msg.chatId, msg.count ?? 50).then(res => sendResponse(res))
    return true
  }
  if (msg?.type === 'BRANORTE_DOWNLOAD_MEDIA') {
    baixarMedia(msg.chatId, msg.msgId).then(res => sendResponse(res))
    return true
  }
  if (msg?.type === 'BRANORTE_SEND_TEXT') {
    enviarTexto(msg.chatId, msg.texto).then(res => sendResponse(res))
    return true
  }
  if (msg?.type === 'BRANORTE_SEND_MEDIA') {
    enviarMidia(msg.chatId, msg.dataUrl, msg.filename, msg.caption, msg.mediaType).then(res => sendResponse(res))
    return true
  }
  if (msg?.type === 'BRANORTE_SIDEBAR_ACTION') {
    handleSidebarAction(msg.action).then(res => sendResponse(res ?? { ok: true }))
    return true
  }
  if (msg?.type === 'BRANORTE_DETECT_ACTIVE_CHAT') {
    detectarChatAtivoNoWA().then(chat => sendResponse({ ok: !!chat, chat }))
    return true
  }
  return false
})

async function detectarChatAtivoNoWA() {
  const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' })
  if (!tabs.length) return null
  const waJsUrl = chrome.runtime.getURL('wppconnect-wa.js')
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      world: 'MAIN',
      func: async (waJsUrl) => {
        // Injeta wa-js se ainda não existir (mesma estratégia do lerEtiquetas)
        if (!window.WPP) {
          if (!window.__branorteFallbackInjected) {
            window.__branorteFallbackInjected = true
            await new Promise(r => {
              const s = document.createElement('script')
              s.src = waJsUrl
              s.onload = () => { s.remove(); r() }
              s.onerror = () => r()
              ;(document.head || document.documentElement).appendChild(s)
            })
            await new Promise(r => {
              const t = setInterval(() => { if (window.WPP?.isReady) { clearInterval(t); r() } }, 500)
              setTimeout(() => { clearInterval(t); r() }, 30000)
            })
          }
        }
        if (!window.WPP?.isReady) return { erro: 'wpp_nao_pronto' }
        try {
          // Reconhece todos os sufixos de id usados pelo WA
          const ehChatId = (id) => /@(c\.us|g\.us|lid|l\.id|broadcast|newsletter)$/i.test(String(id || ''))

          let chat = null

          // 1ª tentativa (PRIORITÁRIA): pegar o data-id no #main / [role="main"]
          //    — isso é o HEADER da conversa que está aberta agora
          const main = document.querySelector('#main, [role="main"]')
          if (main) {
            // Procura no header + qualquer elemento dentro do main com data-id
            const headerEl = main.querySelector('header [data-id], [role="banner"] [data-id]')
              || main.querySelector('[data-id]')
            if (headerEl) {
              const id = headerEl.getAttribute('data-id')
              if (ehChatId(id)) {
                try {
                  const c = await window.WPP.chat.get(id)
                  if (c) chat = c
                } catch {}
              }
            }
          }

          // 2ª tentativa: API oficial
          if (!chat) {
            try { chat = await window.WPP.chat.getActiveChat() } catch {}
          }

          // 3ª tentativa: Store (chat com active=true)
          if (!chat) {
            try {
              const Store = window.Store ?? window.WPP?.whatsapp?.Store
              const ChatColl = Store?.Chat ?? window.WPP?.whatsapp?.ChatCollection
              const todos = ChatColl?.getModelsArray?.() ?? []
              chat = todos.find(c => c.active === true) ?? null
            } catch {}
          }

          // 4ª tentativa (último recurso): qualquer [data-id] no DOM
          //    Filtra os que estão dentro de #main pra evitar pegar item da lista
          if (!chat) {
            const headers = document.querySelectorAll('[data-id]')
            for (const h of headers) {
              const id = h.getAttribute('data-id')
              if (!ehChatId(id)) continue
              try {
                const c = await window.WPP.chat.get(id)
                if (c) { chat = c; break }
              } catch {}
            }
          }

          if (!chat) return { erro: 'sem_chat_ativo' }

          // Resolve número real — se for @lid/@l.id, NÃO usa o user como número
          const idSer = chat.id?._serialized ?? ''
          const ehLid = /@(lid|l\.id)$/i.test(idSer)
          let numeroReal = ''

          if (!ehLid) {
            // @c.us → user é o número de telefone real
            numeroReal = chat.id?.user ?? ''
          } else {
            // @lid → tenta resolver pra phone number real
            try {
              // Tentativa 1: WPP.contact.getPhoneFromLid (versão recente)
              if (window.WPP?.contact?.getPhoneFromLid) {
                const phone = await window.WPP.contact.getPhoneFromLid(chat.id)
                if (phone) numeroReal = String(phone).replace(/@.*$/, '')
              }
              // Tentativa 2: chat.contact.id (alguns @lid têm contact resolvido)
              if (!numeroReal && chat.contact?.id?._serialized) {
                const cid = chat.contact.id._serialized
                if (!/@(lid|l\.id)$/i.test(cid)) {
                  numeroReal = chat.contact.id.user || ''
                }
              }
              // Tentativa 3: phoneNumber direto no chat
              if (!numeroReal && chat.phoneNumber) {
                numeroReal = String(chat.phoneNumber).replace(/[^\d]/g, '')
              }
            } catch {}
            // Se não resolveu, deixa vazio (NÃO usa o lid como número!)
          }

          return {
            id: idSer,
            name: chat.name ?? chat.formattedTitle ?? chat.contact?.pushname ?? '',
            number: numeroReal,
            isLid: ehLid && !numeroReal,
            labels: (chat.labels || []).map(String),
          }
        } catch (e) {
          return { erro: String(e) }
        }
      },
      args: [waJsUrl],
    })
    if (result?.erro) {
      console.log('[Branorte SW] detectar chat ativo:', result.erro)
      return null
    }
    return result
  } catch (e) {
    console.log('[Branorte SW] erro detectar chat:', e.message)
    return null
  }
}

async function handleSidebarAction(action) {
  switch (action) {
    case 'analisar-atual': {
      const chat = await detectarChatAtivoNoWA()
      if (!chat || !chat.id) {
        // Notifica WA que não há chat aberto
        const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' })
        if (tabs.length) {
          chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            world: 'MAIN',
            func: () => alert('Branorte: Abra primeiro uma conversa no WhatsApp pra eu analisar.'),
          }).catch(() => {})
        }
        return { ok: false }
      }
      // Salva contexto e abre CRM com o flag pra abrir IA do chat
      await chrome.storage.local.set({ analyze_target: chat })
      await chrome.tabs.create({ url: chrome.runtime.getURL('crm.html#analyze') })
      break
    }
    case 'open-crm':
      await chrome.tabs.create({ url: chrome.runtime.getURL('crm.html') })
      break
    case 'open-graficos':
      // Abre o CRM Vercel (gráficos do dashboard)
      await chrome.tabs.create({ url: 'https://branorte-crm.vercel.app/etiquetas-zap/graficos' })
      break
    case 'open-quick-replies':
      // Abre o CRM e o painel de mensagens rápidas
      await chrome.tabs.create({ url: chrome.runtime.getURL('crm.html#qr') })
      break
    case 'open-coach':
      await chrome.tabs.create({ url: chrome.runtime.getURL('crm.html#ia') })
      break
    case 'sync-now':
      await executarSync()
      break
    case 'open-popup':
      // Não dá pra abrir popup programaticamente — abre as extensions
      await chrome.tabs.create({ url: 'chrome://extensions/' })
      break
  }
  return { ok: true }
}

async function buscarMensagens(chatId, count = 50) {
  const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' })
  if (!tabs.length) return { ok: false, erro: 'wa_fechado' }
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      world: 'MAIN',
      func: async (id, n) => {
        if (!window.WPP?.isReady) return { ok: false, erro: 'not_ready' }
        try {
          const msgs = await window.WPP.chat.getMessages(id, { count: n })
          const out = (msgs || []).map(m => ({
            id: m.id?._serialized ?? '',
            type: m.type,
            body: typeof m.body === 'string' ? m.body : '',
            t: m.t,
            fromMe: !!m.id?.fromMe,
            mimetype: m.mimetype,
            filename: m.filename,
            duration: m.duration,
            isMedia: ['image','video','audio','ptt','document','sticker'].includes(m.type),
            caption: m.caption ?? null,
          }))
          return { ok: true, mensagens: out }
        } catch (e) {
          return { ok: false, erro: String(e) }
        }
      },
      args: [chatId, count],
    })
    return result
  } catch (e) {
    return { ok: false, erro: e.message }
  }
}

async function baixarMedia(chatId, msgId) {
  const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' })
  if (!tabs.length) return { ok: false, erro: 'wa_fechado' }
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      world: 'MAIN',
      func: async (chatId, msgId) => {
        // Helper: blob -> array (serializável via sendMessage)
        async function blobToArray(blob) {
          const ab = await blob.arrayBuffer()
          return Array.from(new Uint8Array(ab))
        }

        const tentativas = []

        // === ESTRATÉGIA 0: pega <audio src="blob:..."> direto do DOM ===
        // (técnica do speech-to-text-chrome-extension de @omatheusq —
        //  funciona quando o áudio já foi renderizado no DOM, mesmo sem dar play)
        try {
          // Procura elemento da mensagem pelo data-id
          const allDataIds = document.querySelectorAll('[data-id]')
          let elemMsg = null
          for (const el of allDataIds) {
            const id = el.getAttribute('data-id') || ''
            if (id.includes(msgId) || id.endsWith('_' + msgId.split('_').pop())) {
              elemMsg = el
              break
            }
          }
          if (elemMsg) {
            // Procura o <audio> dentro da bolha da mensagem
            let audioEl = elemMsg.querySelector('audio')
            if (!audioEl) {
              // Tenta clicar no botão de play pra forçar carregar o blob
              const playBtn = elemMsg.querySelector('[data-icon="audio-play"], [data-icon="ptt"], button[aria-label*="lay"]')
              if (playBtn) {
                playBtn.click()
                // Aguarda o WhatsApp criar o <audio>
                await new Promise(r => {
                  const t = setInterval(() => {
                    const a = elemMsg.querySelector('audio')
                    if (a?.src) { clearInterval(t); r() }
                  }, 100)
                  setTimeout(() => { clearInterval(t); r() }, 3000)
                })
                audioEl = elemMsg.querySelector('audio')
              }
            }
            if (audioEl?.src && audioEl.src.startsWith('blob:')) {
              const resp = await fetch(audioEl.src)
              const blob = await resp.blob()
              if (blob.size > 0) {
                return {
                  ok: true,
                  estrategia: 'dom_blob',
                  array: await blobToArray(blob),
                  mimetype: blob.type || 'audio/ogg',
                  size: blob.size,
                }
              }
              tentativas.push({ v: 'dom_blob', erro: 'blob_vazio' })
            } else {
              tentativas.push({ v: 'dom_blob', erro: 'sem_audio_no_dom' })
            }
          } else {
            tentativas.push({ v: 'dom_blob', erro: 'msg_nao_visivel' })
          }
        } catch (e) {
          tentativas.push({ v: 'dom_blob', erro: String(e).slice(0, 200) })
        }

        // === ESTRATÉGIA 1: WPP.chat.downloadMedia(msgId STRING) ===
        try {
          const blob = await window.WPP.chat.downloadMedia(msgId)
          if (blob && blob.size > 0) {
            return {
              ok: true,
              estrategia: 'wpp_string_id',
              array: await blobToArray(blob),
              mimetype: blob.type,
              size: blob.size,
            }
          }
          tentativas.push({ v: 'wpp_string_id', erro: 'blob_nulo_ou_vazio' })
        } catch (e) {
          tentativas.push({ v: 'wpp_string_id', erro: String(e).slice(0, 200) })
        }

        // === ESTRATÉGIA 2: msg.downloadMedia() (método do objeto) ===
        try {
          const msg = await window.WPP.chat.getMessageById(msgId)
          if (msg && typeof msg.downloadMedia === 'function') {
            const blob = await msg.downloadMedia()
            if (blob && blob.size > 0) {
              return {
                ok: true,
                estrategia: 'msg_method',
                array: await blobToArray(blob),
                mimetype: blob.type,
                size: blob.size,
              }
            }
            tentativas.push({ v: 'msg_method', erro: 'blob_nulo' })
          } else {
            tentativas.push({ v: 'msg_method', erro: 'sem_metodo' })
          }
        } catch (e) {
          tentativas.push({ v: 'msg_method', erro: String(e).slice(0, 200) })
        }

        // === ESTRATÉGIA 3: Store.DownloadManager.downloadAndDecrypt direto ===
        try {
          const msg = await window.WPP.chat.getMessageById(msgId)
          if (!msg) return { ok: false, erro: 'msg_not_found', tentativas }

          const Store = window.Store ?? window.WPP?.whatsapp?.Store
          const dlFn = Store?.DownloadManager?.downloadAndDecrypt
                    ?? Store?.DownloadManager?.downloadAndMaybeDecrypt
          if (!dlFn) {
            tentativas.push({ v: 'store_dlmgr', erro: 'fn_nao_encontrada' })
            return { ok: false, erro: 'download_failed', tentativas }
          }
          const arrayBuffer = await dlFn({
            directPath: msg.directPath,
            encFilehash: msg.encFilehash,
            filehash: msg.filehash,
            mediaKey: msg.mediaKey,
            mediaKeyTimestamp: msg.mediaKeyTimestamp,
            type: msg.type,
            signal: new AbortController().signal,
          })
          if (!arrayBuffer) {
            tentativas.push({ v: 'store_dlmgr', erro: 'array_buffer_nulo' })
            return { ok: false, erro: 'download_failed', tentativas }
          }
          const mimetype = msg.mimetype || (msg.type === 'ptt' ? 'audio/ogg; codecs=opus' : 'audio/mpeg')
          return {
            ok: true,
            estrategia: 'store_dlmgr',
            array: Array.from(new Uint8Array(arrayBuffer)),
            mimetype,
            size: arrayBuffer.byteLength,
          }
        } catch (e) {
          tentativas.push({ v: 'store_dlmgr', erro: String(e).slice(0, 200) })
          return { ok: false, erro: 'download_failed', tentativas }
        }
      },
      args: [chatId, msgId],
    })
    return result
  } catch (e) {
    return { ok: false, erro: e.message }
  }
}

// Pega o ID do próprio WhatsApp (do vendedor logado nesta aba)
async function obterMeuWhatsId() {
  const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' })
  if (!tabs.length) return null
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      world: 'MAIN',
      func: () => {
        try {
          // Estratégia 1: WPP.profile.getMyNumberId
          if (window.WPP?.profile?.getMyNumberId) {
            const me = window.WPP.profile.getMyNumberId()
            if (me?._serialized) return me._serialized
            if (typeof me === 'string') return me
          }
          // Estratégia 2: WPP.whatsapp.UserPrefs
          if (window.WPP?.whatsapp?.UserPrefs?.getMaybeMeUser) {
            const me = window.WPP.whatsapp.UserPrefs.getMaybeMeUser()
            if (me?._serialized) return me._serialized
          }
          // Estratégia 3: Store.Conn ou Store.UserPrefs
          const Store = window.Store ?? window.WPP?.whatsapp?.Store
          if (Store?.Conn?.me?._serialized) return Store.Conn.me._serialized
          if (Store?.UserPrefs?.getMaybeMeUser) {
            const me = Store.UserPrefs.getMaybeMeUser()
            if (me?._serialized) return me._serialized
          }
          // Estratégia 4: pelos dados do perfil
          if (Store?.Conn?.wid?._serialized) return Store.Conn.wid._serialized
          return null
        } catch {
          return null
        }
      },
    })
    return result || null
  } catch (e) {
    console.warn('[Branorte SW] obterMeuWhatsId erro:', e)
    return null
  }
}

async function enviarTexto(chatId, texto) {
  const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' })
  if (!tabs.length) return { ok: false, erro: 'wa_fechado' }
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      world: 'MAIN',
      func: async (id, t) => {
        try {
          await window.WPP.chat.sendTextMessage(id, t)
          return { ok: true }
        } catch (e) {
          return { ok: false, erro: String(e) }
        }
      },
      args: [chatId, texto],
    })
    return result
  } catch (e) {
    return { ok: false, erro: e.message }
  }
}

async function enviarMidia(chatId, dataUrl, filename, caption, mediaType) {
  const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' })
  if (!tabs.length) return { ok: false, erro: 'wa_fechado' }
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      world: 'MAIN',
      func: async (id, dataUrl, filename, caption, mediaType) => {
        try {
          if (!window.WPP?.isReady) return { ok: false, erro: 'not_ready' }

          const tentativas = []

          // ===== ÁUDIO (PTT — voice note nativa) =====
          // Cliente envia WebM/Opus direto. wa-js aceita e empacota como PTT
          // quando passamos isPtt: true + waveform: true (vira bolinha de voz
          // com forma de onda no destinatário).
          // Ref: https://github.com/wppconnect-team/wa-js/blob/main/src/chat/functions/sendFileMessage.ts
          if (mediaType === 'audio') {
            try {
              await window.WPP.chat.sendFileMessage(id, dataUrl, {
                type: 'audio',
                isPtt: true,
                waveform: true,
              })
              return { ok: true, estrategia: 'ptt' }
            } catch (e) {
              tentativas.push({ v: 'ptt', erro: String(e).slice(0, 200) })
              // Fallback único: PTT sem waveform (caso decodeAudioData falhe).
              // Mantém isPtt pra ainda virar voice note, só perde a forma de onda.
              try {
                await window.WPP.chat.sendFileMessage(id, dataUrl, {
                  type: 'audio',
                  isPtt: true,
                })
                return { ok: true, estrategia: 'ptt_no_waveform' }
              } catch (e2) {
                tentativas.push({ v: 'ptt_no_waveform', erro: String(e2).slice(0, 200) })
              }
            }
            return { ok: false, erro: 'audio_send_failed', tentativas }
          }

          // ===== IMAGE / VIDEO / DOCUMENT =====
          const opts = {
            type: mediaType || 'auto',
            caption: caption || '',
            filename: filename || 'arquivo',
          }
          try {
            await window.WPP.chat.sendFileMessage(id, dataUrl, opts)
            return { ok: true, estrategia: opts.type }
          } catch (e) {
            tentativas.push({ v: opts.type, erro: String(e).slice(0, 150) })
            // Fallback: tenta como documento
            try {
              await window.WPP.chat.sendFileMessage(id, dataUrl, {
                type: 'document',
                filename: filename || 'arquivo',
                caption: caption || '',
              })
              return { ok: true, estrategia: 'document_fallback' }
            } catch (e2) {
              tentativas.push({ v: 'document_fallback', erro: String(e2).slice(0, 150) })
              return { ok: false, erro: String(e).slice(0, 200), tentativas }
            }
          }
        } catch (e) {
          return { ok: false, erro: String(e).slice(0, 300) }
        }
      },
      args: [chatId, dataUrl, filename, caption, mediaType],
    })
    return result
  } catch (e) {
    return { ok: false, erro: e.message }
  }
}

async function resolverLid(chatId) {
  const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' })
  if (!tabs.length) return { ok: false, erro: 'wa_fechado' }
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      world: 'MAIN',
      func: async (id) => {
        try {
          if (!window.WPP?.isReady) return { ok: false, erro: 'not_ready' }
          const Store = window.Store ?? window.WPP?.whatsapp?.Store
          // Tenta várias estratégias de resolução LID → @c.us
          // 1) Pega o chat e veja se contact.id é c.us
          const chat = await window.WPP.chat.get(id) ?? await window.WPP.chat.find(id)
          if (chat?.contact?.id?._serialized?.endsWith('@c.us')) {
            return { ok: true, numero: chat.contact.id.user }
          }
          if (chat?.contact?.phoneNumber) {
            return { ok: true, numero: String(chat.contact.phoneNumber).replace(/[^\d]/g, '') }
          }
          // 2) Store.LidUtils
          const lu = Store?.LidUtils
          if (lu?.getPhoneNumber) {
            try {
              const p = lu.getPhoneNumber(id)
              if (p) return { ok: true, numero: String(p).replace(/[^\d]/g, '') }
            } catch {}
          }
          // 3) Store.WidFactory
          const wf = Store?.WidFactory
          if (wf?.getPhoneNumber) {
            try {
              const p = wf.getPhoneNumber(id)
              if (p) return { ok: true, numero: String(p).replace(/[^\d]/g, '') }
            } catch {}
          }
          // 4) Busca via signal/lid mapping
          if (Store?.SignalLidMap?.lidToPn) {
            try {
              const pn = Store.SignalLidMap.lidToPn(id)
              if (pn?._serialized) return { ok: true, numero: pn.user }
            } catch {}
          }
          return { ok: false, erro: 'sem_numero_publico' }
        } catch (e) {
          return { ok: false, erro: String(e).slice(0, 200) }
        }
      },
      args: [chatId],
    })
    return result || { ok: false }
  } catch (e) {
    return { ok: false, erro: e.message }
  }
}

async function buscarFotoChat(chatId) {
  const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' })
  if (!tabs.length) return null
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      world: 'MAIN',
      func: async (id) => {
        try {
          if (window.WPP?.contact?.getProfilePictureUrl) {
            return await window.WPP.contact.getProfilePictureUrl(id)
          }
        } catch {}
        return null
      },
      args: [chatId],
    })
    return result ?? null
  } catch {
    return null
  }
}
