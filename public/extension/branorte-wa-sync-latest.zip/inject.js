// inject.js — roda no contexto da página (window.Store acessível).
// Aguarda wa-js ficar pronto e dispara leitura de labels periodicamente.

(function () {
  const INTERVAL_MS = 5 * 1000 // 5s — quase instant; só envia POST se mudou
  let lastSnapshot = null      // último payload enviado, pra evitar POST sem mudança
  let realtimeAtivo = false    // listener LC ativo? (set após hookEventos)

  function log(...args) { console.log('[Branorte WA inject]', ...args) }

  function snapshotKey(payload) {
    // Cria string canônica pra comparar mudanças (id+count por etiqueta)
    return [...payload].sort((a, b) => String(a.id).localeCompare(String(b.id)))
      .map(e => `${e.id}:${e.count}`).join('|')
  }

  async function enviarLabels() {
    try {
      if (!window.WPP || !window.WPP.labels || !window.WPP.chat) {
        log('WPP ainda não disponível')
        return
      }

      // wa-js Label.count é bugado/cacheado. Contagem real = iterar chats e contar
      // quantos têm cada label. WPP.chat.list força hidratação dos chats.
      const labels = await window.WPP.labels.getAllLabels()
      const chats = await window.WPP.chat.list({ count: 5000 })

      const SYSTEM_NAMES = new Set(['NAO LIDAS', 'FAVORITOS', 'GRUPOS'])
      const norm = (s) => s.normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[‎‏]/g, '').toUpperCase().trim()

      // Contagem manual: chat.labels é array de IDs
      const realCount = new Map()
      for (const c of chats) {
        const ls = c.labels || []
        for (const lid of ls) {
          const id = String(lid)
          realCount.set(id, (realCount.get(id) || 0) + 1)
        }
      }

      const payload = (labels || [])
        .filter(l => l && l.name && !SYSTEM_NAMES.has(norm(l.name)))
        .map(l => ({
          id: l.id,
          name: l.name.replace(/[‎‏]/g, '').trim(),
          color: l.color,
          hex: l.hexColor,
          count: realCount.get(String(l.id)) ?? 0,
        }))

      const key = snapshotKey(payload)
      // Sempre reporta heartbeat (verificou agora, com ou sem mudança)
      window.postMessage({
        type: 'BRANORTE_WA_HEARTBEAT',
        payload_summary: payload.map(l => ({ name: l.name, count: l.count })),
        chats_total: chats.length,
        changed: key !== lastSnapshot,
        realtime: realtimeAtivo,
        polling_ms: INTERVAL_MS,
        wpp_version: window.WPP?.version,
      }, '*')

      if (key === lastSnapshot) {
        // Sem mudança — só heartbeat já foi
        return
      }
      lastSnapshot = key

      log(`${payload.length} labels (${chats.length} chats varridos) — MUDOU, enviando POST`,
          payload.map(l => `${l.name}=${l.count}`).slice(0, 8))
      window.postMessage({ type: 'BRANORTE_WA_LABELS', payload, total_chats: chats.length }, '*')
    } catch (e) {
      log('erro lendo labels', e)
    }
  }

  function aguardarReady() {
    return new Promise((resolve) => {
      if (!window.WPP) return resolve(false)
      if (window.WPP.isReady) return resolve(true)
      // wa-js v4 usa EventEmitter — escuta evento 'ready'
      try {
        window.WPP.on('ready', () => resolve(true))
      } catch (e) {
        // fallback: poll
        const t = setInterval(() => {
          if (window.WPP?.isReady) { clearInterval(t); resolve(true) }
        }, 1000)
      }
    })
  }

  // Debounce: agrupa múltiplas mudanças em rajada num único sync
  let debounceTimer = null
  function agendarSync(motivo) {
    clearTimeout(debounceTimer)
    debounceTimer = setTimeout(() => {
      log(`sync disparado por: ${motivo}`)
      enviarLabels()
    }, 1500)
  }

  function tryHookOnce() {
    try {
      const W = window.WPP?.whatsapp
      const LC = W?.LabelCollection
      if (!LC || typeof LC.on !== 'function') return false
      LC.on('all', (eventName) => agendarSync(`label.${eventName}`))
      log('✓ event listeners registrados em LabelCollection (real-time)')
      return true
    } catch (e) {
      log('erro registrando listeners', e)
      return false
    }
  }

  async function hookEventos() {
    // Tenta múltiplas vezes — LabelCollection pode demorar pra estar pronto
    for (let i = 0; i < 30; i++) {
      if (tryHookOnce()) return true
      await new Promise(r => setTimeout(r, 1000))
    }
    log('LabelCollection.on não disponível após 30s — fallback pra polling apenas')
    return false
  }

  async function bootstrap() {
    let tentativas = 0
    while (!window.WPP && tentativas < 60) {
      await new Promise(r => setTimeout(r, 1000))
      tentativas++
    }
    if (!window.WPP) {
      log('WPP global não apareceu após 60s — abortando')
      return
    }

    log('WPP detectado, aguardando ready…')
    await aguardarReady()
    log('WPP ready', {
      version: window.WPP.version,
      isReady: window.WPP.isReady,
      isFullReady: window.WPP.isFullReady,
    })

    // Hook em eventos de label pra real-time (fire-and-forget, atualiza realtimeAtivo quando conseguir)
    hookEventos().then(ok => {
      realtimeAtivo = ok
      log(ok ? 'modo real-time + polling backup' : 'modo polling-only')
    })

    // Reporta status inicial (será sobrescrito pelos heartbeats)
    window.postMessage({
      type: 'BRANORTE_WA_STATUS',
      realtime: realtimeAtivo,
      polling_ms: INTERVAL_MS,
      wpp_version: window.WPP.version,
    }, '*')

    // Primeira leitura
    setTimeout(enviarLabels, 3000)

    // Polling de backup (caso evento não dispare por algum motivo)
    setInterval(enviarLabels, INTERVAL_MS)
  }

  // Listener pra trigger manual via popup (força envio mesmo sem mudança)
  window.addEventListener('message', (ev) => {
    if (ev.source !== window || !ev.data) return
    if (ev.data.type === 'BRANORTE_TRIGGER_READ') {
      log('trigger manual recebido — força envio')
      lastSnapshot = null  // invalida cache pra forçar envio
      enviarLabels()
    }
  })

  bootstrap()
})()
