// wa-sidebar.js — Painel lateral inline no WhatsApp Web (só DOM, não injeta no page world)

(function () {
  if (document.getElementById('branorte-sb')) return

  const QR_ENDPOINT = 'https://flwbeevtvjiouxdjmziv.supabase.co/functions/v1/quick-replies'
  const IA_ENDPOINT = 'https://flwbeevtvjiouxdjmziv.supabase.co/functions/v1/coach-ia'
  const TRANSCRIBE_ENDPOINT = 'https://flwbeevtvjiouxdjmziv.supabase.co/functions/v1/wa-transcribe'
  const SECRET = 'branorte-wa-sync-2026'

  let chatAtivo = null  // {id, name, number, isLid, labels}

  // Retorna número de telefone REAL do chat ativo (null se for @lid sem resolução).
  // Use isso em vez de chatAtivo.number quando for salvar como telefone ou gerar wa.me.
  function numeroValidoChat(chat) {
    if (!chat) return null
    if (chat.isLid) return null
    const num = String(chat.number || '').replace(/[^\d]/g, '')
    if (num.length < 8 || num.length > 15) return null
    return num
  }

  let quickReplies = []
  let abaAtual = 'ia'
  let pollingTimer = null
  let ultimaMsgSugerida = null  // {texto, chatId}
  // Estado da aba Mensagens
  let qrVista = 'all'           // 'all' | 'popular' | 'recent'
  let qrCategoriaFiltro = null  // null = todas
  let qrTermoBusca = ''
  // Estado da aba Contato
  let contatoSubAtual = 'perfil'
  const HUB_ENDPOINT = 'https://flwbeevtvjiouxdjmziv.supabase.co/functions/v1/wa-contact-hub'
  const UPLOAD_ENDPOINT = 'https://flwbeevtvjiouxdjmziv.supabase.co/functions/v1/wa-media-upload'

  // ===== Lamejs (MP3 encoder) — carregado sob demanda =====
  let _lamejsCarregado = null
  async function carregarLamejs() {
    if (window.lamejs?.Mp3Encoder) return window.lamejs
    if (_lamejsCarregado) return _lamejsCarregado
    _lamejsCarregado = new Promise((resolve, reject) => {
      const url = chrome.runtime.getURL('lame.min.js')
      const s = document.createElement('script')
      s.src = url
      s.onload = () => {
        // lame.min.js expõe global `lamejs` como factory function
        if (typeof window.lamejs === 'function') {
          try { window.lamejs = window.lamejs() } catch (e) { reject(e); return }
        }
        if (window.lamejs?.Mp3Encoder) resolve(window.lamejs)
        else reject(new Error('lamejs nao expos Mp3Encoder'))
      }
      s.onerror = () => reject(new Error('falha ao carregar lame.min.js'))
      document.head.appendChild(s)
    })
    return _lamejsCarregado
  }

  // Converte WebM/Opus → MP3 via lamejs. WhatsApp toca como áudio nativo.
  async function webmToMp3Blob(blob, kbps = 128) {
    const lamejs = await carregarLamejs()
    const arrayBuffer = await blob.arrayBuffer()
    const AudioCtx = window.AudioContext || window.webkitAudioContext
    const ctx = new AudioCtx()
    let audioBuffer
    try { audioBuffer = await ctx.decodeAudioData(arrayBuffer.slice(0)) }
    finally { try { ctx.close() } catch {} }
    const numCh = Math.min(audioBuffer.numberOfChannels, 2)
    const sr = audioBuffer.sampleRate
    const enc = new lamejs.Mp3Encoder(numCh, sr, kbps)
    const L = audioBuffer.getChannelData(0)
    const R = numCh === 2 ? audioBuffer.getChannelData(1) : null
    const len = L.length
    const Li = new Int16Array(len)
    const Ri = R ? new Int16Array(len) : null
    for (let i = 0; i < len; i++) {
      const lv = Math.max(-1, Math.min(1, L[i]))
      Li[i] = lv < 0 ? lv * 0x8000 : lv * 0x7FFF
      if (R) {
        const rv = Math.max(-1, Math.min(1, R[i]))
        Ri[i] = rv < 0 ? rv * 0x8000 : rv * 0x7FFF
      }
    }
    const chunks = []
    const block = 1152
    for (let i = 0; i < len; i += block) {
      const lc = Li.subarray(i, i + block)
      const buf = R ? enc.encodeBuffer(lc, Ri.subarray(i, i + block)) : enc.encodeBuffer(lc)
      if (buf.length > 0) chunks.push(buf)
    }
    const tail = enc.flush()
    if (tail.length > 0) chunks.push(tail)
    return new Blob(chunks, { type: 'audio/mp3' })
  }

  // Converte WebM/Opus → WAV PCM 16-bit (fallback se MP3 falhar).
  async function webmToWavBlob(blob) {
    const arrayBuffer = await blob.arrayBuffer()
    const AudioCtx = window.AudioContext || window.webkitAudioContext
    const ctx = new AudioCtx()
    try {
      const audioBuffer = await ctx.decodeAudioData(arrayBuffer.slice(0))
      return audioBufferParaWav(audioBuffer)
    } finally {
      try { ctx.close() } catch {}
    }
  }

  function audioBufferParaWav(audioBuffer) {
    const numChannels = Math.min(audioBuffer.numberOfChannels, 2)
    const sampleRate = audioBuffer.sampleRate
    const length = audioBuffer.length
    const bytesPerSample = 2
    const blockAlign = numChannels * bytesPerSample
    const byteRate = sampleRate * blockAlign
    const dataSize = length * blockAlign
    const buf = new ArrayBuffer(44 + dataSize)
    const view = new DataView(buf)
    let off = 0
    const wStr = (s) => { for (let i = 0; i < s.length; i++) view.setUint8(off++, s.charCodeAt(i)) }
    const wU32 = (v) => { view.setUint32(off, v, true); off += 4 }
    const wU16 = (v) => { view.setUint16(off, v, true); off += 2 }
    wStr('RIFF'); wU32(36 + dataSize); wStr('WAVE')
    wStr('fmt '); wU32(16); wU16(1); wU16(numChannels)
    wU32(sampleRate); wU32(byteRate); wU16(blockAlign); wU16(16)
    wStr('data'); wU32(dataSize)
    const channels = []
    for (let c = 0; c < numChannels; c++) channels.push(audioBuffer.getChannelData(c))
    for (let i = 0; i < length; i++) {
      for (let c = 0; c < numChannels; c++) {
        let s = Math.max(-1, Math.min(1, channels[c][i]))
        s = s < 0 ? s * 0x8000 : s * 0x7FFF
        view.setInt16(off, s | 0, true); off += 2
      }
    }
    return new Blob([buf], { type: 'audio/wav' })
  }

  // ===== Guard: extension context valido? =====
  // Quando a extensao e recarregada/atualizada, content scripts antigos perdem
  // o runtime. chrome.runtime.id vira undefined. Tudo que usa chrome.* falha.
  function extContextValid() {
    try { return !!(chrome && chrome.runtime && chrome.runtime.id) } catch { return false }
  }

  // Detecta se erro é por context invalidated
  function isContextErr(e) {
    const m = String(e?.message || e || '').toLowerCase()
    return m.includes('extension context invalidated')
        || m.includes('extension context was invalidated')
        || m.includes('message port closed')
  }

  // Quando context cair: para tudo + mostra toast persistente com botão de reload.
  // Toast custom (não usa mostrarToast genérico) pra ficar visível até o user clicar
  // e dar F5 sozinho — evita ficar tentando lembrar do atalho.
  let _ctxMorto = false
  function avisarContextoMorto() {
    if (_ctxMorto) return
    _ctxMorto = true
    try { pararPolling?.() } catch {}
    try {
      document.getElementById('bsb-ctx-dead-toast')?.remove()
      const div = document.createElement('div')
      div.id = 'bsb-ctx-dead-toast'
      div.style.cssText = [
        'position:fixed', 'top:16px', 'right:16px', 'z-index:2147483647',
        'background:#fbbf24', 'color:#1f2937',
        'padding:8px 10px 8px 14px', 'border-radius:8px',
        'font:500 13px -apple-system,BlinkMacSystemFont,Segoe UI,sans-serif',
        'box-shadow:0 6px 18px rgba(0,0,0,0.18)',
        'display:flex', 'align-items:center', 'gap:10px',
        'max-width:340px',
      ].join(';')
      div.innerHTML =
        '<span style="flex:1">🔁 Extensão atualizada</span>' +
        '<button id="bsb-ctx-reload-btn" style="' +
          'background:#1f2937;color:#fff;border:0;padding:6px 12px;' +
          'border-radius:6px;cursor:pointer;font:600 12px inherit;white-space:nowrap' +
        '">Recarregar</button>' +
        '<button id="bsb-ctx-close-btn" title="Fechar" style="' +
          'background:transparent;color:#1f2937;border:0;padding:2px 6px;' +
          'border-radius:4px;cursor:pointer;font:700 16px inherit;line-height:1' +
        '">×</button>'
      document.body.appendChild(div)
      div.querySelector('#bsb-ctx-reload-btn')?.addEventListener('click', () => {
        try { location.reload() } catch {}
      })
      div.querySelector('#bsb-ctx-close-btn')?.addEventListener('click', () => {
        div.remove()
      })
    } catch {}
    // log discreto — info, não warning (não polui aba "Erros" do Chrome)
    try { console.info('[Branorte] context invalidated — toast mostrado') } catch {}
  }

  // Handlers GLOBAIS — silencia erros de context invalidated em qualquer lugar
  window.addEventListener('error', (ev) => {
    if (isContextErr(ev.error || ev.message)) {
      ev.preventDefault?.()
      ev.stopImmediatePropagation?.()
      avisarContextoMorto()
      return false
    }
  }, true)
  window.addEventListener('unhandledrejection', (ev) => {
    if (isContextErr(ev.reason)) {
      ev.preventDefault?.()
      avisarContextoMorto()
    }
  })

  // Faz upload de mídia pro bucket Supabase. Retorna { url, mime, size_kb } ou lança erro.
  async function uploadMidiaParaBucket(modalMedia, vendedor_nome) {
    const r = await fetch(UPLOAD_ENDPOINT, {
      method: 'POST',
      headers: { 'Authorization': 'Bearer ' + SECRET, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        vendedor_nome: vendedor_nome || 'SHARED',
        dataUrl: modalMedia.dataUrl,
        filename: modalMedia.filename,
        mediaType: modalMedia.mediaType,
      }),
    })
    if (!r.ok) {
      const j = await r.json().catch(() => ({}))
      throw new Error(j?.error || ('upload falhou ' + r.status))
    }
    return r.json()
  }

  function criar() {
    const LOGO_URL = chrome.runtime.getURL('branorte-logo-white.png')
    const wrap = document.createElement('div')
    wrap.id = 'branorte-sb'

    const toggle = document.createElement('button')
    toggle.id = 'branorte-sb-toggle'
    toggle.title = 'Branorte CRM'
    toggle.innerHTML = `<img src="${LOGO_URL}" alt="Branorte" style="width:26px;height:26px;display:block;margin:auto;object-fit:contain;" />`
    toggle.style.display = 'none' // ocultado: usar ⚡ ao lado do mic ou burger do topbar

    const full = document.createElement('div')
    full.id = 'branorte-sb-full'
    full.innerHTML = `
      <div class="bsb-resize-handle" id="bsb-resize-handle" title="Arraste pra redimensionar"></div>
      <div class="hd">
        <h2>Branorte CRM</h2>
        <div style="display:flex;gap:6px;align-items:center;">
          <button class="bsb-toggle-width" id="bsb-toggle-width" title="Reduzir / Expandir">◧</button>
          <button class="bsb-theme-toggle" id="bsb-theme-toggle" title="Alternar tema">🌙</button>
          <button class="close" id="bsb-close">✕</button>
        </div>
      </div>
      <div class="tabs">
        <button data-tab="contato" class="active">👤</button>
        <button data-tab="ia">🤖 IA</button>
        <button data-tab="qr">💬 Msgs</button>
        <button data-tab="cal">📅 Agenda</button>
        <button data-tab="atalhos">🚀</button>
      </div>
      <div class="body">
        <div class="pane active" data-pane="contato">
          <div class="bsb-contact-header" id="bsb-contact-header">
            <div class="bsb-loading"><div class="bsb-spin"></div>Carregando…</div>
          </div>
          <div class="bsb-contact-tabs" id="bsb-contact-tabs">
            <button data-sub="perfil" class="active">📋 Perfil</button>
            <button data-sub="notas">📝 Notas</button>
            <button data-sub="agenda">⏰ Agenda</button>
            <button data-sub="lembrete">🔔 Lembrete</button>
          </div>
          <div class="bsb-contact-body">
            <div class="bsb-subpane active" data-subpane="perfil" id="bsb-sub-perfil"></div>
            <div class="bsb-subpane" data-subpane="notas" id="bsb-sub-notas"></div>
            <div class="bsb-subpane" data-subpane="agenda" id="bsb-sub-agenda"></div>
            <div class="bsb-subpane" data-subpane="lembrete" id="bsb-sub-lembrete"></div>
          </div>
        </div>

        <div class="pane" data-pane="ia">
          <div class="bsb-ia-info" id="bsb-ia-info">Carregando chat ativo…</div>
          <div class="bsb-ia-quick">
            <button data-q="Resume essa conversa em 3 frases">📝 Resumir</button>
            <button data-q="Sugere a próxima mensagem que devo mandar baseado nessa conversa">💬 Sugerir resposta</button>
            <button data-q="Qual é a próxima pergunta inteligente que eu devo fazer pra avançar a venda? Considere o estágio do funil, objeções não resolvidas, e o estilo de comunicação do cliente. Devolva 1 pergunta principal pronta pra mandar (no <msg>) + 2 alternativas opcionais.">🎯 Próxima pergunta</button>
            <button data-q="Em que estágio do funil esse cliente está? Quais os próximos passos?">🪜 Estágio</button>
            <button data-q="Quais objeções ou dúvidas o cliente tem? Como contornar?">🛡️ Objeções</button>
            <button data-q="Esse cliente parece pronto pra fechar? Por quê?">🔥 Quente?</button>
            <button id="bsb-ia-transcrever" class="bsb-ia-tool">🎤 Transcrever áudios</button>
            <button id="bsb-ia-corrigir" class="bsb-ia-tool">✨ Corrigir texto</button>
            <button id="bsb-ia-corrigir-auto" class="bsb-ia-tool bsb-ia-toggle" data-on="false">⚡ Auto: OFF</button>
          </div>
          <div class="bsb-ia-resp ph" id="bsb-ia-resp">👋 Abre uma conversa no WhatsApp e clica numa opção acima ou pergunta livre.</div>
          <div class="bsb-ia-input">
            <textarea id="bsb-ia-input" placeholder="Pergunta sobre essa conversa…"></textarea>
            <button id="bsb-ia-send">Perguntar</button>
          </div>
        </div>

        <div class="pane" data-pane="qr">
          <div class="bsb-qr-toolbar">
            <div class="bsb-qr-search-wrap">
              <span class="bsb-qr-search-icon">🔍</span>
              <input id="bsb-qr-search" placeholder="Pesquisar resposta rápida" />
              <button class="bsb-qr-clear" id="bsb-qr-clear" title="Limpar">✕</button>
              <button class="bsb-qr-new-mini" id="bsb-qr-new" title="Nova mensagem rápida">⊕</button>
            </div>
            <div class="bsb-qr-filters" id="bsb-qr-filters">
              <button data-vista="all" class="active">Tudo</button>
              <button data-vista="por-tipo">Por Tipo ▼</button>
              <button data-vista="sem-categoria">Sem Categoria</button>
              <button data-vista="por-categoria">Por Categoria ▼</button>
              <button data-vista="popular">Mais Usadas</button>
            </div>
          </div>
          <div class="bsb-qr-list bsb-qr-list-dense" id="bsb-qr-list">
            <div class="bsb-loading"><div class="bsb-spin"></div>Carregando…</div>
          </div>
          <div class="bsb-qr-footer-mini">
            <button id="bsb-qr-export" title="Baixar backup">💾 Exportar</button>
            <button id="bsb-qr-import" title="Importar backup">📥 Importar</button>
            <input type="file" id="bsb-qr-import-file" accept=".json,application/json" style="display:none" />
          </div>
        </div>

        <div class="pane" data-pane="cal">
          <div class="bsb-cal-toolbar">
            <button class="bsb-cal-nav" id="bsb-cal-prev" title="Mês anterior">‹</button>
            <div class="bsb-cal-titulo" id="bsb-cal-titulo">—</div>
            <button class="bsb-cal-nav" id="bsb-cal-next" title="Próximo mês">›</button>
            <button class="bsb-cal-hoje" id="bsb-cal-hoje" title="Voltar pra hoje">Hoje</button>
          </div>
          <div class="bsb-cal-legenda">
            <span class="bsb-cal-leg-item"><span class="bsb-cal-dot bsb-cal-dot-msg"></span>Msg agendada</span>
            <span class="bsb-cal-leg-item"><span class="bsb-cal-dot bsb-cal-dot-rem"></span>Lembrete</span>
            <span class="bsb-cal-leg-item"><span class="bsb-cal-dot bsb-cal-dot-evt"></span>Evento</span>
          </div>
          <div class="bsb-cal-grid" id="bsb-cal-grid"></div>
          <div class="bsb-cal-dia" id="bsb-cal-dia">
            <div class="bsb-cal-dia-head">
              <span id="bsb-cal-dia-titulo">Selecione um dia</span>
              <button class="bsb-cc-primary" id="bsb-cal-novo" style="width:auto;padding:6px 12px;font-size:11px">+ Novo evento</button>
            </div>
            <div class="bsb-cal-dia-list" id="bsb-cal-dia-list"></div>
          </div>
        </div>

        <div class="pane" data-pane="atalhos">
          <div class="bsb-atalhos">
            <div class="bsb-section-title">🔔 Central de pendências</div>
            <button data-act="central-lembretes"><span class="ico">🔔</span><span>Meus lembretes</span><span class="bsb-badge" id="bsb-badge-rem" style="display:none">0</span></button>
            <button data-act="central-agendadas"><span class="ico">⏰</span><span>Mensagens agendadas</span><span class="bsb-badge" id="bsb-badge-agd" style="display:none">0</span></button>
            <button data-act="testar-notif"><span class="ico">🔊</span><span>Testar notificação</span></button>
            <div class="bsb-section-title" style="margin-top:14px;">📎 Enviar mídia pra conversa ativa</div>
            <button data-media="image"><span class="ico">🖼️</span><span>Enviar imagem</span></button>
            <button data-media="video"><span class="ico">🎥</span><span>Enviar vídeo</span></button>
            <button data-media="document"><span class="ico">📄</span><span>Enviar documento</span></button>
            <div class="bsb-section-title" style="margin-top:14px;">🛠️ Ferramentas</div>
            <button data-act="open-crm"><span class="ico">📋</span><span>Abrir CRM Kanban</span></button>
            <button data-act="open-graficos"><span class="ico">📊</span><span>Gráficos & Dashboard</span></button>
            <button data-act="sync-now"><span class="ico">🔄</span><span>Sincronizar agora</span></button>
            <button data-act="open-popup"><span class="ico">⚙️</span><span>chrome://extensions/</span></button>
          </div>
          <input type="file" id="bsb-file-input" style="display:none" />
        </div>
      </div>
    `

    wrap.appendChild(toggle)
    document.body.appendChild(wrap)
    document.body.appendChild(full)

    // ===== Toggle inline no composer do WhatsApp =====
    // Em vez do botão flutuante na borda, injeta um botão na barra do composer
    // (ao lado do clip de anexar / botão de enviar). Quando consegue injetar,
    // esconde o flutuante. Se o WA remonta o composer (troca de chat), reinjeta.
    function acharSlotComposer() {
      const footer = document.querySelector('footer')
      if (!footer) return null
      // Prioridade 1: emoji / sticker (mesma linha do input + enviar)
      // Prioridade 2: anexar/+ (fallback, pode estar em linha separada)
      const candidatos = [
        'button[aria-label*="Emoji" i]',
        'button[aria-label*="Adesivo" i]',
        'button[aria-label*="Sticker" i]',
        'button[aria-label*="Figurinha" i]',
        'span[data-icon="smiley"]',
        'span[data-icon="sticker"]',
        'span[data-icon="emoji"]',
        // Fallback: anexar/+
        'button[aria-label*="Anexar" i]',
        'button[aria-label*="Attach" i]',
        'button[title*="Anexar" i]',
        'span[data-icon="plus"]',
        'span[data-icon="clip"]',
        'span[data-icon="attach-menu-plus"]',
      ]
      for (const sel of candidatos) {
        const el = footer.querySelector(sel)
        if (el) {
          // Sobe até achar o button container (nível mais externo do botão clicável)
          const btn = el.closest('button') || el
          return { container: btn.parentElement, anchor: btn }
        }
      }
      return null
    }
    function montarInlineToggle() {
      // DESATIVADO: usar ⚡ na compose toolbar ou 🍔 no topbar
      // Remove qualquer instância existente
      const existente = document.getElementById('branorte-inline-toggle')
      if (existente) try { existente.remove() } catch {}
    }
    function verificarInlineToggle() {
      const inline = document.getElementById('branorte-inline-toggle')
      const slot = acharSlotComposer()
      if (inline && (!slot || !document.body.contains(inline))) {
        try { inline.remove() } catch {}
        wrap.classList.remove('branorte-inline-mode')
      }
      if (!inline && slot) {
        montarInlineToggle()
      } else if (inline && !inline.classList.contains('__bnr_synced__')) {
        // Mantém o ".active" sincronizado com o flutuante (uma vez)
        const obs = new MutationObserver(() => {
          inline.classList.toggle('active', toggle.classList.contains('active'))
        })
        obs.observe(toggle, { attributes: true, attributeFilter: ['class'] })
        inline.classList.add('__bnr_synced__')
      }
    }
    // Tenta montar imediato e depois com debounce em mudanças do DOM
    montarInlineToggle()
    let __bnrInlineRaf = 0
    const __bnrInlineObs = new MutationObserver(() => {
      if (__bnrInlineRaf) return
      __bnrInlineRaf = requestAnimationFrame(() => {
        __bnrInlineRaf = 0
        verificarInlineToggle()
      })
    })
    __bnrInlineObs.observe(document.body, { childList: true, subtree: true })

    // Toggle abrir/fechar painel
    toggle.addEventListener('click', async (e) => {
      e.stopPropagation()
      const aberto = full.classList.toggle('open')
      toggle.classList.toggle('active', aberto)
      sincronizarBodyAttr(aberto)
      if (aberto) {
        await atualizarChatAtivo()
        renderContatoSubpane(contatoSubAtual)  // primeira render
        iniciarPolling()
      } else {
        pararPolling()
      }
    })
    document.getElementById('bsb-close').addEventListener('click', () => {
      full.classList.remove('open')
      toggle.classList.remove('active')
      sincronizarBodyAttr(false)
      pararPolling()
    })

    // ===== Resize da sidebar =====
    const MIN_W = 280, MAX_W = 800, DEFAULT_W = 420, COMPACT_W = 320
    function aplicarLargura(px) {
      const clamped = Math.max(MIN_W, Math.min(MAX_W, px))
      document.documentElement.style.setProperty('--bsb-w', clamped + 'px')
      try { chrome.storage.local.set({ branorte_sb_width: clamped }) } catch {}
    }
    // Restaura largura salva
    chrome.storage.local.get(['branorte_sb_width']).then(({ branorte_sb_width }) => {
      if (typeof branorte_sb_width === 'number') aplicarLargura(branorte_sb_width)
    })
    // Drag handle
    const $resizeHandle = document.getElementById('bsb-resize-handle')
    let dragStartX = 0, dragStartW = 0
    const onDragMove = (ev) => {
      const dx = dragStartX - ev.clientX  // arrastar pra esquerda aumenta
      aplicarLargura(dragStartW + dx)
    }
    const onDragEnd = () => {
      full.classList.remove('resizing')
      $resizeHandle.classList.remove('active')
      document.removeEventListener('mousemove', onDragMove)
      document.removeEventListener('mouseup', onDragEnd)
    }
    $resizeHandle.addEventListener('mousedown', (ev) => {
      ev.preventDefault()
      dragStartX = ev.clientX
      dragStartW = full.getBoundingClientRect().width
      full.classList.add('resizing')
      $resizeHandle.classList.add('active')
      document.addEventListener('mousemove', onDragMove)
      document.addEventListener('mouseup', onDragEnd)
    })
    // Botão toggle largura (compacto/normal/largo)
    document.getElementById('bsb-toggle-width').addEventListener('click', () => {
      const atual = full.getBoundingClientRect().width
      // Cycle: normal → compacto → largo → normal
      let prox
      if (Math.abs(atual - DEFAULT_W) < 20) prox = COMPACT_W
      else if (Math.abs(atual - COMPACT_W) < 20) prox = 600
      else prox = DEFAULT_W
      aplicarLargura(prox)
    })

    // Toggle tema (dark / light)
    const $themeBtn = document.getElementById('bsb-theme-toggle')
    async function aplicarTema(tema) {
      full.dataset.theme = tema
      $themeBtn.textContent = tema === 'light' ? '☀️' : '🌙'
      $themeBtn.title = tema === 'light' ? 'Tema escuro' : 'Tema claro'
      try { await chrome.storage.local.set({ branorte_tema: tema }) } catch {}
    }
    chrome.storage.local.get(['branorte_tema']).then(({ branorte_tema }) => {
      aplicarTema(branorte_tema || 'dark')
    })
    $themeBtn.addEventListener('click', () => {
      const atual = full.dataset.theme === 'light' ? 'light' : 'dark'
      aplicarTema(atual === 'light' ? 'dark' : 'light')
    })

    // Tabs principais
    full.querySelectorAll('.tabs > button').forEach(btn => {
      btn.addEventListener('click', () => {
        const tab = btn.dataset.tab
        full.querySelectorAll('.tabs > button').forEach(b => b.classList.toggle('active', b === btn))
        full.querySelectorAll('.body > .pane').forEach(p => p.classList.toggle('active', p.dataset.pane === tab))
        abaAtual = tab
        if (tab === 'qr' && quickReplies.length === 0) carregarQR()
        if (tab === 'contato') renderContatoSubpane(contatoSubAtual)
        if (tab === 'cal') carregarCalendario()
      })
    })

    // Calendário: navegação de mês + novo evento
    document.getElementById('bsb-cal-prev').addEventListener('click', () => {
      calMesAtual.setMonth(calMesAtual.getMonth() - 1)
      renderCalendarioGrid()
    })
    document.getElementById('bsb-cal-next').addEventListener('click', () => {
      calMesAtual.setMonth(calMesAtual.getMonth() + 1)
      renderCalendarioGrid()
    })
    document.getElementById('bsb-cal-hoje').addEventListener('click', () => {
      calMesAtual = new Date()
      calMesAtual.setDate(1)
      calDiaSelecionado = new Date()
      renderCalendarioGrid()
      renderCalendarioDia()
    })
    document.getElementById('bsb-cal-novo').addEventListener('click', () => modalNovoEvento())

    // Sub-tabs do Contato
    full.querySelectorAll('#bsb-contact-tabs button').forEach(btn => {
      btn.addEventListener('click', () => {
        const sub = btn.dataset.sub
        full.querySelectorAll('#bsb-contact-tabs button').forEach(b => b.classList.toggle('active', b === btn))
        full.querySelectorAll('.bsb-subpane').forEach(p => p.classList.toggle('active', p.dataset.subpane === sub))
        contatoSubAtual = sub
        renderContatoSubpane(sub)
      })
    })

    // IA — botões de prompt rápido (têm data-q)
    full.querySelectorAll('.bsb-ia-quick button[data-q]').forEach(btn => {
      btn.addEventListener('click', () => {
        const $i = document.getElementById('bsb-ia-input')
        $i.value = btn.dataset.q
        perguntarIa()
      })
    })
    document.getElementById('bsb-ia-send').addEventListener('click', perguntarIa)
    document.getElementById('bsb-ia-input').addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault()
        perguntarIa()
      }
    })
    // Ferramentas: transcrever áudio + corrigir texto + auto-corrigir
    document.getElementById('bsb-ia-transcrever').addEventListener('click', transcreverUltimoAudio)
    document.getElementById('bsb-ia-corrigir').addEventListener('click', corrigirTextoComposicao)
    document.getElementById('bsb-ia-corrigir-auto').addEventListener('click', toggleAutoCorrigir)
    inicializarAutoCorrigir()

    // QR busca
    const $qrSearch = document.getElementById('bsb-qr-search')
    const $qrClear = document.getElementById('bsb-qr-clear')
    $qrSearch.addEventListener('input', (e) => {
      qrTermoBusca = e.target.value.toLowerCase().trim()
      $qrClear.style.display = qrTermoBusca ? 'inline-flex' : 'none'
      renderQR()
    })
    $qrClear.addEventListener('click', () => {
      $qrSearch.value = ''
      qrTermoBusca = ''
      $qrClear.style.display = 'none'
      renderQR()
    })

    // Tabs (Todas / Mais usadas / Recentes)
    full.querySelectorAll('#bsb-qr-filters button').forEach(btn => {
      btn.addEventListener('click', () => {
        full.querySelectorAll('#bsb-qr-filters button').forEach(b => b.classList.toggle('active', b === btn))
        qrVista = btn.dataset.vista
        renderQR()
      })
    })

    // Botão + Nova
    document.getElementById('bsb-qr-new').addEventListener('click', () => modalNovaQR(null))

    // QR export/import (no footer agora)
    document.getElementById('bsb-qr-export').addEventListener('click', exportarBackupQR)
    document.getElementById('bsb-qr-import').addEventListener('click', () => {
      document.getElementById('bsb-qr-import-file').click()
    })
    document.getElementById('bsb-qr-import-file').addEventListener('change', async (e) => {
      const file = e.target.files?.[0]
      if (!file) return
      await importarBackupQR(file)
      e.target.value = ''
    })

    // Atalhos
    full.querySelectorAll('.bsb-atalhos button[data-act]').forEach(btn => {
      btn.addEventListener('click', () => {
        const act = btn.dataset.act
        if (act === 'central-lembretes') return abrirCentralPendencias('reminders')
        if (act === 'central-agendadas') return abrirCentralPendencias('scheduled')
        if (act === 'testar-notif') return testarNotificacao()
        chrome.runtime.sendMessage({ type: 'BRANORTE_SIDEBAR_ACTION', action: act })
      })
    })

    // Atualiza badges de pendências quando entrar na aba Atalhos
    full.querySelectorAll('.tabs > button[data-tab="atalhos"]').forEach(b => {
      b.addEventListener('click', () => atualizarBadgesPendencias())
    })

    // Envio de mídia
    full.querySelectorAll('.bsb-atalhos button[data-media]').forEach(btn => {
      btn.addEventListener('click', () => abrirSeletorMidia(btn.dataset.media))
    })
  }

  function abrirSeletorMidia(tipo) {
    if (!chatAtivo) {
      mostrarToast('⚠️ Abra uma conversa no WhatsApp primeiro.', 'erro')
      return
    }
    const $input = document.getElementById('bsb-file-input')
    if (!$input) return
    const accepts = {
      image: 'image/*',
      video: 'video/*',
      document: '.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.zip,.rar,.csv',
    }
    $input.accept = accepts[tipo] || '*/*'
    $input.dataset.tipo = tipo
    $input.value = ''
    $input.onchange = async () => {
      const file = $input.files?.[0]
      if (!file) return
      await enviarArquivo(file, tipo)
    }
    $input.click()
  }

  async function enviarArquivo(file, tipo) {
    if (!chatAtivo) {
      mostrarToast('⚠️ Abra uma conversa primeiro.', 'erro')
      return
    }
    // Limite WhatsApp ~64MB pra docs/video
    const MAX = 60 * 1024 * 1024
    if (file.size > MAX) {
      mostrarToast(`❌ Arquivo muito grande: ${(file.size / 1024 / 1024).toFixed(1)}MB (máx 60MB).`, 'erro', 4500)
      return
    }
    let caption = ''
    if (tipo !== 'document') {
      const r = await modalLegenda(file.name)
      if (r === null) return  // cancelou
      caption = r
    }

    // Lê arquivo como dataURL
    const dataUrl = await new Promise((res, rej) => {
      const fr = new FileReader()
      fr.onload = () => res(fr.result)
      fr.onerror = () => rej(fr.error)
      fr.readAsDataURL(file)
    })

    // Feedback visual
    const $r = document.getElementById('bsb-ia-resp')
    const oldHtml = $r?.innerHTML
    if ($r) {
      $r.classList.remove('ph')
      $r.innerHTML = `<div style="text-align:center;padding:14px;">⏳ Enviando ${escapeHtml(file.name)}…</div>`
    }

    try {
      const r = await chrome.runtime.sendMessage({
        type: 'BRANORTE_SEND_MEDIA',
        chatId: chatAtivo.id,
        dataUrl,
        filename: file.name,
        caption,
        mediaType: tipo,
      })
      if (r?.ok) {
        if ($r) $r.innerHTML = `<div style="padding:10px;background:#10b981;color:white;border-radius:6px;text-align:center;font-weight:600;">✅ ${escapeHtml(file.name)} enviado!</div>`
        setTimeout(() => { if ($r && oldHtml) $r.innerHTML = oldHtml }, 3500)
        mostrarToast(`✅ ${file.name} enviado`, 'sucesso')
      } else {
        mostrarToast('❌ Falhou ao enviar: ' + (r?.erro || 'erro desconhecido'), 'erro', 4500)
        if ($r && oldHtml) $r.innerHTML = oldHtml
      }
    } catch (e) {
      mostrarToast('❌ Erro: ' + e.message, 'erro', 4500)
      if ($r && oldHtml) $r.innerHTML = oldHtml
    }
  }

  async function atualizarChatAtivo(silencioso = false) {
    if (!extContextValid()) { avisarContextoMorto(); return }
    const $info = document.getElementById('bsb-ia-info')
    if (!silencioso) $info.innerHTML = '<i>Detectando chat aberto…</i>'
    try {
      const r = await chrome.runtime.sendMessage({ type: 'BRANORTE_DETECT_ACTIVE_CHAT' })
      const novoChat = (r?.ok && r.chat) ? r.chat : null

      // Detecta mudança de chat
      const mudou = (chatAtivo?.id ?? null) !== (novoChat?.id ?? null)

      chatAtivo = novoChat
      if (chatAtivo) {
        const nome = chatAtivo.name || chatAtivo.number || '?'
        $info.innerHTML = `Conversa ativa: <b>${escapeHtml(nome)}</b>`
      } else {
        $info.innerHTML = `<i>Nenhuma conversa aberta. Abra uma no WhatsApp pra eu analisar.</i>`
      }

      // Se mudou de chat, limpa a resposta IA pra não ficar gente errada
      if (mudou && !silencioso) {
        const $r = document.getElementById('bsb-ia-resp')
        if ($r) {
          $r.classList.add('ph')
          $r.innerHTML = '👋 Conversa trocou! Clica numa opção acima ou pergunta sobre essa conversa.'
        }
        ultimaMsgSugerida = null
      }

      // Re-renderiza aba Contato sempre que chat muda (inclusive em silencioso)
      if (mudou) {
        renderContatoHeader()
        if (abaAtual === 'contato') renderContatoSubpane(contatoSubAtual)
      }
    } catch (e) {
      if (isContextErr(e)) { avisarContextoMorto(); return }
      if (!silencioso) $info.innerHTML = `<i>Erro: ${escapeHtml(e.message)}</i>`
    }
  }

  // Polling de chat ativo (só roda quando painel está aberto)
  function iniciarPolling() {
    pararPolling()
    pollingTimer = setInterval(() => {
      atualizarChatAtivo(true)  // silencioso
    }, 2500)
  }
  function pararPolling() {
    if (pollingTimer) {
      clearInterval(pollingTimer)
      pollingTimer = null
    }
  }

  // ===== Ferramenta: Transcrever último áudio do chat ativo =====
  async function transcreverUltimoAudio() {
    const $r = document.getElementById('bsb-ia-resp')
    const $btn = document.getElementById('bsb-ia-transcrever')
    if (!chatAtivo) await atualizarChatAtivo()
    if (!chatAtivo) {
      $r.classList.remove('ph')
      $r.textContent = '⚠️ Abra uma conversa primeiro.'
      return
    }
    $btn.disabled = true
    const labelOriginal = $btn.textContent
    $btn.textContent = '⏳ Buscando áudio…'
    $r.classList.remove('ph')
    $r.textContent = '🎤 Procurando o último áudio recebido…'

    try {
      // 1) Pega últimas mensagens e acha a última PTT/áudio
      const msgRes = await chrome.runtime.sendMessage({
        type: 'BRANORTE_GET_MESSAGES',
        chatId: chatAtivo.id,
        count: 30,
      })
      if (!msgRes?.ok) throw new Error(msgRes?.erro || 'falha ao ler mensagens')
      const msgs = msgRes.messages || msgRes.items || msgRes.data || []
      const audio = [...msgs].reverse().find(m =>
        m && (m.type === 'ptt' || m.type === 'audio' || /audio|ptt/i.test(m.mimetype || ''))
      )
      if (!audio) throw new Error('nenhum áudio nas últimas 30 mensagens')

      // 2) Baixa o áudio (background.js já tem BRANORTE_DOWNLOAD_MEDIA)
      $btn.textContent = '⏳ Baixando…'
      const dl = await chrome.runtime.sendMessage({
        type: 'BRANORTE_DOWNLOAD_MEDIA',
        chatId: chatAtivo.id,
        msgId: audio.id || audio._id || audio.key,
      })
      if (!dl?.ok || !dl.dataUrl) throw new Error(dl?.erro || 'falha no download')

      // 3) Envia pro endpoint de transcrição
      $btn.textContent = '⏳ Transcrevendo…'
      $r.textContent = '🎧 Enviando áudio pra transcrição…'
      const cfg = await chrome.storage.local.get(['vendedor_nome'])
      const tr = await fetch(TRANSCRIBE_ENDPOINT, {
        method: 'POST',
        headers: { 'Authorization': 'Bearer ' + SECRET, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          vendedor_nome: cfg.vendedor_nome || 'SHARED',
          chat_id: chatAtivo.id,
          dataUrl: dl.dataUrl,
          mimetype: audio.mimetype || 'audio/ogg',
          language: 'pt',
        }),
      })
      if (!tr.ok) {
        const t = await tr.text()
        throw new Error(`HTTP ${tr.status} — ${t.slice(0, 200)}`)
      }
      const j = await tr.json().catch(() => ({}))
      const texto = j.text || j.transcription || j.transcript || ''
      if (!texto) throw new Error('resposta vazia do servidor')

      $r.classList.remove('ph')
      $r.innerHTML = `<div style="opacity:0.7;font-size:11px;margin-bottom:6px;">📝 TRANSCRIÇÃO</div>${escapeHtml(texto)}`
      mostrarToast('✓ Áudio transcrito', 'sucesso', 1500)
    } catch (e) {
      $r.classList.remove('ph')
      $r.textContent = '❌ ' + e.message
      mostrarToast('Erro: ' + e.message, 'erro', 4000)
    } finally {
      $btn.disabled = false
      $btn.textContent = labelOriginal
    }
  }

  // Substitui texto no composer (contenteditable do WA Web).
  // WA Business novo usa Lexical/React — selectAll nativo é o único confiável
  // pra criar seleção que o editor respeite antes de paste/insertText.
  function substituirTextoComposer(composer, novoTexto) {
    if (!composer) return false

    return new Promise((resolve) => {
      const verificar = () => composer.innerText.trim() === novoTexto.trim()

      // Estratégia 1: focus + selectAll nativo + paste com DataTransfer
      composer.focus()
      try { document.execCommand('selectAll') } catch {}

      setTimeout(() => {
        try {
          const dt = new DataTransfer()
          dt.setData('text/plain', novoTexto)
          composer.dispatchEvent(new ClipboardEvent('paste', {
            clipboardData: dt, bubbles: true, cancelable: true,
          }))
        } catch {}

        setTimeout(() => {
          if (verificar()) { resolve(true); return }

          // Estratégia 2: selectAll + execCommand insertText (replace selection)
          composer.focus()
          try {
            document.execCommand('selectAll')
            document.execCommand('insertText', false, novoTexto)
          } catch {}

          setTimeout(() => {
            if (verificar()) { resolve(true); return }

            // Estratégia 3: deletar tudo via beforeinput + inserir
            composer.focus()
            try { document.execCommand('selectAll') } catch {}
            try {
              composer.dispatchEvent(new InputEvent('beforeinput', {
                inputType: 'deleteContent', bubbles: true, cancelable: true,
              }))
              composer.dispatchEvent(new InputEvent('beforeinput', {
                inputType: 'insertText', data: novoTexto, bubbles: true, cancelable: true,
              }))
              composer.dispatchEvent(new InputEvent('input', {
                inputType: 'insertText', data: novoTexto, bubbles: true,
              }))
            } catch {}

            setTimeout(() => {
              if (verificar()) { resolve(true); return }

              // Estratégia 4: backspace múltiplo + paste
              composer.focus()
              const lenAtual = composer.innerText.length
              for (let i = 0; i < lenAtual + 5; i++) {
                try {
                  composer.dispatchEvent(new InputEvent('beforeinput', {
                    inputType: 'deleteContentBackward', bubbles: true, cancelable: true,
                  }))
                } catch {}
              }
              setTimeout(() => {
                try {
                  const dt2 = new DataTransfer()
                  dt2.setData('text/plain', novoTexto)
                  composer.dispatchEvent(new ClipboardEvent('paste', {
                    clipboardData: dt2, bubbles: true, cancelable: true,
                  }))
                } catch {}
                setTimeout(() => {
                  if (verificar()) { resolve(true); return }

                  // Estratégia 5 (último recurso): manipular DOM direto
                  try {
                    composer.innerText = ''
                    composer.dispatchEvent(new InputEvent('input', { bubbles: true }))
                  } catch {}
                  setTimeout(() => {
                    try {
                      composer.focus()
                      const dt3 = new DataTransfer()
                      dt3.setData('text/plain', novoTexto)
                      composer.dispatchEvent(new ClipboardEvent('paste', {
                        clipboardData: dt3, bubbles: true, cancelable: true,
                      }))
                    } catch {}
                    resolve(true)
                  }, 30)
                }, 60)
              }, 30)
            }, 60)
          }, 60)
        }, 80)
      }, 50)
    })
  }

  // ===== Ferramenta: Corrigir texto digitado na composição do WA =====
  async function corrigirTextoComposicao() {
    const $r = document.getElementById('bsb-ia-resp')
    const $btn = document.getElementById('bsb-ia-corrigir')
    const composer = document.querySelector('footer [contenteditable="true"][role="textbox"], div[contenteditable="true"][data-tab="10"], div[contenteditable="true"][data-tab="1"]')
    if (!composer) {
      $r.classList.remove('ph')
      $r.textContent = '⚠️ Não achei o campo de mensagem. Abra uma conversa.'
      return
    }
    const original = composer.innerText.trim()
    if (!original) {
      $r.classList.remove('ph')
      $r.textContent = '⚠️ Digite algo no campo de mensagem antes.'
      return
    }
    $btn.disabled = true
    const labelOriginal = $btn.textContent
    $btn.textContent = '⏳ Corrigindo…'
    $r.classList.remove('ph')
    $r.innerHTML = `<div style="opacity:0.7;font-size:11px;margin-bottom:6px;">📝 ORIGINAL</div>${escapeHtml(original)}<div style="opacity:0.7;font-size:11px;margin:10px 0 6px;">⏳ Corrigindo…</div>`

    try {
      const cfg = await chrome.storage.local.get(['vendedor_nome'])
      const r = await fetch(IA_ENDPOINT, {
        method: 'POST',
        headers: { 'Authorization': 'Bearer ' + SECRET, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: 'corrigir',
          vendedor_nome: cfg.vendedor_nome || 'SHARED',
          texto: original,
          // Prompt explícito caso o backend ainda não trate `mode=corrigir`
          contexto: 'Corrija APENAS ortografia, gramática, pontuação e capitalização da mensagem do vendedor abaixo, mantendo o tom original (informal/formal), gírias e estilo. NÃO reescreva, NÃO adicione conteúdo, NÃO traduza. Devolva SOMENTE o texto corrigido, sem explicações nem aspas.',
          pergunta: original,
        }),
      })
      if (!r.ok) {
        const t = await r.text()
        throw new Error(`HTTP ${r.status} — ${t.slice(0, 200)}`)
      }
      const j = await r.json().catch(() => ({}))
      const corrigido = (j.resposta || j.text || j.answer || '').trim()
      if (!corrigido) throw new Error('resposta vazia do servidor')

      // Substitui o texto no campo do WhatsApp (com helper robusto)
      await substituirTextoComposer(composer, corrigido)

      $r.innerHTML =
        `<div style="opacity:0.7;font-size:11px;margin-bottom:6px;">📝 ORIGINAL</div>${escapeHtml(original)}` +
        `<div style="opacity:0.7;font-size:11px;margin:12px 0 6px;color:#10b981;">✨ CORRIGIDO (já aplicado no campo)</div>${escapeHtml(corrigido)}`
      mostrarToast('✨ Texto corrigido aplicado', 'sucesso', 1800)
    } catch (e) {
      $r.classList.remove('ph')
      $r.textContent = '❌ ' + e.message
      mostrarToast('Erro: ' + e.message, 'erro', 4000)
    } finally {
      $btn.disabled = false
      $btn.textContent = labelOriginal
    }
  }

  // ===== Auto-correção em tempo real (igual corretor) =====
  let autoCorrigirOn = false
  let autoCorrigirTimer = null
  let autoCorrigirComposer = null
  let autoCorrigirEmAndamento = false
  let autoCorrigirUltimoTexto = ''           // último texto JÁ corrigido (pra não reenviar)
  let autoCorrigirObserver = null

  async function inicializarAutoCorrigir() {
    try {
      const r = await chrome.storage.local.get('auto_corrigir_on')
      autoCorrigirOn = !!r.auto_corrigir_on
      atualizarUiAutoCorrigir()
      if (autoCorrigirOn) ligarAutoCorrigir()
    } catch (_) {}
  }

  async function toggleAutoCorrigir() {
    autoCorrigirOn = !autoCorrigirOn
    await chrome.storage.local.set({ auto_corrigir_on: autoCorrigirOn })
    atualizarUiAutoCorrigir()
    if (autoCorrigirOn) {
      ligarAutoCorrigir()
      mostrarToast('⚡ Auto-correção LIGADA — corrige depois de 1.5s sem digitar', 'sucesso', 2500)
    } else {
      desligarAutoCorrigir()
      mostrarToast('Auto-correção desligada', 'aviso', 1500)
    }
  }

  function atualizarUiAutoCorrigir() {
    const $b = document.getElementById('bsb-ia-corrigir-auto')
    if (!$b) return
    if (autoCorrigirOn) {
      $b.dataset.on = 'true'
      $b.textContent = '⚡ Auto: ON'
      $b.classList.add('is-on')
    } else {
      $b.dataset.on = 'false'
      $b.textContent = '⚡ Auto: OFF'
      $b.classList.remove('is-on')
    }
  }

  function acharComposerWA() {
    return document.querySelector(
      'footer [contenteditable="true"][role="textbox"], div[contenteditable="true"][data-tab="10"], div[contenteditable="true"][data-tab="1"]'
    )
  }

  function ligarAutoCorrigir() {
    desligarAutoCorrigir()  // garante limpeza
    // Observa o DOM pra re-anexar o listener quando WA recriar o composer (troca de chat)
    autoCorrigirObserver = new MutationObserver(() => {
      const novo = acharComposerWA()
      if (novo && novo !== autoCorrigirComposer) {
        anexarListenerComposer(novo)
      }
    })
    autoCorrigirObserver.observe(document.body, { childList: true, subtree: true })
    // Tenta anexar imediatamente
    const c = acharComposerWA()
    if (c) anexarListenerComposer(c)
  }

  function desligarAutoCorrigir() {
    if (autoCorrigirObserver) { autoCorrigirObserver.disconnect(); autoCorrigirObserver = null }
    if (autoCorrigirTimer) { clearTimeout(autoCorrigirTimer); autoCorrigirTimer = null }
    if (autoCorrigirComposer && autoCorrigirComposer._branorteAutoListener) {
      autoCorrigirComposer.removeEventListener('input', autoCorrigirComposer._branorteAutoListener)
      autoCorrigirComposer._branorteAutoListener = null
    }
    autoCorrigirComposer = null
  }

  function anexarListenerComposer(composer) {
    // Remove listener antigo do composer anterior
    if (autoCorrigirComposer && autoCorrigirComposer._branorteAutoListener) {
      autoCorrigirComposer.removeEventListener('input', autoCorrigirComposer._branorteAutoListener)
    }
    autoCorrigirComposer = composer
    const handler = () => {
      if (!autoCorrigirOn) return
      if (autoCorrigirTimer) clearTimeout(autoCorrigirTimer)
      autoCorrigirTimer = setTimeout(() => corrigirComposerAuto(composer), 1500)
    }
    composer.addEventListener('input', handler)
    composer._branorteAutoListener = handler
  }

  async function corrigirComposerAuto(composer) {
    if (!autoCorrigirOn) return
    if (autoCorrigirEmAndamento) return  // evita chamadas paralelas
    if (!composer || !composer.isConnected) return
    const texto = composer.innerText.trim()
    if (texto.length < 5) return                 // muito curto pra valer a pena
    if (texto === autoCorrigirUltimoTexto) return  // já corrigido nesse estado
    // Evita corrigir enquanto usuário ainda está digitando ativamente:
    // se a última caractere for letra (sem pontuação/espaço), espera mais
    // (handler já debouncia 1.5s, então geralmente OK)

    autoCorrigirEmAndamento = true
    try {
      const cfg = await chrome.storage.local.get(['vendedor_nome'])
      const r = await fetch(IA_ENDPOINT, {
        method: 'POST',
        headers: { 'Authorization': 'Bearer ' + SECRET, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: 'corrigir',
          vendedor_nome: cfg.vendedor_nome || 'SHARED',
          texto,
          contexto: 'Corrija APENAS ortografia, gramática, pontuação e capitalização da mensagem do vendedor abaixo, mantendo o tom original (informal/formal), gírias e estilo. NÃO reescreva, NÃO adicione conteúdo, NÃO traduza. Devolva SOMENTE o texto corrigido, sem explicações nem aspas.',
          pergunta: texto,
        }),
      })
      if (!r.ok) return
      const j = await r.json().catch(() => ({}))
      const corrigido = (j.resposta || j.text || j.answer || '').trim()
      if (!corrigido) return
      // Não substitui se: igual ao texto atual OU se usuário continuou digitando (texto mudou)
      const atual = composer.innerText.trim()
      if (atual !== texto) return  // user typed more, skip
      if (corrigido === atual) {
        autoCorrigirUltimoTexto = atual
        return
      }
      // Substitui texto via helper robusto
      await substituirTextoComposer(composer, corrigido)
      autoCorrigirUltimoTexto = corrigido
      flashComposer(composer)
    } catch (_) {
      // silencioso — auto-correção não deve incomodar com erros
    } finally {
      autoCorrigirEmAndamento = false
    }
  }

  function flashComposer(el) {
    if (!el) return
    const original = el.style.boxShadow
    el.style.transition = 'box-shadow 0.4s'
    el.style.boxShadow = 'inset 0 0 0 2px #10b981'
    setTimeout(() => { el.style.boxShadow = original }, 600)
  }

  async function perguntarIa() {
    const $i = document.getElementById('bsb-ia-input')
    const $r = document.getElementById('bsb-ia-resp')
    const $b = document.getElementById('bsb-ia-send')
    const pergunta = $i.value.trim()
    if (!pergunta) return

    if (!chatAtivo) {
      await atualizarChatAtivo()
      if (!chatAtivo) {
        $r.classList.remove('ph')
        $r.textContent = '⚠️ Abra uma conversa no WhatsApp primeiro.'
        return
      }
    }

    $r.classList.remove('ph')
    $r.textContent = '⏳ Lendo conversa e analisando…'
    $b.disabled = true
    $i.value = ''

    try {
      const cfg = await chrome.storage.local.get(['vendedor_nome'])
      // Pega só as últimas 5 mensagens (foco no contexto mais recente, mais rápido)
      const msgs = await chrome.runtime.sendMessage({
        type: 'BRANORTE_GET_MESSAGES',
        chatId: chatAtivo.id,
        count: 5,
      })
      if (!msgs?.ok) {
        $r.textContent = '⚠️ ' + (msgs?.erro ?? 'erro ao ler mensagens')
        return
      }

      // ===== Auto-transcrição: até 5 áudios das últimas mensagens, em paralelo =====
      const MAX_AUDIOS_TRANSCREVER = 5       // máximo (na prática vem de 5 mensagens só)
      const CONCORRENCIA = 3                 // 3 transcrições simultâneas
      const TIMEOUT_MS = 25000               // 25s por áudio

      const cacheKey = 'transcricoes_cache'
      const cache = (await chrome.storage.local.get([cacheKey]))[cacheKey] || {}

      // 1. Aplica cache em TODOS os áudios primeiro (rápido)
      let cacheHits = 0
      for (const m of (msgs.mensagens || [])) {
        if ((m.type === 'audio' || m.type === 'ptt') && !m.transcricao && cache[m.id]) {
          m.transcricao = cache[m.id]
          cacheHits++
        }
      }

      // 2. Identifica áudios SEM cache, mais recentes primeiro
      const audiosPendentes = (msgs.mensagens || [])
        .filter(m => (m.type === 'audio' || m.type === 'ptt') && !m.transcricao)
        .sort((a, b) => (b.t ?? 0) - (a.t ?? 0))   // mais novo primeiro
        .slice(0, MAX_AUDIOS_TRANSCREVER)

      const totalAudios = (msgs.mensagens || []).filter(m => m.type === 'audio' || m.type === 'ptt').length
      const ignorados = totalAudios - cacheHits - audiosPendentes.length

      if (audiosPendentes.length > 0) {
        let processados = 0
        const atualizarProgresso = () => {
          $r.textContent = `⏳ Transcrevendo áudios (${processados}/${audiosPendentes.length}${ignorados > 0 ? ` · ${ignorados} mais antigos ignorados` : ''})…`
        }
        atualizarProgresso()

        // Worker que processa um áudio com timeout
        async function transcreverUm(m) {
          try {
            const dl = await Promise.race([
              chrome.runtime.sendMessage({
                type: 'BRANORTE_DOWNLOAD_MEDIA',
                chatId: chatAtivo.id,
                msgId: m.id,
              }),
              new Promise((_, rej) => setTimeout(() => rej(new Error('timeout_download')), TIMEOUT_MS)),
            ])
            if (!dl?.ok || !dl.array) return
            const u8 = new Uint8Array(dl.array)
            const blob = new Blob([u8], { type: dl.mimetype || 'audio/ogg' })
            const dataUrl = await new Promise((res) => {
              const fr = new FileReader()
              fr.onload = () => res(fr.result)
              fr.onerror = () => res(null)
              fr.readAsDataURL(blob)
            })
            if (!dataUrl) return
            const tr = await Promise.race([
              fetch(TRANSCRIBE_ENDPOINT, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + SECRET },
                body: JSON.stringify({ dataUrl, language: 'pt' }),
              }),
              new Promise((_, rej) => setTimeout(() => rej(new Error('timeout_whisper')), TIMEOUT_MS)),
            ])
            const tj = await tr.json().catch(() => ({}))
            if (tj?.ok && tj.text) {
              m.transcricao = tj.text
              cache[m.id] = tj.text
            }
          } catch (e) {
            console.warn('[Branorte IA] falha transcrever áudio', m.id, e?.message || e)
          } finally {
            processados++
            atualizarProgresso()
          }
        }

        // Pool de concorrência: roda CONCORRENCIA simultâneas
        const fila = audiosPendentes.slice()
        const workers = []
        for (let i = 0; i < CONCORRENCIA; i++) {
          workers.push((async () => {
            while (fila.length > 0) {
              const m = fila.shift()
              if (m) await transcreverUm(m)
            }
          })())
        }
        await Promise.all(workers)

        // Salva cache (limita 200 entradas)
        try {
          const keys = Object.keys(cache)
          if (keys.length > 200) {
            const recortado = {}
            keys.slice(-200).forEach(k => recortado[k] = cache[k])
            await chrome.storage.local.set({ [cacheKey]: recortado })
          } else {
            await chrome.storage.local.set({ [cacheKey]: cache })
          }
        } catch {}
      }
      $r.textContent = '⏳ Analisando conversa…'

      const ia = await fetch(IA_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + SECRET },
        body: JSON.stringify({
          vendedor_nome: cfg.vendedor_nome || 'VENDEDOR',
          pergunta,
          nome_contato: chatAtivo.name || chatAtivo.number || 'cliente',
          mensagens_chat: msgs.mensagens,
          contexto: `Cliente: ${chatAtivo.name || chatAtivo.number}, etiquetas: ${(chatAtivo.labels || []).join(', ') || '(nenhuma)'}.`,
        }),
      })
      if (!ia.ok) {
        const j = await ia.json().catch(() => ({}))
        $r.textContent = '⚠️ ' + (j.error ?? ia.status)
        return
      }
      const j = await ia.json()
      const respostaTexto = j.resposta ?? '(sem resposta)'
      const sugestoes = Array.isArray(j.mensagem_sugerida) ? j.mensagem_sugerida : []

      // Renderiza resposta (limpa tags <msg>)
      $r.innerHTML = ''
      const $textoLimpo = document.createElement('div')
      $textoLimpo.style.whiteSpace = 'pre-wrap'
      $textoLimpo.textContent = respostaTexto.replace(/<msg>[\s\S]*?<\/msg>/gi, '').replace(/\n{3,}/g, '\n\n').trim()
      $r.appendChild($textoLimpo)

      // Botões de envio se IA sugeriu mensagem
      if (sugestoes.length > 0) {
        ultimaMsgSugerida = { texto: sugestoes[0], chatId: chatAtivo.id }
        for (const sugestao of sugestoes) {
          const $box = document.createElement('div')
          $box.style.cssText = 'margin-top: 14px; padding: 10px; background: #11151c; border: 1px solid #10b981; border-radius: 8px;'
          $box.innerHTML = `
            <div style="font-size:10px; color:#10b981; font-weight:700; text-transform:uppercase; letter-spacing:0.7px; margin-bottom:6px;">📤 Mensagem sugerida pra enviar</div>
            <div style="white-space:pre-wrap; font-size:12.5px; color:#e7e9ee; padding:8px; background:#0d1117; border-radius:5px; margin-bottom:8px; line-height:1.5;">${escapeHtml(sugestao)}</div>
            <div style="display:flex; gap:6px;">
              <button class="bsb-send-msg" style="flex:1; background:linear-gradient(135deg,#10b981,#059669); color:white; border:0; padding:8px; border-radius:6px; font-weight:700; font-size:12px; cursor:pointer;">📤 Enviar agora</button>
              <button class="bsb-edit-msg" style="background:#161a22; color:#d1d5db; border:1px solid #1f2937; padding:8px 12px; border-radius:6px; font-size:12px; cursor:pointer;">✏️ Editar</button>
              <button class="bsb-copy-msg" style="background:#161a22; color:#d1d5db; border:1px solid #1f2937; padding:8px 12px; border-radius:6px; font-size:12px; cursor:pointer;">📋</button>
            </div>
          `
          $box.querySelector('.bsb-send-msg').addEventListener('click', () => enviarSugestao(sugestao, false))
          $box.querySelector('.bsb-edit-msg').addEventListener('click', () => enviarSugestao(sugestao, true))
          $box.querySelector('.bsb-copy-msg').addEventListener('click', async () => {
            try {
              await navigator.clipboard.writeText(sugestao)
              mostrarToast('📋 Copiado!', 'sucesso', 1500)
            } catch {
              mostrarToast('❌ Falhou ao copiar', 'erro')
            }
          })
          $r.appendChild($box)
        }
      }
    } catch (e) {
      $r.textContent = '⚠️ ' + e.message
    } finally {
      $b.disabled = false
    }
  }

  // ===== Mensagens rápidas (REFATORADA v2) =====
  const CAT_COLORS = {
    GERAL: '#10b981', SAUDACAO: '#3b82f6', ORCAMENTO: '#f59e0b',
    PRODUTO: '#8b5cf6', POSVENDA: '#06b6d4', FOLLOWUP: '#ec4899',
    OBJECAO: '#f97316', WASCRIPT: '#6b7280',
  }
  function corCategoria(cat) {
    if (!cat) return '#6b7280'
    return CAT_COLORS[String(cat).toUpperCase()] ?? '#6b7280'
  }

  async function carregarQR() {
    const $list = document.getElementById('bsb-qr-list')
    if (!$list) return
    $list.innerHTML = '<div class="bsb-loading"><div class="bsb-spin"></div>Carregando…</div>'
    try {
      if (!chrome?.storage?.local?.get) {
        $list.innerHTML = '<div class="bsb-empty">⚠️ Sem acesso ao storage. Reload a página.</div>'
        return
      }
      const cfg = await chrome.storage.local.get(['vendedor_nome'])
      if (!cfg || !cfg.vendedor_nome) {
        $list.innerHTML = `
          <div class="bsb-qr-empty-state">
            <div class="bsb-qr-empty-icon">⚙️</div>
            <div class="bsb-qr-empty-title">Configure o vendedor</div>
            <div class="bsb-qr-empty-sub">Clica no ícone da extensão no Chrome e define seu nome.</div>
          </div>`
        return
      }
      const r = await fetch(`${QR_ENDPOINT}?vendedor=${encodeURIComponent(cfg.vendedor_nome)}`, {
        headers: { 'Authorization': 'Bearer ' + SECRET },
      })
      if (!r.ok) {
        $list.innerHTML = `<div class="bsb-empty">⚠️ Backend retornou ${r.status}.</div>`
        return
      }
      const j = await r.json().catch(() => ({}))
      quickReplies = Array.isArray(j?.items) ? j.items : []
      renderQR()
    } catch (e) {
      console.error('[Branorte QR] carregarQR erro:', e)
      $list.innerHTML = `<div class="bsb-empty">⚠️ ${escapeHtml(e?.message || String(e))}</div>`
    }
  }

  function destacarMatch(texto, termo) {
    if (!termo) return escapeHtml(texto)
    const re = new RegExp(`(${termo.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi')
    return escapeHtml(texto).replace(re, '<mark class="bsb-hl">$1</mark>')
  }

  function previewComVariaveis(body, chat) {
    if (!chat) return body
    const nome = chat.name || chat.number || ''
    const primeiro = nome.split(/\s+/)[0] || ''
    return body
      .replace(/\{\{nome\}\}/gi, nome)
      .replace(/\{\{primeiro_nome\}\}/gi, primeiro)
      .replace(/\{\{vendedor\}\}/gi, '')
  }

  function renderChips() {
    const $chips = document.getElementById('bsb-qr-chips')
    if (!$chips) return
    const counts = new Map()
    for (const qr of quickReplies) {
      const cat = (qr.category || 'GERAL').toUpperCase()
      counts.set(cat, (counts.get(cat) ?? 0) + 1)
    }
    if (counts.size === 0) { $chips.innerHTML = ''; return }
    const cats = [...counts.entries()].sort((a, b) => b[1] - a[1])
    const chips = [
      `<button class="bsb-chip ${qrCategoriaFiltro === null ? 'active' : ''}" data-cat="">Todas <span class="ct">${quickReplies.length}</span></button>`,
      ...cats.map(([cat, ct]) => {
        const cor = corCategoria(cat)
        const ativo = qrCategoriaFiltro === cat
        return `<button class="bsb-chip ${ativo ? 'active' : ''}" data-cat="${escapeHtml(cat)}" style="--chip-color:${cor}">
          <span class="bsb-chip-dot" style="background:${cor}"></span>${escapeHtml(cat)} <span class="ct">${ct}</span>
        </button>`
      }),
    ].join('')
    $chips.innerHTML = chips
    $chips.querySelectorAll('.bsb-chip').forEach($c => {
      $c.addEventListener('click', () => {
        const cat = $c.dataset.cat
        qrCategoriaFiltro = cat ? cat : null
        renderQR()
      })
    })
  }

  // Cache de categorias colapsadas (persistido em chrome.storage)
  let qrCategoriasColapsadas = new Set()
  ;(async () => {
    try {
      const c = await chrome.storage.local.get(['qr_cat_colapsadas'])
      if (Array.isArray(c.qr_cat_colapsadas)) qrCategoriasColapsadas = new Set(c.qr_cat_colapsadas)
    } catch {}
  })()
  async function salvarColapsadas() {
    try { await chrome.storage.local.set({ qr_cat_colapsadas: [...qrCategoriasColapsadas] }) } catch {}
  }

  // Ícone por tipo de mensagem
  function iconeTipoQR(qr) {
    if (qr.media_type === 'audio') return '🎤'
    if (qr.media_type === 'image') return '🖼️'
    if (qr.media_type === 'video') return '🎥'
    if (qr.media_type === 'document') return '📎'
    return '📄'
  }

  function renderQR() {
    const $list = document.getElementById('bsb-qr-list')
    if (!$list) return

    let items = quickReplies.slice()

    // Busca textual
    if (qrTermoBusca) {
      const t = qrTermoBusca
      items = items.filter(qr =>
        (qr.title || '').toLowerCase().includes(t) ||
        (qr.body || '').toLowerCase().includes(t) ||
        (qr.slug || '').toLowerCase().includes(t)
      )
    }

    // Filtros principais
    if (qrVista === 'sem-categoria') {
      items = items.filter(qr => !qr.category || qr.category.toUpperCase() === 'GERAL' || !qr.category.trim())
    } else if (qrVista === 'popular') {
      items = items.filter(qr => (qr.usage_count ?? 0) > 0)
        .sort((a, b) => (b.usage_count ?? 0) - (a.usage_count ?? 0))
    }

    if (items.length === 0) {
      const semNada = quickReplies.length === 0
      $list.innerHTML = `
        <div class="bsb-qr-empty-state">
          <div class="bsb-qr-empty-icon">${semNada ? '💬' : '🔍'}</div>
          <div class="bsb-qr-empty-title">${semNada ? 'Sem mensagens cadastradas' : 'Nada encontrado'}</div>
          <div class="bsb-qr-empty-sub">${semNada ? 'Clica em <b>⊕</b> em cima pra criar.' : 'Tenta outra palavra.'}</div>
        </div>`
      return
    }

    // Decide modo de renderização
    const modoLinhaPlana = qrVista === 'popular' || qrTermoBusca
    if (modoLinhaPlana) {
      // Lista plana sem agrupamento
      $list.innerHTML = items.map(qr => renderLinhaQR(qr)).join('')
    } else {
      // Agrupado por categoria, colapsável
      const grupos = new Map()
      for (const qr of items) {
        const cat = (qr.category || 'GERAL').toUpperCase()
        if (!grupos.has(cat)) grupos.set(cat, [])
        grupos.get(cat).push(qr)
      }
      // Ordena cats por count desc, ETIQUETA = principal
      const cats = [...grupos.entries()].sort((a, b) => b[1].length - a[1].length)
      $list.innerHTML = cats.map(([cat, lista]) => {
        const cor = corCategoria(cat)
        const colapsada = qrCategoriasColapsadas.has(cat)
        const seta = colapsada ? '▼' : '▲'
        const itemsHtml = colapsada ? '' : lista.sort((a, b) => (a.title || '').localeCompare(b.title || '')).map(qr => renderLinhaQR(qr)).join('')
        return `
          <div class="bsb-qr-grupo" data-cat="${escapeHtml(cat)}" style="--cat-color:${cor}">
            <button class="bsb-qr-grupo-head" data-action="toggle">
              <span class="bsb-qr-grupo-pin">🏷️</span>
              <span class="bsb-qr-grupo-nome">${escapeHtml(cat)}</span>
              <span class="bsb-qr-grupo-count">${lista.length}</span>
              <span class="bsb-qr-grupo-seta">${seta}</span>
            </button>
            <div class="bsb-qr-grupo-body">${itemsHtml}</div>
          </div>`
      }).join('')
    }

    // Listeners
    $list.querySelectorAll('.bsb-qr-grupo-head').forEach($h => {
      $h.addEventListener('click', () => {
        const cat = $h.closest('.bsb-qr-grupo').dataset.cat
        if (qrCategoriasColapsadas.has(cat)) qrCategoriasColapsadas.delete(cat)
        else qrCategoriasColapsadas.add(cat)
        salvarColapsadas()
        renderQR()
      })
    })

    $list.querySelectorAll('.bsb-qr-line').forEach($el => {
      const id = $el.dataset.id
      const qr = quickReplies.find(q => q.id === id)
      if (!qr) return
      // Click na linha → enviar (igual WaSeller)
      $el.querySelector('.bsb-qr-line-title').addEventListener('click', (e) => {
        e.stopPropagation()
        usarQuickReply(qr)
      })
      $el.querySelector('.bsb-qr-line-icon').addEventListener('click', (e) => {
        e.stopPropagation()
        usarQuickReply(qr)
      })
      $el.querySelector('[data-act="menu"]').addEventListener('click', (e) => {
        e.stopPropagation()
        modalNovaQR(qr)
      })
      $el.querySelector('[data-act="preview"]').addEventListener('click', (e) => {
        e.stopPropagation()
        modalPreviewQR(qr)
      })
      $el.querySelector('[data-act="send"]').addEventListener('click', (e) => {
        e.stopPropagation()
        usarQuickReply(qr)
      })
    })
  }

  function renderLinhaQR(qr) {
    const ico = iconeTipoQR(qr)
    const titulo = destacarMatch(qr.title || '(sem título)', qrTermoBusca)
    const usage = qr.usage_count > 0 ? `<span class="bsb-qr-line-uses">${qr.usage_count}×</span>` : ''
    return `
      <div class="bsb-qr-line" data-id="${escapeHtml(qr.id)}">
        <span class="bsb-qr-line-icon">${ico}</span>
        <span class="bsb-qr-line-title" title="${escapeHtml(qr.title || '')}">${titulo}</span>
        ${usage}
        <button class="bsb-qr-line-act" data-act="menu" title="Editar">⋯</button>
        <button class="bsb-qr-line-act" data-act="preview" title="Pré-visualizar">👁️</button>
        <button class="bsb-qr-line-act bsb-qr-line-send" data-act="send" title="Enviar agora">▷</button>
      </div>`
  }

  // Modal de pré-visualização (mostra mensagem completa antes de enviar)
  function modalPreviewQR(qr) {
    const overlay = document.createElement('div')
    overlay.className = 'bsb-qr-modal-overlay'
    const ico = iconeTipoQR(qr)
    const cat = (qr.category || 'GERAL').toUpperCase()
    const cor = corCategoria(cat)
    const bodyComVars = previewComVariaveis(qr.body || '', chatAtivo)
    const midia = qr.media_url ? `
      <div class="bsb-qr-prev-midia">
        ${qr.media_type === 'image' ? `<img src="${escapeHtml(qr.media_url)}" alt="" />` : ''}
        ${qr.media_type === 'video' ? `<video src="${escapeHtml(qr.media_url)}" controls preload="metadata"></video>` : ''}
        ${qr.media_type === 'audio' ? `<audio src="${escapeHtml(qr.media_url)}" controls></audio>` : ''}
        ${qr.media_type === 'document' ? `<div class="bsb-mqr-media-doc">📎 ${escapeHtml(qr.media_filename || 'arquivo')}</div>` : ''}
        <div class="bsb-qr-prev-midia-info">${escapeHtml(qr.media_filename || '')} · ${qr.media_size_kb || '?'} KB</div>
      </div>` : ''
    overlay.innerHTML = `
      <div class="bsb-qr-modal" style="width:480px">
        <div class="bsb-qr-modal-head" style="background:linear-gradient(135deg,${cor},${cor}cc)">
          <span>${ico} ${escapeHtml(qr.title || '')}</span>
          <button class="bsb-qr-modal-close">✕</button>
        </div>
        <div class="bsb-qr-modal-body">
          <div style="display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap;align-items:center">
            <span class="bsb-qr-card-cat" style="background:${cor}1a;color:${cor}">${escapeHtml(cat)}</span>
            ${qr.slug ? `<span class="bsb-qr-slug">/${escapeHtml(qr.slug)}</span>` : ''}
            ${qr.is_shared ? `<span class="bsb-qr-shared">🌐 compartilhada</span>` : ''}
            ${qr.usage_count > 0 ? `<span class="bsb-qr-usage">${qr.usage_count}× usada</span>` : ''}
          </div>
          ${midia}
          <div class="bsb-qr-prev-body">${escapeHtml(bodyComVars)}</div>
        </div>
        <div class="bsb-qr-modal-foot">
          <button class="bsb-qr-btn-cancel" data-act="edit">✏️ Editar</button>
          <div style="display:flex;gap:8px">
            <button class="bsb-qr-btn-cancel" data-act="close">Fechar</button>
            <button class="bsb-qr-btn-save" data-act="send">📤 Enviar agora</button>
          </div>
        </div>
      </div>`
    document.body.appendChild(overlay)
    const fechar = () => overlay.remove()
    overlay.querySelector('.bsb-qr-modal-close').addEventListener('click', fechar)
    overlay.querySelector('[data-act="close"]').addEventListener('click', fechar)
    overlay.addEventListener('click', e => { if (e.target === overlay) fechar() })
    overlay.querySelector('[data-act="edit"]').addEventListener('click', () => { fechar(); modalNovaQR(qr) })
    overlay.querySelector('[data-act="send"]').addEventListener('click', () => { fechar(); usarQuickReply(qr) })
  }

  // Modal de criação/edição inline (não precisa abrir CRM)
  async function modalNovaQR(qrExistente) {
    const cfg = await chrome.storage.local.get(['vendedor_nome'])
    if (!cfg?.vendedor_nome) { mostrarToast('⚠️ Configure o vendedor primeiro', 'erro'); return }

    const overlay = document.createElement('div')
    overlay.className = 'bsb-qr-modal-overlay'
    const cats = Object.keys(CAT_COLORS)
    overlay.innerHTML = `
      <div class="bsb-qr-modal">
        <div class="bsb-qr-modal-head">
          <span>${qrExistente ? '✏️ Editar mensagem' : '✨ Nova mensagem rápida'}</span>
          <button class="bsb-qr-modal-close">✕</button>
        </div>
        <div class="bsb-qr-modal-body">
          <div class="bsb-qr-modal-row">
            <label>Título</label>
            <input id="bsb-mqr-title" placeholder="Ex: Envio de orçamento" maxlength="100" />
          </div>
          <div class="bsb-qr-modal-row bsb-qr-modal-row-split">
            <div>
              <label>Categoria</label>
              <select id="bsb-mqr-cat">${cats.map(c => `<option value="${c}">${c}</option>`).join('')}</select>
            </div>
            <div>
              <label>Atalho <small>(opcional)</small></label>
              <input id="bsb-mqr-slug" placeholder="orca" maxlength="30" />
            </div>
          </div>
          <div class="bsb-qr-modal-row">
            <label>Mensagem <small>· Use <code>{{nome}}</code> <code>{{primeiro_nome}}</code> <code>{{vendedor}}</code></small></label>
            <textarea id="bsb-mqr-body" placeholder="Olá {{primeiro_nome}}, segue o orçamento…" rows="6"></textarea>
          </div>
          <div class="bsb-qr-modal-row">
            <label>🎬 Mídia <small>(opcional · enviada junto com a mensagem)</small></label>
            <div class="bsb-mqr-media-bar">
              <button type="button" class="bsb-mqr-media-btn" data-acc="image/*" data-mt="image">📷 Imagem</button>
              <button type="button" class="bsb-mqr-media-btn" data-acc="video/*" data-mt="video">🎥 Vídeo</button>
              <button type="button" class="bsb-mqr-media-btn" data-acc="audio/*" data-mt="audio">🎵 Áudio</button>
              <button type="button" class="bsb-mqr-media-btn" data-acc="*/*" data-mt="document">📎 Arquivo</button>
              <button type="button" class="bsb-mqr-media-btn bsb-mqr-rec-btn" id="bsb-mqr-rec">🎤 Gravar</button>
            </div>
            <input type="file" id="bsb-mqr-file" style="display:none" />
            <div id="bsb-mqr-media-preview" class="bsb-mqr-media-preview" style="display:none"></div>
          </div>
          <div class="bsb-qr-modal-row">
            <label class="bsb-qr-checkbox-row">
              <input type="checkbox" id="bsb-mqr-shared" />
              <span>🌐 Compartilhar com a equipe</span>
            </label>
          </div>
        </div>
        <div class="bsb-qr-modal-foot">
          ${qrExistente ? '<button class="bsb-qr-btn-del">🗑️ Apagar</button>' : '<span></span>'}
          <div style="display:flex;gap:8px;">
            <button class="bsb-qr-btn-cancel">Cancelar</button>
            <button class="bsb-qr-btn-save">💾 Salvar</button>
          </div>
        </div>
      </div>`
    document.body.appendChild(overlay)

    const $title = overlay.querySelector('#bsb-mqr-title')
    const $cat = overlay.querySelector('#bsb-mqr-cat')
    const $slug = overlay.querySelector('#bsb-mqr-slug')
    const $body = overlay.querySelector('#bsb-mqr-body')
    const $shared = overlay.querySelector('#bsb-mqr-shared')

    if (qrExistente) {
      $title.value = qrExistente.title || ''
      $cat.value = (qrExistente.category || 'GERAL').toUpperCase()
      $slug.value = qrExistente.slug || ''
      $body.value = qrExistente.body || ''
      $shared.checked = !!qrExistente.is_shared
    } else { $cat.value = 'GERAL' }
    $title.focus()

    // ===== Mídia =====
    let modalMedia = null  // { dataUrl, mediaType, filename, sizeKB }
    let mediaRecorder = null
    let recChunks = []
    let recStream = null

    const $fileInput = overlay.querySelector('#bsb-mqr-file')
    const $preview = overlay.querySelector('#bsb-mqr-media-preview')
    const $recBtn = overlay.querySelector('#bsb-mqr-rec')

    // Carrega mídia existente se for edição
    if (qrExistente) {
      // Prioridade: media_url do Supabase (novo)
      if (qrExistente.media_url) {
        modalMedia = {
          url: qrExistente.media_url,
          mediaType: qrExistente.media_type || 'document',
          filename: qrExistente.media_filename || 'arquivo',
          sizeKB: qrExistente.media_size_kb || 0,
          dataUrl: null,  // será baixado se precisar
        }
        renderMediaPreview()
      } else {
        // Fallback: chrome.storage (legado)
        try {
          const k = 'qr_media_' + qrExistente.id
          const stored = await chrome.storage.local.get(k)
          if (stored[k]) { modalMedia = stored[k]; renderMediaPreview() }
        } catch (_) {}
      }
    }

    function renderMediaPreview() {
      if (!modalMedia) {
        $preview.style.display = 'none'
        $preview.innerHTML = ''
        return
      }
      const { dataUrl, url, mediaType, filename, sizeKB } = modalMedia
      const src = dataUrl || url || ''
      let inner = ''
      if (mediaType === 'image') {
        inner = `<img src="${src}" alt="" />`
      } else if (mediaType === 'video') {
        inner = `<video src="${src}" controls preload="metadata"></video>`
      } else if (mediaType === 'audio') {
        inner = `<audio src="${src}" controls></audio>`
      } else {
        inner = `<div class="bsb-mqr-media-doc">📎 ${escapeHtml(filename)}</div>`
      }
      const tagBucket = url ? '<span class="bsb-cloud-tag" title="Sincronizada na nuvem">☁️</span>' : ''
      $preview.innerHTML = `
        ${inner}
        <div class="bsb-mqr-media-info">
          <span>${tagBucket} ${escapeHtml(filename)} · ${sizeKB || '?'} KB</span>
          <button type="button" class="bsb-mqr-media-remove" title="Remover">✕</button>
        </div>`
      $preview.style.display = 'block'
      $preview.querySelector('.bsb-mqr-media-remove').addEventListener('click', () => {
        modalMedia = null
        renderMediaPreview()
      })
    }

    function fileToDataUrl(file) {
      return new Promise((res, rej) => {
        const r = new FileReader()
        r.onload = () => res(r.result)
        r.onerror = () => rej(r.error)
        r.readAsDataURL(file)
      })
    }

    async function processarArquivo(file, mediaType) {
      if (!file) return
      // Limite de 10MB (chrome.storage.local quota)
      const sizeKB = Math.round(file.size / 1024)
      if (sizeKB > 10240) {
        mostrarToast(`❌ Arquivo muito grande (${(sizeKB/1024).toFixed(1)} MB) — máx 10 MB`, 'erro', 4000)
        return
      }
      if (sizeKB > 5120) {
        mostrarToast(`⚠️ Arquivo grande (${(sizeKB/1024).toFixed(1)} MB) — pode demorar`, 'aviso', 3000)
      }
      try {
        const dataUrl = await fileToDataUrl(file)
        modalMedia = { dataUrl, mediaType, filename: file.name || 'arquivo', sizeKB }
        renderMediaPreview()
      } catch (e) {
        mostrarToast('❌ Erro ao ler arquivo: ' + e.message, 'erro')
      }
    }

    // Botões de upload (image/video/audio/doc)
    overlay.querySelectorAll('.bsb-mqr-media-btn:not(.bsb-mqr-rec-btn)').forEach(btn => {
      btn.addEventListener('click', () => {
        $fileInput.value = ''
        $fileInput.accept = btn.dataset.acc
        $fileInput.dataset.mt = btn.dataset.mt
        $fileInput.click()
      })
    })
    $fileInput.addEventListener('change', (e) => {
      const f = e.target.files?.[0]
      if (f) processarArquivo(f, $fileInput.dataset.mt || 'document')
    })

    // Botão de gravação de áudio
    $recBtn.addEventListener('click', async () => {
      // Toggle: se gravando, para; senão, inicia
      if (mediaRecorder && mediaRecorder.state === 'recording') {
        mediaRecorder.stop()
        return
      }
      try {
        recStream = await navigator.mediaDevices.getUserMedia({ audio: true })
      } catch (e) {
        mostrarToast('❌ Sem permissão de microfone (clique no cadeado da URL pra liberar)', 'erro', 4500)
        return
      }
      recChunks = []
      const mime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus') ? 'audio/webm;codecs=opus' : 'audio/webm'
      mediaRecorder = new MediaRecorder(recStream, { mimeType: mime })
      mediaRecorder.ondataavailable = (ev) => { if (ev.data?.size) recChunks.push(ev.data) }
      mediaRecorder.onstop = async () => {
        try {
          // WebM/Opus é o formato nativo do WhatsApp pra PTT.
          // Manda direto (sem converter) - wa-js empacota como voice note
          // quando background.js usa isPtt: true + waveform: true.
          const audioBlob = new Blob(recChunks, { type: 'audio/webm; codecs=opus' })
          const dataUrl = await new Promise((res, rej) => {
            const r = new FileReader()
            r.onload = () => res(r.result)
            r.onerror = () => rej(r.error)
            r.readAsDataURL(audioBlob)
          })
          const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)
          modalMedia = {
            dataUrl,
            mediaType: 'audio',
            filename: `audio-${ts}.opus`,
            sizeKB: Math.round(audioBlob.size / 1024),
          }
          renderMediaPreview()
        } finally {
          recStream?.getTracks().forEach(t => t.stop())
          recStream = null
          $recBtn.classList.remove('is-recording')
          $recBtn.textContent = '🎤 Gravar'
        }
      }
      mediaRecorder.start()
      $recBtn.classList.add('is-recording')
      $recBtn.textContent = '⏹️ Parar gravação'
    })

    const fechar = () => overlay.remove()
    overlay.querySelector('.bsb-qr-modal-close').addEventListener('click', fechar)
    overlay.querySelector('.bsb-qr-btn-cancel').addEventListener('click', fechar)
    overlay.addEventListener('click', (e) => { if (e.target === overlay) fechar() })

    overlay.querySelector('.bsb-qr-btn-save').addEventListener('click', async () => {
      const payload = {
        id: qrExistente?.id,
        vendedor_nome: cfg.vendedor_nome,
        title: $title.value.trim(),
        slug: $slug.value.trim().toLowerCase().replace(/[^a-z0-9_-]/g, '') || null,
        category: $cat.value,
        body: $body.value,
        is_shared: $shared.checked,
      }
      if (!payload.title) {
        mostrarToast('⚠️ Título é obrigatório', 'erro')
        return
      }
      if (!payload.body || !payload.body.trim()) {
        if (modalMedia) {
          const tipoLabel = { image: '🖼️ Imagem', video: '🎥 Vídeo', audio: '🎵 Áudio', document: '📎 Arquivo' }[modalMedia.mediaType] || '📎 Mídia'
          payload.body = `${tipoLabel} · ${modalMedia.filename}`
        } else {
          mostrarToast('⚠️ Mensagem ou mídia obrigatória', 'erro')
          return
        }
      }

      // Se mídia é nova (tem dataUrl mas sem url), faz upload pro Supabase Storage
      if (modalMedia && modalMedia.dataUrl && !modalMedia.url) {
        try {
          mostrarToast('⏳ Subindo mídia…', 'aviso', 2000)
          const upRes = await uploadMidiaParaBucket(modalMedia, cfg.vendedor_nome)
          payload.media_url = upRes.url
          payload.media_type = modalMedia.mediaType
          payload.media_filename = modalMedia.filename
          payload.media_size_kb = upRes.size_kb
        } catch (e) {
          mostrarToast('❌ Falha no upload: ' + e.message, 'erro', 4500)
          return
        }
      } else if (modalMedia?.url) {
        // Mídia já estava no bucket (carregada de uma QR existente)
        payload.media_url = modalMedia.url
        payload.media_type = modalMedia.mediaType
        payload.media_filename = modalMedia.filename
        payload.media_size_kb = modalMedia.sizeKB
      } else {
        // Sem mídia — limpa explicitamente em edição
        payload.media_url = null
        payload.media_type = null
        payload.media_filename = null
        payload.media_size_kb = null
      }

      try {
        const r = await fetch(QR_ENDPOINT, {
          method: 'POST',
          headers: { 'Authorization': 'Bearer ' + SECRET, 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        })
        if (r.ok) {
          await carregarQR()
          mostrarToast(qrExistente ? '✅ Atualizada' : '✅ Criada', 'sucesso')
          fechar()
        } else {
          const j = await r.json().catch(() => ({}))
          mostrarToast('❌ ' + (j.error ?? r.status), 'erro')
        }
      } catch (e) { mostrarToast('❌ ' + e.message, 'erro') }
    })

    if (qrExistente) {
      overlay.querySelector('.bsb-qr-btn-del').addEventListener('click', async () => {
        if (!confirm(`Apagar "${qrExistente.title}"?`)) return
        try {
          const r = await fetch(`${QR_ENDPOINT}?id=${qrExistente.id}`, {
            method: 'DELETE',
            headers: { 'Authorization': 'Bearer ' + SECRET },
          })
          if (r.ok) {
            await chrome.storage.local.remove('qr_media_' + qrExistente.id).catch(() => {})
            mostrarToast('🗑️ Apagada', 'sucesso')
            fechar()
            await carregarQR()
          } else { mostrarToast('❌ Falhou ao apagar', 'erro') }
        } catch (e) { mostrarToast('❌ ' + e.message, 'erro') }
      })
    }

    // Garante que se fechar o modal durante gravação, libera o microfone
    const fecharOriginal = overlay.querySelector('.bsb-qr-modal-close')
    overlay.addEventListener('click', () => {
      if (mediaRecorder?.state === 'recording') {
        try { mediaRecorder.stop() } catch (_) {}
      }
      if (recStream) {
        recStream.getTracks().forEach(t => t.stop())
      }
    }, true)
  }

  async function enviarSugestao(texto, editar) {
    if (!chatAtivo) {
      await atualizarChatAtivo()
      if (!chatAtivo) { mostrarToast('⚠️ Abra uma conversa primeiro.', 'erro'); return }
    }
    let final = texto
    if (editar) {
      // Modal customizado de edição (substitui prompt nativo)
      final = await modalEditarTexto(texto)
      if (final === null || !final.trim()) return
    }
    // Sem confirm() - vai direto. O usuário já viu o texto e clicou em Enviar.
    const r = await chrome.runtime.sendMessage({
      type: 'BRANORTE_SEND_TEXT',
      chatId: chatAtivo.id,
      texto: final,
    })
    if (r?.ok) {
      mostrarToast(`✅ Enviado pra ${chatAtivo.name || chatAtivo.number}`, 'sucesso')
    } else {
      mostrarToast('❌ Falhou: ' + (r?.erro ?? 'erro'), 'erro')
    }
  }

  // ===== Toast customizado (substitui alert/confirm nativos) =====
  function mostrarToast(texto, tipo = 'sucesso', duracao = 3000) {
    // Intercepta erros de "extension context invalidated" e "message port closed":
    // muitos catches espalhados fazem mostrarToast('Erro: '+e.message). Se chegar
    // até aqui, redireciona pro toast amigável de reload em vez de mostrar o
    // erro raw em vermelho que assusta o user.
    const lower = String(texto || '').toLowerCase()
    if (lower.includes('extension context invalidated')
        || lower.includes('extension context was invalidated')
        || lower.includes('message port closed')) {
      try { avisarContextoMorto() } catch {}
      return
    }
    const wrap = document.getElementById('bsb-toast-wrap') || (() => {
      const w = document.createElement('div')
      w.id = 'bsb-toast-wrap'
      w.style.cssText = 'position:fixed;top:50px;right:20px;z-index:1000000;display:flex;flex-direction:column;gap:8px;pointer-events:none;'
      document.body.appendChild(w)
      return w
    })()
    const $t = document.createElement('div')
    const cor = tipo === 'erro' ? '#dc2626' : tipo === 'aviso' ? '#f59e0b' : '#10b981'
    $t.style.cssText = `pointer-events:auto;background:${cor};color:white;padding:10px 16px;border-radius:8px;font-size:13px;font-weight:600;box-shadow:0 4px 12px rgba(0,0,0,0.4);max-width:340px;animation:bsb-toast-in 0.2s ease-out;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;`
    $t.textContent = texto
    wrap.appendChild($t)
    setTimeout(() => {
      $t.style.transition = 'opacity 0.2s, transform 0.2s'
      $t.style.opacity = '0'
      $t.style.transform = 'translateX(20px)'
      setTimeout(() => $t.remove(), 220)
    }, duracao)
  }

  // ===== Modal de legenda (mídia) =====
  function modalLegenda(filename) {
    return new Promise((resolve) => {
      const overlay = document.createElement('div')
      overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:1000001;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(4px);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;'
      overlay.innerHTML = `
        <div style="background:#0a0d12;border:1px solid #1f2937;border-radius:12px;padding:18px;width:480px;max-width:92vw;box-shadow:0 12px 40px rgba(0,0,0,0.6);">
          <div style="font-size:13px;font-weight:700;color:#10b981;text-transform:uppercase;letter-spacing:0.6px;margin-bottom:6px;">📎 Enviar mídia</div>
          <div style="font-size:11px;color:#9ca3af;margin-bottom:10px;">${(filename || '').replace(/[<>&]/g, c => ({'<':'&lt;','>':'&gt;','&':'&amp;'}[c]))}</div>
          <textarea id="bsb-legenda-textarea" placeholder="Legenda (opcional)…" style="width:100%;min-height:100px;background:#0d1117;border:1px solid #1f2937;border-radius:6px;color:#e7e9ee;padding:10px 12px;font-size:13px;font-family:inherit;outline:none;resize:vertical;line-height:1.5;"></textarea>
          <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:12px;">
            <button id="bsb-legenda-cancel" style="background:#161a22;color:#d1d5db;border:1px solid #1f2937;padding:9px 16px;border-radius:6px;font-size:13px;cursor:pointer;font-weight:500;">Cancelar</button>
            <button id="bsb-legenda-ok" style="background:linear-gradient(135deg,#10b981,#059669);color:white;border:0;padding:9px 18px;border-radius:6px;font-size:13px;cursor:pointer;font-weight:700;">📤 Enviar</button>
          </div>
        </div>
      `
      document.body.appendChild(overlay)
      const $t = overlay.querySelector('#bsb-legenda-textarea')
      $t.focus()
      const fechar = (val) => { overlay.remove(); resolve(val) }
      overlay.querySelector('#bsb-legenda-ok').addEventListener('click', () => fechar($t.value))
      overlay.querySelector('#bsb-legenda-cancel').addEventListener('click', () => fechar(null))
      overlay.addEventListener('click', (e) => { if (e.target === overlay) fechar(null) })
      $t.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') fechar(null)
        if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) fechar($t.value)
      })
    })
  }

  // ===== Modal customizado de edição (substitui prompt nativo) =====
  function modalEditarTexto(textoInicial) {
    return new Promise((resolve) => {
      const overlay = document.createElement('div')
      overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:1000001;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(4px);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;'
      overlay.innerHTML = `
        <div style="background:#0a0d12;border:1px solid #1f2937;border-radius:12px;padding:18px;width:520px;max-width:92vw;box-shadow:0 12px 40px rgba(0,0,0,0.6);">
          <div style="font-size:13px;font-weight:700;color:#10b981;text-transform:uppercase;letter-spacing:0.6px;margin-bottom:10px;">✏️ Edita a mensagem</div>
          <textarea id="bsb-modal-textarea" style="width:100%;min-height:140px;background:#0d1117;border:1px solid #1f2937;border-radius:6px;color:#e7e9ee;padding:10px 12px;font-size:13px;font-family:inherit;outline:none;resize:vertical;line-height:1.5;"></textarea>
          <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:12px;">
            <button id="bsb-modal-cancel" style="background:#161a22;color:#d1d5db;border:1px solid #1f2937;padding:9px 16px;border-radius:6px;font-size:13px;cursor:pointer;font-weight:500;">Cancelar</button>
            <button id="bsb-modal-ok" style="background:linear-gradient(135deg,#10b981,#059669);color:white;border:0;padding:9px 18px;border-radius:6px;font-size:13px;cursor:pointer;font-weight:700;">📤 Enviar</button>
          </div>
        </div>
      `
      document.body.appendChild(overlay)
      const $t = overlay.querySelector('#bsb-modal-textarea')
      $t.value = textoInicial
      $t.focus()
      $t.setSelectionRange($t.value.length, $t.value.length)
      const fechar = (val) => { overlay.remove(); resolve(val) }
      overlay.querySelector('#bsb-modal-ok').addEventListener('click', () => fechar($t.value))
      overlay.querySelector('#bsb-modal-cancel').addEventListener('click', () => fechar(null))
      overlay.addEventListener('click', (e) => { if (e.target === overlay) fechar(null) })
      $t.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') fechar(null)
        if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) fechar($t.value)
      })
    })
  }

  async function usarQuickReply(qr) {
    if (!chatAtivo) await atualizarChatAtivo()
    if (!chatAtivo) {
      mostrarToast('⚠️ Abra uma conversa primeiro.', 'erro')
      return
    }
    const cfg = await chrome.storage.local.get(['vendedor_nome'])
    const nome = chatAtivo.name || chatAtivo.number || ''
    const primeiro = nome.split(/\s+/)[0] || ''

    // PRIORIDADE 1: media_url do Supabase Storage (novo)
    // PRIORIDADE 2: chrome.storage.local (legado, antes da migração)
    let media = null
    if (qr.media_url) {
      media = {
        url: qr.media_url,
        mediaType: qr.media_type || 'document',
        filename: qr.media_filename || 'arquivo',
      }
    } else {
      try {
        const k = 'qr_media_' + qr.id
        const stored = await chrome.storage.local.get(k)
        media = stored[k] || null  // tem dataUrl
      } catch (_) {}
    }

    // Se body é placeholder auto-gerado de mídia, limpa
    const PLACEHOLDER_RE = /^(🖼️ Imagem|🎥 Vídeo|🎵 Áudio|📎 Arquivo|📎 Mídia) · /
    const bodyOriginal = qr.body || ''
    const bodyLimpo = (media && PLACEHOLDER_RE.test(bodyOriginal)) ? '' : bodyOriginal
    const texto = bodyLimpo
      .replace(/\{\{nome\}\}/gi, nome)
      .replace(/\{\{primeiro_nome\}\}/gi, primeiro)
      .replace(/\{\{vendedor\}\}/gi, cfg.vendedor_nome || '')

    if (!texto.trim() && !media) return

    let r
    if (media) {
      // Se tem URL (do bucket), baixa antes de enviar
      let dataUrl = media.dataUrl
      if (!dataUrl && media.url) {
        try {
          mostrarToast('⏳ Baixando mídia…', 'aviso', 1500)
          const resp = await fetch(media.url)
          if (!resp.ok) throw new Error('HTTP ' + resp.status)
          const blob = await resp.blob()
          dataUrl = await new Promise((res, rej) => {
            const fr = new FileReader()
            fr.onload = () => res(fr.result)
            fr.onerror = () => rej(fr.error)
            fr.readAsDataURL(blob)
          })
        } catch (e) {
          mostrarToast('❌ Falha ao baixar mídia: ' + e.message, 'erro', 4000)
          return
        }
      }
      r = await chrome.runtime.sendMessage({
        type: 'BRANORTE_SEND_MEDIA',
        chatId: chatAtivo.id,
        dataUrl,
        filename: media.filename,
        caption: texto,
        mediaType: media.mediaType,
      })
    } else {
      r = await chrome.runtime.sendMessage({
        type: 'BRANORTE_SEND_TEXT',
        chatId: chatAtivo.id,
        texto,
      })
    }

    if (r?.ok) {
      mostrarToast(`✅ Enviado pra ${chatAtivo.name || chatAtivo.number}`, 'sucesso')
      fetch(QR_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + SECRET },
        body: JSON.stringify({ action: 'use', id_uso: qr.id }),
      }).catch(() => {})
    } else {
      mostrarToast('❌ Erro ao enviar: ' + (r?.erro || 'desconhecido'), 'erro')
    }
  }

  function escapeHtml(s) {
    return String(s ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]))
  }

  // ================================================================
  // ABA CONTATO (Perfil + Notas + Agenda + Lembrete)
  // ================================================================
  async function hubFetch(resource, opts = {}) {
    const { method = 'GET', query = {}, body = null } = opts
    const qs = new URLSearchParams(query).toString()
    const url = `${HUB_ENDPOINT}/${resource}${qs ? '?' + qs : ''}`
    const res = await fetch(url, {
      method,
      headers: {
        'Authorization': 'Bearer ' + SECRET,
        ...(body ? { 'Content-Type': 'application/json' } : {}),
      },
      ...(body ? { body: JSON.stringify(body) } : {}),
    })
    if (!res.ok) {
      const j = await res.json().catch(() => ({}))
      throw new Error(j?.error || `HTTP ${res.status}`)
    }
    return res.json()
  }

  function renderContatoHeader() {
    const $h = document.getElementById('bsb-contact-header')
    if (!$h) return
    if (!chatAtivo) {
      $h.innerHTML = `
        <div class="bsb-contact-empty">
          <div style="font-size:32px;opacity:.5">💬</div>
          <div style="font-size:13px;font-weight:700;margin-top:8px">Nenhuma conversa aberta</div>
          <div style="font-size:11.5px;color:#9ca3af;margin-top:4px">Abre um chat no WhatsApp pra ver o perfil.</div>
        </div>`
      return
    }
    const nome = chatAtivo.name || numeroValidoChat(chatAtivo) || '?'
    const num = numeroValidoChat(chatAtivo) || ''
    const labels = chatAtivo.labels || []
    const iniciais = nome.trim().split(/\s+/).slice(0, 2).map(s => s[0] || '').join('').toUpperCase() || '?'
    const numDisplay = num ? '+' + escapeHtml(num) : (chatAtivo.isLid ? '<span style="color:#9ca3af;font-style:italic;font-size:11px">número privado</span>' : '')
    $h.innerHTML = `
      <div class="bsb-cc-avatar">${escapeHtml(iniciais)}</div>
      <div class="bsb-cc-info">
        <div class="bsb-cc-name" title="${escapeHtml(nome)}">${escapeHtml(nome)}</div>
        <div class="bsb-cc-num">${numDisplay}</div>
        <div class="bsb-cc-labels">${labels.length === 0 ? '<span class="bsb-cc-nolab">sem etiqueta</span>' : labels.length + ' etiqueta(s)'}</div>
      </div>
      ${num ? '<button class="bsb-cc-copy" title="Copiar número">📋</button>' : ''}`
    const $copy = $h.querySelector('.bsb-cc-copy')
    if ($copy) $copy.addEventListener('click', async () => {
      try { await navigator.clipboard.writeText(num); mostrarToast('📋 Copiado', 'sucesso', 1500) } catch {}
    })
  }

  function renderContatoSubpane(sub) {
    // Header compacto só nas sub-abas que NÃO são Perfil (Perfil tem seu próprio hero)
    const $h = document.getElementById('bsb-contact-header')
    if ($h) $h.style.display = (sub === 'perfil') ? 'none' : 'flex'
    if (sub !== 'perfil') renderContatoHeader()
    if (sub === 'perfil') return renderPerfil()
    if (sub === 'notas') return renderNotas()
    if (sub === 'agenda') return renderAgenda()
    if (sub === 'lembrete') return renderLembrete()
  }

  // ----- Perfil (redesign moderno) -----
  async function renderPerfil() {
    const $p = document.getElementById('bsb-sub-perfil')
    if (!$p) return
    if (!chatAtivo) {
      $p.innerHTML = `
        <div class="bsb-pf-empty">
          <div class="bsb-pf-empty-icon">💬</div>
          <div class="bsb-pf-empty-title">Nenhuma conversa aberta</div>
          <div class="bsb-pf-empty-sub">Abra um chat no WhatsApp pra ver tudo do contato aqui.</div>
        </div>`
      return
    }

    const nome = chatAtivo.name || numeroValidoChat?.(chatAtivo) || chatAtivo.number || '?'
    const num = (typeof numeroValidoChat === 'function' ? numeroValidoChat(chatAtivo) : chatAtivo.number) || ''
    const isGroup = chatAtivo.id?.endsWith?.('@g.us')
    const labels = chatAtivo.labels || []
    const iniciais = nome.trim().split(/\s+/).slice(0, 2).map(s => s[0] || '').join('').toUpperCase() || '?'

    // Skeleton imediato
    $p.innerHTML = `
      <div class="bsb-pf-scroll">
        <!-- HERO -->
        <div class="bsb-pf-hero">
          <div class="bsb-pf-hero-avatar">${escapeHtml(iniciais)}</div>
          <div class="bsb-pf-hero-name" title="${escapeHtml(nome)}">${escapeHtml(nome)}</div>
          <div class="bsb-pf-hero-num">${num ? '+' + escapeHtml(num) : '<i>número privado</i>'}</div>
          <div class="bsb-pf-hero-tags" id="bsb-pf-tags">
            ${labels.length === 0
              ? '<span class="bsb-pf-tag bsb-pf-tag-none">sem etiqueta</span>'
              : labels.map(() => '<span class="bsb-pf-tag bsb-pf-tag-skeleton">···</span>').join('')}
          </div>
        </div>

        <!-- STATS -->
        <div class="bsb-pf-stats">
          <button class="bsb-pf-stat" data-go="notas">
            <div class="bsb-pf-stat-ico">📝</div>
            <div class="bsb-pf-stat-num" id="bsb-pf-st-notas">—</div>
            <div class="bsb-pf-stat-lbl">Notas</div>
          </button>
          <button class="bsb-pf-stat" data-go="agenda">
            <div class="bsb-pf-stat-ico">⏰</div>
            <div class="bsb-pf-stat-num" id="bsb-pf-st-agd">—</div>
            <div class="bsb-pf-stat-lbl">Agendadas</div>
          </button>
          <button class="bsb-pf-stat" data-go="lembrete">
            <div class="bsb-pf-stat-ico">🔔</div>
            <div class="bsb-pf-stat-num" id="bsb-pf-st-rem">—</div>
            <div class="bsb-pf-stat-lbl">Lembretes</div>
          </button>
        </div>

        <!-- AÇÕES RÁPIDAS -->
        <div class="bsb-pf-section">
          <div class="bsb-pf-section-title">⚡ Ações rápidas</div>
          <div class="bsb-pf-actions">
            <button class="bsb-pf-action" data-quick="msg">
              <span class="bsb-pf-action-ico" style="background:#10b9811a;color:#10b981">💬</span>
              <span class="bsb-pf-action-lbl">Mensagem rápida</span>
            </button>
            <button class="bsb-pf-action" data-quick="agendar">
              <span class="bsb-pf-action-ico" style="background:#3b82f61a;color:#3b82f6">⏰</span>
              <span class="bsb-pf-action-lbl">Agendar mensagem</span>
            </button>
            <button class="bsb-pf-action" data-quick="lembrete">
              <span class="bsb-pf-action-ico" style="background:#f59e0b1a;color:#f59e0b">🔔</span>
              <span class="bsb-pf-action-lbl">Criar lembrete</span>
            </button>
            <button class="bsb-pf-action" data-quick="evento">
              <span class="bsb-pf-action-ico" style="background:#8b5cf61a;color:#8b5cf6">📅</span>
              <span class="bsb-pf-action-lbl">Adicionar à agenda</span>
            </button>
            <button class="bsb-pf-action" data-quick="ia">
              <span class="bsb-pf-action-ico" style="background:#6366f11a;color:#6366f1">🤖</span>
              <span class="bsb-pf-action-lbl">Analisar com IA</span>
            </button>
            <button class="bsb-pf-action" data-quick="nota">
              <span class="bsb-pf-action-ico" style="background:#ec48991a;color:#ec4899">📝</span>
              <span class="bsb-pf-action-lbl">Nova anotação</span>
            </button>
          </div>
        </div>

        <!-- DETALHES -->
        <div class="bsb-pf-section">
          <div class="bsb-pf-section-title">📋 Detalhes</div>
          <div class="bsb-pf-info">
            <div class="bsb-pf-info-row">
              <span class="bsb-pf-info-k">Tipo</span>
              <span class="bsb-pf-info-v">${isGroup ? '👥 Grupo' : '👤 Contato'}</span>
            </div>
            ${num ? `<div class="bsb-pf-info-row">
              <span class="bsb-pf-info-k">Telefone</span>
              <span class="bsb-pf-info-v" style="font-variant-numeric:tabular-nums">+${escapeHtml(num)}
                <button class="bsb-pf-info-btn" data-act="copy-num" title="Copiar">📋</button>
              </span>
            </div>` : ''}
            ${num ? `<div class="bsb-pf-info-row">
              <span class="bsb-pf-info-k">wa.me</span>
              <span class="bsb-pf-info-v" style="font-family:'Courier New',monospace;font-size:10.5px">wa.me/${escapeHtml(num)}
                <button class="bsb-pf-info-btn" data-act="copy-link" title="Copiar link">🔗</button>
              </span>
            </div>` : ''}
            <details class="bsb-pf-tech">
              <summary>🔧 Dados técnicos</summary>
              <div class="bsb-pf-info-row">
                <span class="bsb-pf-info-k">Chat ID</span>
                <span class="bsb-pf-info-v" style="font-family:'Courier New',monospace;font-size:10px;opacity:.7">${escapeHtml(chatAtivo.id || '')}</span>
              </div>
            </details>
          </div>
        </div>

        <!-- LINKS EXTERNOS -->
        <div class="bsb-pf-section">
          <button class="bsb-pf-link" data-act="open-crm-chat">
            📋 Abrir no CRM Kanban
            <span style="margin-left:auto;opacity:.5">↗</span>
          </button>
        </div>
      </div>`

    // ===== Stats reais (busca em paralelo) =====
    try {
      const [jN, jA, jR] = await Promise.all([
        hubFetch('notes',     { query: { chat_id: chatAtivo.id } }).catch(() => ({ items: [] })),
        hubFetch('scheduled', { query: { chat_id: chatAtivo.id } }).catch(() => ({ items: [] })),
        hubFetch('reminders', { query: { chat_id: chatAtivo.id } }).catch(() => ({ items: [] })),
      ])
      const stN = $p.querySelector('#bsb-pf-st-notas')
      const stA = $p.querySelector('#bsb-pf-st-agd')
      const stR = $p.querySelector('#bsb-pf-st-rem')
      if (stN) stN.textContent = (jN.items || []).length
      if (stA) stA.textContent = (jA.items || []).filter(x => x.status === 'pending').length
      if (stR) stR.textContent = (jR.items || []).filter(x => x.status === 'pending').length
    } catch (_) {}

    // ===== Etiquetas reais (com nome + cor) =====
    if (labels.length > 0) {
      try {
        const cfg = await chrome.storage.local.get(['last_etiquetas', 'wa_labels_cache'])
        const cache = cfg.last_etiquetas || cfg.wa_labels_cache || []
        const $tags = $p.querySelector('#bsb-pf-tags')
        if ($tags && cache.length > 0) {
          // Cache vem como [{name, count}] sem id confiável — fallback simples
          $tags.innerHTML = labels.slice(0, 5).map(() => {
            return `<span class="bsb-pf-tag" style="background:#10b9811a;color:#10b981;border-color:#10b98155">🏷️ etiqueta</span>`
          }).join('')
        } else if ($tags) {
          $tags.innerHTML = `<span class="bsb-pf-tag" style="background:#10b9811a;color:#10b981;border-color:#10b98155">🏷️ ${labels.length} etiqueta(s)</span>`
        }
      } catch (_) {}
    }

    // ===== Handlers =====
    // Stats clicáveis → vai pra sub-aba
    $p.querySelectorAll('[data-go]').forEach($s => {
      $s.addEventListener('click', () => {
        const sub = $s.dataset.go
        const $btn = document.querySelector(`#bsb-contact-tabs button[data-sub="${sub}"]`)
        if ($btn) $btn.click()
      })
    })

    // Ações rápidas
    $p.querySelectorAll('[data-quick]').forEach($a => {
      $a.addEventListener('click', () => {
        const q = $a.dataset.quick
        if (q === 'msg') {
          // vai pra aba de Mensagens (QR)
          const $tabMsgs = document.querySelector('.tabs > button[data-tab="qr"]')
          if ($tabMsgs) $tabMsgs.click()
        } else if (q === 'agendar') {
          modalAgenda()
        } else if (q === 'lembrete') {
          modalLembrete()
        } else if (q === 'evento') {
          // Vai pro calendário e abre modal de evento
          const $tabCal = document.querySelector('.tabs > button[data-tab="cal"]')
          if ($tabCal) {
            $tabCal.click()
            setTimeout(() => {
              const $btn = document.getElementById('bsb-cal-novo')
              if ($btn) $btn.click()
            }, 200)
          }
        } else if (q === 'ia') {
          const $tabIa = document.querySelector('.tabs > button[data-tab="ia"]')
          if ($tabIa) $tabIa.click()
        } else if (q === 'nota') {
          // Vai pra notas e abre criação
          const $btnNotas = document.querySelector('#bsb-contact-tabs button[data-sub="notas"]')
          if ($btnNotas) {
            $btnNotas.click()
            setTimeout(() => {
              const $btnNova = document.getElementById('bsb-nota-nova')
              if ($btnNova) $btnNova.click()
            }, 200)
          }
        }
      })
    })

    // Detalhes
    const $copyNum = $p.querySelector('[data-act="copy-num"]')
    if ($copyNum) $copyNum.addEventListener('click', async (e) => {
      e.stopPropagation()
      try { await navigator.clipboard.writeText(num); mostrarToast('📋 Número copiado', 'sucesso', 1500) } catch {}
    })
    const $copyLink = $p.querySelector('[data-act="copy-link"]')
    if ($copyLink) $copyLink.addEventListener('click', async (e) => {
      e.stopPropagation()
      try { await navigator.clipboard.writeText(`https://wa.me/${num}`); mostrarToast('🔗 Link copiado', 'sucesso', 1500) } catch {}
    })
    const $crm = $p.querySelector('[data-act="open-crm-chat"]')
    if ($crm) $crm.addEventListener('click', () => {
      chrome.runtime.sendMessage({ type: 'BRANORTE_SIDEBAR_ACTION', action: 'open-crm' })
    })
  }

  // ----- Notas -----
  let notasCache = []
  async function renderNotas() {
    const $p = document.getElementById('bsb-sub-notas')
    if (!$p) return
    if (!chatAtivo) {
      $p.innerHTML = `<div class="bsb-empty" style="padding:30px 16px;">Abre um chat pra adicionar notas.</div>`
      return
    }
    $p.innerHTML = `
      <div class="bsb-cc-tools">
        <button id="bsb-nota-nova" class="bsb-cc-primary">+ Nova nota</button>
      </div>
      <div class="bsb-cc-list" id="bsb-notas-list">
        <div class="bsb-loading"><div class="bsb-spin"></div>Carregando…</div>
      </div>`
    document.getElementById('bsb-nota-nova').addEventListener('click', () => modalNota(null))
    await carregarNotas()
  }
  async function carregarNotas() {
    const $l = document.getElementById('bsb-notas-list')
    if (!$l || !chatAtivo) return
    try {
      const j = await hubFetch('notes', { query: { chat_id: chatAtivo.id } })
      notasCache = j.items || []
      renderListaNotas()
    } catch (e) {
      $l.innerHTML = `<div class="bsb-empty">⚠️ ${escapeHtml(e.message)}</div>`
    }
  }
  function renderListaNotas() {
    const $l = document.getElementById('bsb-notas-list')
    if (!$l) return
    if (notasCache.length === 0) {
      $l.innerHTML = `<div class="bsb-cc-empty">📝 Sem anotações ainda. Clica em <b>+ Nova nota</b>.</div>`
      return
    }
    $l.innerHTML = notasCache.map(n => `
      <div class="bsb-cc-card ${n.is_pinned ? 'pinned' : ''}" data-id="${n.id}">
        <div class="bsb-cc-card-body">${escapeHtml(n.body || '').replace(/\n/g, '<br>')}</div>
        <div class="bsb-cc-card-foot">
          <span class="bsb-cc-time">${fmtDataHora(n.created_at)}</span>
          <div class="bsb-cc-card-actions">
            <button data-a="pin" title="${n.is_pinned ? 'Desafixar' : 'Fixar'}">${n.is_pinned ? '📌' : '📍'}</button>
            <button data-a="edit" title="Editar">✏️</button>
            <button data-a="del" title="Apagar">🗑️</button>
          </div>
        </div>
      </div>`).join('')
    $l.querySelectorAll('.bsb-cc-card').forEach($c => {
      const id = $c.dataset.id
      const nota = notasCache.find(x => x.id === id)
      $c.querySelector('[data-a="pin"]').addEventListener('click', async () => {
        try {
          await hubFetch('notes', { method: 'POST', body: { id, is_pinned: !nota.is_pinned } })
          await carregarNotas()
        } catch (e) { mostrarToast('❌ ' + e.message, 'erro') }
      })
      $c.querySelector('[data-a="edit"]').addEventListener('click', () => modalNota(nota))
      $c.querySelector('[data-a="del"]').addEventListener('click', async () => {
        if (!confirm('Apagar essa nota?')) return
        try {
          await hubFetch('notes', { method: 'DELETE', query: { id } })
          mostrarToast('🗑️ Apagada', 'sucesso')
          await carregarNotas()
        } catch (e) { mostrarToast('❌ ' + e.message, 'erro') }
      })
    })
  }
  function modalNota(notaExistente) {
    const overlay = document.createElement('div')
    overlay.className = 'bsb-qr-modal-overlay'
    overlay.innerHTML = `
      <div class="bsb-qr-modal" style="width:480px">
        <div class="bsb-qr-modal-head">
          <span>${notaExistente ? '✏️ Editar nota' : '📝 Nova nota'} · ${escapeHtml(chatAtivo?.name || '')}</span>
          <button class="bsb-qr-modal-close">✕</button>
        </div>
        <div class="bsb-qr-modal-body">
          <div class="bsb-qr-modal-row">
            <label>Anotação</label>
            <textarea id="bsb-nota-body" rows="6" placeholder="Cliente preferiu boleto, vai responder semana que vem…"></textarea>
          </div>
          <div class="bsb-qr-modal-row">
            <label class="bsb-qr-checkbox-row">
              <input type="checkbox" id="bsb-nota-pin" />
              <span>📌 Fixar no topo</span>
            </label>
          </div>
        </div>
        <div class="bsb-qr-modal-foot">
          <span></span>
          <div style="display:flex;gap:8px">
            <button class="bsb-qr-btn-cancel">Cancelar</button>
            <button class="bsb-qr-btn-save">💾 Salvar</button>
          </div>
        </div>
      </div>`
    document.body.appendChild(overlay)
    const $body = overlay.querySelector('#bsb-nota-body')
    const $pin = overlay.querySelector('#bsb-nota-pin')
    if (notaExistente) { $body.value = notaExistente.body || ''; $pin.checked = !!notaExistente.is_pinned }
    $body.focus()
    const fechar = () => overlay.remove()
    overlay.querySelector('.bsb-qr-modal-close').addEventListener('click', fechar)
    overlay.querySelector('.bsb-qr-btn-cancel').addEventListener('click', fechar)
    overlay.addEventListener('click', e => { if (e.target === overlay) fechar() })
    overlay.querySelector('.bsb-qr-btn-save').addEventListener('click', async () => {
      if (!$body.value.trim()) { mostrarToast('⚠️ Texto vazio', 'erro'); return }
      const cfg = await chrome.storage.local.get(['vendedor_nome'])
      try {
        await hubFetch('notes', {
          method: 'POST',
          body: {
            id: notaExistente?.id,
            vendedor_nome: cfg.vendedor_nome,
            chat_id: chatAtivo.id,
            contato_nome: chatAtivo.name || '',
            contato_numero: numeroValidoChat(chatAtivo) || '',
            body: $body.value,
            is_pinned: $pin.checked,
          },
        })
        mostrarToast('✅ ' + (notaExistente ? 'Atualizada' : 'Salva'), 'sucesso')
        fechar()
        await carregarNotas()
      } catch (e) { mostrarToast('❌ ' + e.message, 'erro') }
    })
  }

  // ----- Agenda (mensagens agendadas) -----
  async function renderAgenda() {
    const $p = document.getElementById('bsb-sub-agenda')
    if (!$p) return
    if (!chatAtivo) {
      $p.innerHTML = `<div class="bsb-empty" style="padding:30px 16px;">Abre um chat pra agendar mensagem.</div>`
      return
    }
    $p.innerHTML = `
      <div class="bsb-cc-tools">
        <button id="bsb-agenda-nova" class="bsb-cc-primary">+ Agendar mensagem</button>
      </div>
      <div class="bsb-cc-list" id="bsb-agenda-list">
        <div class="bsb-loading"><div class="bsb-spin"></div>Carregando…</div>
      </div>`
    document.getElementById('bsb-agenda-nova').addEventListener('click', () => modalAgenda())
    await carregarAgenda()
  }
  let agendaCache = []
  async function carregarAgenda() {
    const $l = document.getElementById('bsb-agenda-list')
    if (!$l || !chatAtivo) return
    try {
      const j = await hubFetch('scheduled', { query: { chat_id: chatAtivo.id } })
      agendaCache = j.items || []
      renderListaAgenda()
    } catch (e) {
      $l.innerHTML = `<div class="bsb-empty">⚠️ ${escapeHtml(e.message)}</div>`
    }
  }
  async function renderListaAgenda() {
    const $l = document.getElementById('bsb-agenda-list')
    if (!$l) return
    if (agendaCache.length === 0) {
      $l.innerHTML = `<div class="bsb-cc-empty">⏰ Nenhuma mensagem agendada.</div>`
      return
    }
    const statusEmoji = { pending: '⏳', sent: '✅', failed: '❌', canceled: '🚫' }

    // Pré-checa mídia local pra cada agendamento (storage local)
    const keys = agendaCache.map(m => 'sched_media_' + m.id)
    const stored = await chrome.storage.local.get(keys).catch(() => ({}))

    $l.innerHTML = agendaCache.map(m => {
      const diff = new Date(m.scheduled_at).getTime() - Date.now()
      const tempoStr = diff > 0 ? `em ${fmtDuracao(diff)}` : 'já passou'
      // Prioridade: media_url do registro (cloud); fallback: chrome.storage local (legado)
      const localMedia = stored['sched_media_' + m.id]
      const mediaTipo = m.media_url ? m.media_type : localMedia?.mediaType
      const midiaIcone = mediaTipo ? {
        image: '🖼️', video: '🎥', audio: '🎵', document: '📎',
      }[mediaTipo] || '📎' : ''
      return `
      <div class="bsb-cc-card status-${m.status}" data-id="${m.id}">
        <div class="bsb-cc-card-tag">${statusEmoji[m.status] || ''} ${escapeHtml(m.status)}${midiaIcone ? ' · ' + midiaIcone + ' c/ mídia' : ''}</div>
        <div class="bsb-cc-card-body">${escapeHtml((m.body || '').slice(0, 200))}</div>
        <div class="bsb-cc-card-foot">
          <span class="bsb-cc-time">📅 ${fmtDataHora(m.scheduled_at)} · ${tempoStr}</span>
          <div class="bsb-cc-card-actions">
            ${m.status === 'pending' ? '<button data-a="cancel" title="Cancelar">🚫</button>' : ''}
            <button data-a="del" title="Apagar">🗑️</button>
          </div>
        </div>
      </div>`
    }).join('')
    $l.querySelectorAll('.bsb-cc-card').forEach($c => {
      const id = $c.dataset.id
      const $cancel = $c.querySelector('[data-a="cancel"]')
      if ($cancel) $cancel.addEventListener('click', async () => {
        try {
          await hubFetch('scheduled', { method: 'PATCH', query: { id }, body: { status: 'canceled' } })
          await carregarAgenda()
        } catch (e) { mostrarToast('❌ ' + e.message, 'erro') }
      })
      $c.querySelector('[data-a="del"]').addEventListener('click', async () => {
        if (!confirm('Apagar?')) return
        try {
          await hubFetch('scheduled', { method: 'DELETE', query: { id } })
          // Limpa mídia local atrelada
          await chrome.storage.local.remove('sched_media_' + id).catch(() => {})
          await carregarAgenda()
        } catch (e) { mostrarToast('❌ ' + e.message, 'erro') }
      })
    })
  }
  async function modalAgenda() {
    const overlay = document.createElement('div')
    overlay.className = 'bsb-qr-modal-overlay'
    const agora = new Date()
    agora.setMinutes(agora.getMinutes() + 30)
    const localISO = new Date(agora.getTime() - agora.getTimezoneOffset() * 60000).toISOString().slice(0, 16)
    overlay.innerHTML = `
      <div class="bsb-qr-modal" style="width:520px">
        <div class="bsb-qr-modal-head">
          <span>⏰ Agendar mensagem · ${escapeHtml(chatAtivo?.name || '')}</span>
          <button class="bsb-qr-modal-close">✕</button>
        </div>
        <div class="bsb-qr-modal-body">
          <div class="bsb-qr-modal-row">
            <label>📑 Usar mensagem rápida <small>(opcional)</small></label>
            <select id="bsb-agenda-qr">
              <option value="">— Escolher uma QR pra preencher abaixo —</option>
            </select>
          </div>
          <div class="bsb-qr-modal-row">
            <label>Mensagem</label>
            <textarea id="bsb-agenda-body" rows="4" placeholder="Olá! Passando pra saber se já decidiu sobre o orçamento…"></textarea>
          </div>
          <div class="bsb-qr-modal-row">
            <label>🎬 Mídia <small>(opcional · enviada junto)</small></label>
            <div class="bsb-mqr-media-bar">
              <button type="button" class="bsb-mqr-media-btn" data-acc="image/*" data-mt="image">📷 Imagem</button>
              <button type="button" class="bsb-mqr-media-btn" data-acc="video/*" data-mt="video">🎥 Vídeo</button>
              <button type="button" class="bsb-mqr-media-btn" data-acc="audio/*" data-mt="audio">🎵 Áudio</button>
              <button type="button" class="bsb-mqr-media-btn" data-acc="*/*" data-mt="document">📎 Arquivo</button>
              <button type="button" class="bsb-mqr-media-btn bsb-mqr-rec-btn" id="bsb-agenda-rec">🎤 Gravar</button>
            </div>
            <input type="file" id="bsb-agenda-file" style="display:none" />
            <div id="bsb-agenda-media-preview" class="bsb-mqr-media-preview" style="display:none"></div>
          </div>
          <div class="bsb-qr-modal-row">
            <label>📅 Data e hora do envio</label>
            <input type="datetime-local" id="bsb-agenda-when" value="${localISO}" />
          </div>
          <div class="bsb-qr-modal-row">
            <label>⚡ Atalhos rápidos</label>
            <div style="display:flex;gap:6px;flex-wrap:wrap">
              <button class="bsb-cc-quick" data-min="60">+1h</button>
              <button class="bsb-cc-quick" data-min="180">+3h</button>
              <button class="bsb-cc-quick" data-min="1440">Amanhã</button>
              <button class="bsb-cc-quick" data-min="4320">+3 dias</button>
              <button class="bsb-cc-quick" data-min="10080">+1 semana</button>
            </div>
          </div>
        </div>
        <div class="bsb-qr-modal-foot">
          <span style="font-size:11px;color:#9ca3af">⚠️ Seu PC precisa estar ligado na hora</span>
          <div style="display:flex;gap:8px">
            <button class="bsb-qr-btn-cancel">Cancelar</button>
            <button class="bsb-qr-btn-save">📤 Agendar</button>
          </div>
        </div>
      </div>`
    document.body.appendChild(overlay)
    const $body = overlay.querySelector('#bsb-agenda-body')
    const $when = overlay.querySelector('#bsb-agenda-when')
    const $qrSel = overlay.querySelector('#bsb-agenda-qr')
    const $fileInput = overlay.querySelector('#bsb-agenda-file')
    const $preview = overlay.querySelector('#bsb-agenda-media-preview')
    const $recBtn = overlay.querySelector('#bsb-agenda-rec')

    // ===== Carrega QRs do vendedor pro dropdown =====
    if (quickReplies.length === 0) await carregarQR().catch(() => {})
    if (quickReplies.length > 0) {
      // Agrupa por categoria
      const grupos = new Map()
      for (const qr of quickReplies) {
        const cat = (qr.category || 'GERAL').toUpperCase()
        if (!grupos.has(cat)) grupos.set(cat, [])
        grupos.get(cat).push(qr)
      }
      const html = ['<option value="">— Escolher uma QR pra preencher abaixo —</option>']
      for (const [cat, lista] of grupos) {
        html.push(`<optgroup label="${escapeHtml(cat)}">`)
        for (const qr of lista) {
          html.push(`<option value="${escapeHtml(qr.id)}">${escapeHtml(qr.title)}${qr.slug ? ' (/'+escapeHtml(qr.slug)+')' : ''}</option>`)
        }
        html.push('</optgroup>')
      }
      $qrSel.innerHTML = html.join('')
    }

    // Quando seleciona QR: copia body + carrega mídia se tiver
    $qrSel.addEventListener('change', async () => {
      const id = $qrSel.value
      if (!id) return
      const qr = quickReplies.find(q => q.id === id)
      if (!qr) return
      // Substitui variáveis básicas
      const nome = chatAtivo?.name || chatAtivo?.number || ''
      const primeiro = nome.split(/\s+/)[0] || ''
      const PLACEHOLDER_RE = /^(🖼️ Imagem|🎥 Vídeo|🎵 Áudio|📎 Arquivo|📎 Mídia) · /
      // Carrega mídia da QR se tiver
      try {
        const k = 'qr_media_' + qr.id
        const stored = await chrome.storage.local.get(k)
        if (stored[k]) {
          modalMedia = { ...stored[k] }
          renderMediaPreview()
          // Se body é placeholder, limpa
          if (PLACEHOLDER_RE.test(qr.body || '')) {
            $body.value = ''
            return
          }
        }
      } catch (_) {}
      $body.value = (qr.body || '')
        .replace(/\{\{nome\}\}/gi, nome)
        .replace(/\{\{primeiro_nome\}\}/gi, primeiro)
    })

    // ===== Mídia (mesma lógica do modalNovaQR) =====
    let modalMedia = null
    let mediaRecorder = null
    let recChunks = []
    let recStream = null

    function renderMediaPreview() {
      if (!modalMedia) {
        $preview.style.display = 'none'
        $preview.innerHTML = ''
        return
      }
      const { dataUrl, mediaType, filename, sizeKB } = modalMedia
      let inner = ''
      if (mediaType === 'image') inner = `<img src="${dataUrl}" alt="" />`
      else if (mediaType === 'video') inner = `<video src="${dataUrl}" controls preload="metadata"></video>`
      else if (mediaType === 'audio') inner = `<audio src="${dataUrl}" controls></audio>`
      else inner = `<div class="bsb-mqr-media-doc">📎 ${escapeHtml(filename)}</div>`
      $preview.innerHTML = `
        ${inner}
        <div class="bsb-mqr-media-info">
          <span>${escapeHtml(filename)} · ${sizeKB} KB</span>
          <button type="button" class="bsb-mqr-media-remove" title="Remover">✕</button>
        </div>`
      $preview.style.display = 'block'
      $preview.querySelector('.bsb-mqr-media-remove').addEventListener('click', () => {
        modalMedia = null
        renderMediaPreview()
      })
    }

    function fileToDataUrl(file) {
      return new Promise((res, rej) => {
        const r = new FileReader()
        r.onload = () => res(r.result)
        r.onerror = () => rej(r.error)
        r.readAsDataURL(file)
      })
    }

    async function processarArquivo(file, mediaType) {
      if (!file) return
      const sizeKB = Math.round(file.size / 1024)
      if (sizeKB > 10240) {
        mostrarToast(`❌ Arquivo muito grande (${(sizeKB/1024).toFixed(1)} MB) — máx 10 MB`, 'erro', 4000)
        return
      }
      try {
        const dataUrl = await fileToDataUrl(file)
        modalMedia = { dataUrl, mediaType, filename: file.name || 'arquivo', sizeKB }
        renderMediaPreview()
      } catch (e) {
        mostrarToast('❌ Erro ao ler arquivo: ' + e.message, 'erro')
      }
    }

    overlay.querySelectorAll('.bsb-mqr-media-btn:not(.bsb-mqr-rec-btn)').forEach(btn => {
      btn.addEventListener('click', () => {
        $fileInput.value = ''
        $fileInput.accept = btn.dataset.acc
        $fileInput.dataset.mt = btn.dataset.mt
        $fileInput.click()
      })
    })
    $fileInput.addEventListener('change', (e) => {
      const f = e.target.files?.[0]
      if (f) processarArquivo(f, $fileInput.dataset.mt || 'document')
    })

    // Botão de gravação
    $recBtn.addEventListener('click', async () => {
      if (mediaRecorder && mediaRecorder.state === 'recording') {
        mediaRecorder.stop()
        return
      }
      try {
        recStream = await navigator.mediaDevices.getUserMedia({ audio: true })
      } catch (e) {
        mostrarToast('❌ Sem permissão de microfone', 'erro', 4500)
        return
      }
      recChunks = []
      const mime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus') ? 'audio/webm;codecs=opus' : 'audio/webm'
      mediaRecorder = new MediaRecorder(recStream, { mimeType: mime })
      mediaRecorder.ondataavailable = (ev) => { if (ev.data?.size) recChunks.push(ev.data) }
      mediaRecorder.onstop = async () => {
        try {
          // WebM/Opus é o formato nativo do WhatsApp pra PTT.
          // Manda direto (sem converter) - wa-js empacota como voice note
          // quando background.js usa isPtt: true + waveform: true.
          const audioBlob = new Blob(recChunks, { type: 'audio/webm; codecs=opus' })
          const dataUrl = await new Promise((res, rej) => {
            const r = new FileReader()
            r.onload = () => res(r.result)
            r.onerror = () => rej(r.error)
            r.readAsDataURL(audioBlob)
          })
          const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)
          modalMedia = {
            dataUrl,
            mediaType: 'audio',
            filename: `audio-${ts}.opus`,
            sizeKB: Math.round(audioBlob.size / 1024),
          }
          renderMediaPreview()
        } finally {
          recStream?.getTracks().forEach(t => t.stop())
          recStream = null
          $recBtn.classList.remove('is-recording')
          $recBtn.textContent = '🎤 Gravar'
        }
      }
      mediaRecorder.start()
      $recBtn.classList.add('is-recording')
      $recBtn.textContent = '⏹️ Parar gravação'
    })

    // Atalhos de tempo
    overlay.querySelectorAll('.bsb-cc-quick').forEach(b => {
      b.addEventListener('click', () => {
        const min = parseInt(b.dataset.min, 10)
        const dt = new Date(Date.now() + min * 60000)
        $when.value = new Date(dt.getTime() - dt.getTimezoneOffset() * 60000).toISOString().slice(0, 16)
      })
    })

    $body.focus()
    const fechar = () => overlay.remove()
    overlay.querySelector('.bsb-qr-modal-close').addEventListener('click', fechar)
    overlay.querySelector('.bsb-qr-btn-cancel').addEventListener('click', fechar)
    overlay.addEventListener('click', e => { if (e.target === overlay) fechar() })

    overlay.querySelector('.bsb-qr-btn-save').addEventListener('click', async () => {
      if (!$body.value.trim() && !modalMedia) {
        mostrarToast('⚠️ Mensagem ou mídia obrigatória', 'erro')
        return
      }
      if (!$when.value) { mostrarToast('⚠️ Data inválida', 'erro'); return }
      const cfg = await chrome.storage.local.get(['vendedor_nome'])
      const scheduled_at = new Date($when.value).toISOString()

      let body = $body.value
      if (!body.trim() && modalMedia) {
        const labels = { image: '🖼️ Imagem', video: '🎥 Vídeo', audio: '🎵 Áudio', document: '📎 Arquivo' }
        body = `${labels[modalMedia.mediaType] || '📎 Mídia'} · ${modalMedia.filename}`
      }

      const payload = {
        vendedor_nome: cfg.vendedor_nome,
        chat_id: chatAtivo.id,
        contato_nome: chatAtivo.name || '',
        contato_numero: numeroValidoChat(chatAtivo) || '',
        body,
        scheduled_at,
      }

      // Upload da mídia pro Supabase Storage (se for nova)
      if (modalMedia) {
        if (modalMedia.dataUrl && !modalMedia.url) {
          try {
            mostrarToast('⏳ Subindo mídia…', 'aviso', 2000)
            const upRes = await uploadMidiaParaBucket(modalMedia, cfg.vendedor_nome)
            payload.media_url = upRes.url
            payload.media_type = modalMedia.mediaType
            payload.media_filename = modalMedia.filename
            payload.media_size_kb = upRes.size_kb
          } catch (e) {
            mostrarToast('❌ Falha no upload: ' + e.message, 'erro', 4500)
            return
          }
        } else if (modalMedia.url) {
          payload.media_url = modalMedia.url
          payload.media_type = modalMedia.mediaType
          payload.media_filename = modalMedia.filename
          payload.media_size_kb = modalMedia.sizeKB
        }
      }

      try {
        await hubFetch('scheduled', { method: 'POST', body: payload })
        mostrarToast('⏰ Agendada', 'sucesso')
        fechar()
        await carregarAgenda()
      } catch (e) { mostrarToast('❌ ' + e.message, 'erro') }
    })
  }

  // ----- Lembretes -----
  async function renderLembrete() {
    const $p = document.getElementById('bsb-sub-lembrete')
    if (!$p) return
    $p.innerHTML = `
      <div class="bsb-cc-tools">
        <button id="bsb-rem-novo" class="bsb-cc-primary">+ Criar lembrete</button>
      </div>
      <div class="bsb-cc-list" id="bsb-rem-list">
        <div class="bsb-loading"><div class="bsb-spin"></div>Carregando…</div>
      </div>`
    document.getElementById('bsb-rem-novo').addEventListener('click', () => modalLembrete())
    await carregarLembretes()
  }
  let lembretesCache = []
  async function carregarLembretes() {
    const $l = document.getElementById('bsb-rem-list')
    if (!$l) return
    try {
      const cfg = await chrome.storage.local.get(['vendedor_nome'])
      const query = { vendedor: cfg.vendedor_nome || '' }
      if (chatAtivo?.id) query.chat_id = chatAtivo.id
      const j = await hubFetch('reminders', { query })
      lembretesCache = j.items || []
      renderListaLembretes()
    } catch (e) {
      $l.innerHTML = `<div class="bsb-empty">⚠️ ${escapeHtml(e.message)}</div>`
    }
  }
  function renderListaLembretes() {
    const $l = document.getElementById('bsb-rem-list')
    if (!$l) return
    if (lembretesCache.length === 0) {
      $l.innerHTML = `<div class="bsb-cc-empty">🔔 Sem lembretes.</div>`
      return
    }
    $l.innerHTML = lembretesCache.map(r => {
      const diff = new Date(r.remind_at).getTime() - Date.now()
      const status = r.status === 'done' ? '✅' : r.status === 'dismissed' ? '🚫' : (diff < 0 ? '⏰' : '⏳')
      const tempoStr = diff > 0 ? `em ${fmtDuracao(diff)}` : (r.status === 'pending' ? 'AGORA' : '')
      return `
      <div class="bsb-cc-card status-${r.status}" data-id="${r.id}">
        <div class="bsb-cc-card-tag">${status} ${escapeHtml(r.status)}</div>
        <div class="bsb-cc-card-title-strong">${escapeHtml(r.title || '')}</div>
        ${r.body ? `<div class="bsb-cc-card-body">${escapeHtml(r.body)}</div>` : ''}
        ${r.contato_nome ? `<div class="bsb-cc-card-sub">👤 ${escapeHtml(r.contato_nome)}</div>` : ''}
        <div class="bsb-cc-card-foot">
          <span class="bsb-cc-time">⏰ ${fmtDataHora(r.remind_at)} · ${tempoStr}</span>
          <div class="bsb-cc-card-actions">
            ${r.status === 'pending' ? '<button data-a="done" title="Marcar feito">✅</button>' : ''}
            <button data-a="del" title="Apagar">🗑️</button>
          </div>
        </div>
      </div>`
    }).join('')
    $l.querySelectorAll('.bsb-cc-card').forEach($c => {
      const id = $c.dataset.id
      const $done = $c.querySelector('[data-a="done"]')
      if ($done) $done.addEventListener('click', async () => {
        try {
          await hubFetch('reminders', { method: 'PATCH', query: { id }, body: { status: 'done', done_at: new Date().toISOString() } })
          await carregarLembretes()
        } catch (e) { mostrarToast('❌ ' + e.message, 'erro') }
      })
      $c.querySelector('[data-a="del"]').addEventListener('click', async () => {
        if (!confirm('Apagar?')) return
        try {
          await hubFetch('reminders', { method: 'DELETE', query: { id } })
          await carregarLembretes()
        } catch (e) { mostrarToast('❌ ' + e.message, 'erro') }
      })
    })
  }
  function modalLembrete() {
    const overlay = document.createElement('div')
    overlay.className = 'bsb-qr-modal-overlay'
    const dt = new Date(Date.now() + 60 * 60000)
    const localISO = new Date(dt.getTime() - dt.getTimezoneOffset() * 60000).toISOString().slice(0, 16)
    const ctxChat = chatAtivo ? `📞 ${chatAtivo.name || chatAtivo.number}` : 'sem contato vinculado'
    overlay.innerHTML = `
      <div class="bsb-qr-modal" style="width:480px">
        <div class="bsb-qr-modal-head">
          <span>🔔 Novo lembrete · ${escapeHtml(ctxChat)}</span>
          <button class="bsb-qr-modal-close">✕</button>
        </div>
        <div class="bsb-qr-modal-body">
          <div class="bsb-qr-modal-row">
            <label>Título</label>
            <input id="bsb-rem-title" maxlength="120" placeholder="Ligar pro João pra confirmar pedido" />
          </div>
          <div class="bsb-qr-modal-row">
            <label>Detalhes <small>(opcional)</small></label>
            <textarea id="bsb-rem-body" rows="3" placeholder="..."></textarea>
          </div>
          <div class="bsb-qr-modal-row">
            <label>Quando me lembrar?</label>
            <input type="datetime-local" id="bsb-rem-when" value="${localISO}" />
          </div>
          <div class="bsb-qr-modal-row">
            <div style="display:flex;gap:6px;flex-wrap:wrap">
              <button class="bsb-cc-quick" data-min="30">+30min</button>
              <button class="bsb-cc-quick" data-min="120">+2h</button>
              <button class="bsb-cc-quick" data-min="1440">Amanhã</button>
              <button class="bsb-cc-quick" data-min="4320">+3 dias</button>
              <button class="bsb-cc-quick" data-min="10080">+1 semana</button>
            </div>
          </div>
          <div class="bsb-qr-modal-row">
            <label class="bsb-qr-checkbox-row">
              <input type="checkbox" id="bsb-rem-self" checked />
              <span>📲 Enviar lembrete pro meu WhatsApp (aparece no celular)</span>
            </label>
          </div>
        </div>
        <div class="bsb-qr-modal-foot">
          <span style="font-size:10.5px;color:#9ca3af">🔔 Notificação no Chrome + 📲 mensagem no celular</span>
          <div style="display:flex;gap:8px">
            <button class="bsb-qr-btn-cancel">Cancelar</button>
            <button class="bsb-qr-btn-save">🔔 Criar</button>
          </div>
        </div>
      </div>`
    document.body.appendChild(overlay)
    const $title = overlay.querySelector('#bsb-rem-title')
    const $body = overlay.querySelector('#bsb-rem-body')
    const $when = overlay.querySelector('#bsb-rem-when')
    const $self = overlay.querySelector('#bsb-rem-self')
    overlay.querySelectorAll('.bsb-cc-quick').forEach(b => {
      b.addEventListener('click', () => {
        const min = parseInt(b.dataset.min, 10)
        const dtq = new Date(Date.now() + min * 60000)
        $when.value = new Date(dtq.getTime() - dtq.getTimezoneOffset() * 60000).toISOString().slice(0, 16)
      })
    })
    $title.focus()
    const fechar = () => overlay.remove()
    overlay.querySelector('.bsb-qr-modal-close').addEventListener('click', fechar)
    overlay.querySelector('.bsb-qr-btn-cancel').addEventListener('click', fechar)
    overlay.addEventListener('click', e => { if (e.target === overlay) fechar() })
    overlay.querySelector('.bsb-qr-btn-save').addEventListener('click', async () => {
      if (!$title.value.trim()) { mostrarToast('⚠️ Título obrigatório', 'erro'); return }
      const cfg = await chrome.storage.local.get(['vendedor_nome'])
      try {
        await hubFetch('reminders', {
          method: 'POST',
          body: {
            vendedor_nome: cfg.vendedor_nome,
            chat_id: chatAtivo?.id || null,
            contato_nome: chatAtivo?.name || null,
            contato_numero: numeroValidoChat(chatAtivo),
            title: $title.value,
            body: $body.value || null,
            remind_at: new Date($when.value).toISOString(),
            notify_self: $self.checked,
          },
        })
        mostrarToast('🔔 Lembrete criado', 'sucesso')
        fechar()
        await carregarLembretes()
      } catch (e) { mostrarToast('❌ ' + e.message, 'erro') }
    })
  }

  // ================================================================
  // ABA CALENDÁRIO (interno, sem Google)
  // ================================================================
  let calMesAtual = new Date()  // qualquer dia do mês visualizado
  calMesAtual.setDate(1)
  let calDiaSelecionado = new Date()
  let calEventos = { msg: [], rem: [], evt: [] }

  async function carregarCalendario() {
    try {
      const cfg = await chrome.storage.local.get(['vendedor_nome'])
      if (!cfg.vendedor_nome) return
      const ven = cfg.vendedor_nome
      const [j1, j2, j3] = await Promise.all([
        hubFetch('scheduled', { query: { vendedor: ven } }).catch(() => ({ items: [] })),
        hubFetch('reminders', { query: { vendedor: ven } }).catch(() => ({ items: [] })),
        hubFetch('calendar',  { query: { vendedor: ven } }).catch(() => ({ items: [] })),
      ])
      calEventos = {
        msg: j1.items || [],
        rem: j2.items || [],
        evt: j3.items || [],
      }
      renderCalendarioGrid()
      renderCalendarioDia()
    } catch (e) {
      console.error('[cal] erro', e)
    }
  }

  function eventosDoDia(dataISO) {
    // dataISO = "YYYY-MM-DD" local
    const dia = dataISO
    const noDia = (iso) => iso && new Date(iso).toLocaleDateString('sv-SE') === dia
    return [
      ...calEventos.msg.filter(m => noDia(m.scheduled_at)).map(m => ({ tipo: 'msg', data: m })),
      ...calEventos.rem.filter(r => noDia(r.remind_at)).map(r => ({ tipo: 'rem', data: r })),
      ...calEventos.evt.filter(e => noDia(e.starts_at)).map(e => ({ tipo: 'evt', data: e })),
    ]
  }

  function diasComEventos() {
    const set = new Set()
    const add = (iso) => { if (iso) set.add(new Date(iso).toLocaleDateString('sv-SE')) }
    calEventos.msg.forEach(m => add(m.scheduled_at))
    calEventos.rem.forEach(r => add(r.remind_at))
    calEventos.evt.forEach(e => add(e.starts_at))
    return set
  }

  function renderCalendarioGrid() {
    const $titulo = document.getElementById('bsb-cal-titulo')
    const $grid = document.getElementById('bsb-cal-grid')
    if (!$titulo || !$grid) return
    const meses = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
                   'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro']
    const ano = calMesAtual.getFullYear()
    const mes = calMesAtual.getMonth()
    $titulo.textContent = `${meses[mes]} ${ano}`

    const primeiroDia = new Date(ano, mes, 1)
    const ultimoDia = new Date(ano, mes + 1, 0)
    const totalDias = ultimoDia.getDate()
    // Domingo = 0; queremos começar segunda
    const offset = (primeiroDia.getDay() + 6) % 7  // segunda=0, domingo=6

    const headers = ['S', 'T', 'Q', 'Q', 'S', 'S', 'D']
    let html = headers.map(h => `<div class="bsb-cal-h">${h}</div>`).join('')

    // Espaços vazios antes do dia 1
    for (let i = 0; i < offset; i++) html += '<div class="bsb-cal-c bsb-cal-c-empty"></div>'

    const eventosDias = diasComEventos()
    const hojeISO = new Date().toLocaleDateString('sv-SE')
    const selISO = calDiaSelecionado.toLocaleDateString('sv-SE')

    for (let d = 1; d <= totalDias; d++) {
      const data = new Date(ano, mes, d)
      const iso = data.toLocaleDateString('sv-SE')
      const isHoje = iso === hojeISO
      const isSel = iso === selISO
      const tem = eventosDias.has(iso)
      const evs = tem ? eventosDoDia(iso) : []
      const dots = ['msg', 'rem', 'evt']
        .filter(t => evs.some(e => e.tipo === t))
        .map(t => `<span class="bsb-cal-dot bsb-cal-dot-${t}"></span>`)
        .join('')
      html += `
        <div class="bsb-cal-c ${isHoje ? 'hoje' : ''} ${isSel ? 'sel' : ''} ${tem ? 'tem' : ''}" data-iso="${iso}">
          <span class="bsb-cal-num">${d}</span>
          <div class="bsb-cal-dots">${dots}</div>
        </div>`
    }
    $grid.innerHTML = html
    $grid.querySelectorAll('.bsb-cal-c[data-iso]').forEach($c => {
      $c.addEventListener('click', () => {
        calDiaSelecionado = new Date($c.dataset.iso + 'T12:00:00')
        renderCalendarioGrid()
        renderCalendarioDia()
      })
    })
  }

  function renderCalendarioDia() {
    const $tit = document.getElementById('bsb-cal-dia-titulo')
    const $list = document.getElementById('bsb-cal-dia-list')
    if (!$tit || !$list) return
    const iso = calDiaSelecionado.toLocaleDateString('sv-SE')
    const fmtCompleto = calDiaSelecionado.toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' })
    $tit.textContent = fmtCompleto.charAt(0).toUpperCase() + fmtCompleto.slice(1)
    const evs = eventosDoDia(iso).sort((a, b) => {
      const ta = a.tipo === 'msg' ? a.data.scheduled_at : a.tipo === 'rem' ? a.data.remind_at : a.data.starts_at
      const tb = b.tipo === 'msg' ? b.data.scheduled_at : b.tipo === 'rem' ? b.data.remind_at : b.data.starts_at
      return new Date(ta) - new Date(tb)
    })
    if (evs.length === 0) {
      $list.innerHTML = `<div class="bsb-cc-empty">Nenhum evento neste dia</div>`
      return
    }
    const meta = {
      msg: { icon: '💬', label: 'MENSAGEM AGENDADA', cor: '#3b82f6' },
      rem: { icon: '🔔', label: 'LEMBRETE', cor: '#f59e0b' },
      evt: { icon: '📅', label: 'EVENTO', cor: '#10b981' },
    }
    $list.innerHTML = evs.map(({ tipo, data }) => {
      const m = meta[tipo]
      let titulo, sub, hora
      if (tipo === 'msg') {
        titulo = (data.body || '').slice(0, 60)
        sub = data.contato_nome || data.contato_numero || ''
        hora = new Date(data.scheduled_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
      } else if (tipo === 'rem') {
        titulo = data.title || ''
        sub = data.contato_nome || ''
        hora = new Date(data.remind_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
      } else {
        titulo = data.title || ''
        sub = data.contato_nome || data.description || ''
        hora = new Date(data.starts_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
      }
      return `
        <div class="bsb-cal-evt-card" style="border-left-color:${m.cor}">
          <div class="bsb-cal-evt-hora">${hora}</div>
          <div class="bsb-cal-evt-body">
            <div class="bsb-cal-evt-tag" style="color:${m.cor}">${m.icon} ${m.label}</div>
            <div class="bsb-cal-evt-titulo">${escapeHtml(titulo)}</div>
            ${sub ? `<div class="bsb-cal-evt-sub">${escapeHtml(sub)}</div>` : ''}
          </div>
        </div>`
    }).join('')
  }

  function modalNovoEvento() {
    const overlay = document.createElement('div')
    overlay.className = 'bsb-qr-modal-overlay'
    const dt = new Date(calDiaSelecionado)
    dt.setHours(9, 0, 0, 0)  // default 9h da manhã
    const localISO = new Date(dt.getTime() - dt.getTimezoneOffset() * 60000).toISOString().slice(0, 16)
    const dtFim = new Date(dt.getTime() + 60 * 60000)
    const localISOFim = new Date(dtFim.getTime() - dtFim.getTimezoneOffset() * 60000).toISOString().slice(0, 16)
    const ctxChat = chatAtivo ? `📞 ${chatAtivo.name || chatAtivo.number}` : 'sem contato vinculado'
    overlay.innerHTML = `
      <div class="bsb-qr-modal" style="width:480px">
        <div class="bsb-qr-modal-head">
          <span>📅 Novo evento · ${escapeHtml(ctxChat)}</span>
          <button class="bsb-qr-modal-close">✕</button>
        </div>
        <div class="bsb-qr-modal-body">
          <div class="bsb-qr-modal-row">
            <label>Título</label>
            <input id="bsb-evt-title" maxlength="120" placeholder="Visita técnica - Fazenda Sta Rosa" />
          </div>
          <div class="bsb-qr-modal-row">
            <label>Descrição <small>(opcional)</small></label>
            <textarea id="bsb-evt-desc" rows="3" placeholder="Detalhes do evento, endereço, observações…"></textarea>
          </div>
          <div class="bsb-qr-modal-row bsb-qr-modal-row-split">
            <div>
              <label>Início</label>
              <input type="datetime-local" id="bsb-evt-ini" value="${localISO}" />
            </div>
            <div>
              <label>Fim</label>
              <input type="datetime-local" id="bsb-evt-fim" value="${localISOFim}" />
            </div>
          </div>
        </div>
        <div class="bsb-qr-modal-foot">
          <span></span>
          <div style="display:flex;gap:8px">
            <button class="bsb-qr-btn-cancel">Cancelar</button>
            <button class="bsb-qr-btn-save">📅 Criar evento</button>
          </div>
        </div>
      </div>`
    document.body.appendChild(overlay)
    const $title = overlay.querySelector('#bsb-evt-title')
    const $desc = overlay.querySelector('#bsb-evt-desc')
    const $ini = overlay.querySelector('#bsb-evt-ini')
    const $fim = overlay.querySelector('#bsb-evt-fim')
    $title.focus()
    const fechar = () => overlay.remove()
    overlay.querySelector('.bsb-qr-modal-close').addEventListener('click', fechar)
    overlay.querySelector('.bsb-qr-btn-cancel').addEventListener('click', fechar)
    overlay.addEventListener('click', e => { if (e.target === overlay) fechar() })
    overlay.querySelector('.bsb-qr-btn-save').addEventListener('click', async () => {
      if (!$title.value.trim()) { mostrarToast('⚠️ Título obrigatório', 'erro'); return }
      const cfg = await chrome.storage.local.get(['vendedor_nome'])
      try {
        await hubFetch('calendar', {
          method: 'POST',
          body: {
            vendedor_nome: cfg.vendedor_nome,
            chat_id: chatAtivo?.id || null,
            contato_nome: chatAtivo?.name || null,
            contato_numero: numeroValidoChat(chatAtivo),
            title: $title.value,
            description: $desc.value || null,
            starts_at: new Date($ini.value).toISOString(),
            ends_at: $fim.value ? new Date($fim.value).toISOString() : null,
          },
        })
        mostrarToast('📅 Evento criado', 'sucesso')
        fechar()
        await carregarCalendario()
      } catch (e) { mostrarToast('❌ ' + e.message, 'erro') }
    })
  }

  // ================================================================
  // CENTRAL DE PENDÊNCIAS (lembretes + mensagens agendadas)
  // ================================================================
  async function atualizarBadgesPendencias() {
    if (!extContextValid()) { avisarContextoMorto(); return }
    try {
      const cfg = await chrome.storage.local.get(['vendedor_nome'])
      if (!cfg.vendedor_nome) return
      const ven = cfg.vendedor_nome
      const [j1, j2] = await Promise.all([
        hubFetch('reminders', { query: { vendedor: ven, status: 'pending' } }).catch(() => ({ items: [] })),
        hubFetch('scheduled', { query: { vendedor: ven, status: 'pending' } }).catch(() => ({ items: [] })),
      ])
      const $br = document.getElementById('bsb-badge-rem')
      const $ba = document.getElementById('bsb-badge-agd')
      const nr = (j1.items || []).length
      const na = (j2.items || []).length
      if ($br) {
        $br.textContent = String(nr)
        $br.style.display = nr > 0 ? 'inline-flex' : 'none'
      }
      if ($ba) {
        $ba.textContent = String(na)
        $ba.style.display = na > 0 ? 'inline-flex' : 'none'
      }
    } catch (e) {
      if (isContextErr(e)) { avisarContextoMorto(); return }
      console.error('[badges] erro', e)
    }
  }

  async function abrirCentralPendencias(tipo) {
    const cfg = await chrome.storage.local.get(['vendedor_nome'])
    if (!cfg.vendedor_nome) { mostrarToast('⚠️ Configure o vendedor primeiro', 'erro'); return }

    const overlay = document.createElement('div')
    overlay.className = 'bsb-qr-modal-overlay'
    const titulo = tipo === 'reminders' ? '🔔 Meus lembretes' : '⏰ Mensagens agendadas'
    overlay.innerHTML = `
      <div class="bsb-qr-modal" style="width:560px;max-height:80vh">
        <div class="bsb-qr-modal-head">
          <span>${titulo}</span>
          <button class="bsb-qr-modal-close">✕</button>
        </div>
        <div class="bsb-qr-modal-body" style="padding:0">
          <div class="bsb-cp-tabs">
            <button data-st="pending" class="active">⏳ Pendentes</button>
            <button data-st="done">✅ Feitos</button>
            <button data-st="all">📋 Todos</button>
          </div>
          <div class="bsb-cp-list" id="bsb-cp-list">
            <div class="bsb-loading"><div class="bsb-spin"></div>Carregando…</div>
          </div>
        </div>
      </div>`
    document.body.appendChild(overlay)

    let filtroStatus = 'pending'
    const fechar = () => overlay.remove()
    overlay.querySelector('.bsb-qr-modal-close').addEventListener('click', fechar)
    overlay.addEventListener('click', e => { if (e.target === overlay) fechar() })

    overlay.querySelectorAll('.bsb-cp-tabs button').forEach(b => {
      b.addEventListener('click', () => {
        overlay.querySelectorAll('.bsb-cp-tabs button').forEach(x => x.classList.toggle('active', x === b))
        filtroStatus = b.dataset.st
        carregar()
      })
    })

    async function carregar() {
      const $list = overlay.querySelector('#bsb-cp-list')
      $list.innerHTML = '<div class="bsb-loading"><div class="bsb-spin"></div>Carregando…</div>'
      try {
        const query = { vendedor: cfg.vendedor_nome }
        // 'done' = só status done; 'all' = sem filtro
        if (filtroStatus === 'pending') query.status = 'pending'
        else if (filtroStatus === 'done') query.status = (tipo === 'reminders' ? 'done' : 'sent')
        const j = await hubFetch(tipo, { query })
        const items = j.items || []
        if (items.length === 0) {
          $list.innerHTML = `<div class="bsb-cc-empty" style="padding:40px 20px">Nada aqui. ${filtroStatus === 'pending' ? '🎉 Sem pendências!' : ''}</div>`
          return
        }
        $list.innerHTML = items.map(item => renderItemCentral(item, tipo)).join('')
        $list.querySelectorAll('.bsb-cp-card').forEach($c => {
          const id = $c.dataset.id
          const $done = $c.querySelector('[data-a="done"]')
          if ($done) $done.addEventListener('click', async () => {
            try {
              const patch = tipo === 'reminders'
                ? { status: 'done', done_at: new Date().toISOString() }
                : { status: 'canceled' }
              await hubFetch(tipo, { method: 'PATCH', query: { id }, body: patch })
              await carregar()
              await atualizarBadgesPendencias()
            } catch (e) { mostrarToast('❌ ' + e.message, 'erro') }
          })
          const $del = $c.querySelector('[data-a="del"]')
          if ($del) $del.addEventListener('click', async () => {
            if (!confirm('Apagar?')) return
            try {
              await hubFetch(tipo, { method: 'DELETE', query: { id } })
              await carregar()
              await atualizarBadgesPendencias()
            } catch (e) { mostrarToast('❌ ' + e.message, 'erro') }
          })
        })
      } catch (e) {
        $list.innerHTML = `<div class="bsb-empty" style="padding:30px">⚠️ ${escapeHtml(e.message)}</div>`
      }
    }

    function renderItemCentral(item, tipo) {
      const isRem = tipo === 'reminders'
      const dataISO = isRem ? item.remind_at : item.scheduled_at
      const diff = new Date(dataISO).getTime() - Date.now()
      const tempoStr = diff > 0 ? `em ${fmtDuracao(diff)}` : (item.status === 'pending' ? '⏰ AGORA' : '')
      const statusEmoji = isRem
        ? { pending: '⏳', done: '✅', dismissed: '🚫' }
        : { pending: '⏳', sent: '✅', failed: '❌', canceled: '🚫' }
      return `
        <div class="bsb-cp-card status-${item.status}" data-id="${escapeHtml(item.id)}">
          <div class="bsb-cp-card-icon">${statusEmoji[item.status] || ''}</div>
          <div class="bsb-cp-card-main">
            <div class="bsb-cp-card-titulo">${escapeHtml(isRem ? (item.title || '') : (item.body || '').slice(0, 100))}</div>
            ${isRem && item.body ? `<div class="bsb-cp-card-body">${escapeHtml(item.body)}</div>` : ''}
            ${item.contato_nome ? `<div class="bsb-cp-card-sub">👤 ${escapeHtml(item.contato_nome)}</div>` : ''}
            <div class="bsb-cp-card-time">📅 ${fmtDataHora(dataISO)}${tempoStr ? ' · ' + tempoStr : ''}</div>
          </div>
          <div class="bsb-cp-card-actions">
            ${item.status === 'pending' ? `<button data-a="done" title="${isRem ? 'Marcar feito' : 'Cancelar'}">${isRem ? '✅' : '🚫'}</button>` : ''}
            <button data-a="del" title="Apagar">🗑️</button>
          </div>
        </div>`
    }

    await carregar()
  }

  function testarNotificacao() {
    chrome.runtime.sendMessage({ type: 'BRANORTE_TEST_NOTIF' }, (resp) => {
      if (resp?.ok) mostrarToast('🔊 Notificação enviada (se aceitou permissão do Chrome)', 'sucesso', 4000)
      else mostrarToast('❌ Falhou: ' + (resp?.erro || 'erro'), 'erro')
    })
  }

  // ----- Helpers -----
  function fmtDataHora(iso) {
    if (!iso) return ''
    const d = new Date(iso)
    return d.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })
  }
  function fmtDuracao(ms) {
    if (ms < 0) return 'agora'
    const min = Math.floor(ms / 60000)
    if (min < 60) return `${min}min`
    const h = Math.floor(min / 60)
    if (h < 24) return `${h}h${min % 60 ? ` ${min % 60}min` : ''}`
    const d = Math.floor(h / 24)
    return `${d}d${h % 24 ? ` ${h % 24}h` : ''}`
  }


  // ===== Export/Import de backup das mensagens rápidas =====
  async function exportarBackupQR() {
    const cfg = await chrome.storage.local.get(['vendedor_nome'])
    if (!cfg.vendedor_nome) { mostrarToast('⚠️ Configure o vendedor primeiro', 'erro'); return }
    if (quickReplies.length === 0) await carregarQR()
    if (quickReplies.length === 0) { mostrarToast('⚠️ Nenhuma mensagem pra exportar', 'erro'); return }
    const dump = {
      formato: 'branorte-crm-backup',
      versao: '1.0',
      exportado_em: new Date().toISOString(),
      vendedor_nome: cfg.vendedor_nome,
      quick_replies: quickReplies.map(qr => ({
        title: qr.title, slug: qr.slug, category: qr.category,
        body: qr.body, is_shared: qr.is_shared,
      })),
    }
    const blob = new Blob([JSON.stringify(dump, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)
    a.href = url
    a.download = `branorte-backup-${cfg.vendedor_nome}-${ts}.json`
    document.body.appendChild(a)
    a.click()
    a.remove()
    URL.revokeObjectURL(url)
    mostrarToast(`✅ ${quickReplies.length} mensagens exportadas`, 'sucesso')
  }

  async function importarBackupQR(file) {
    let data
    try {
      data = JSON.parse(await file.text())
    } catch {
      mostrarToast('❌ Arquivo não é JSON válido', 'erro', 4000)
      return
    }

    const isNosso = data.formato === 'branorte-crm-backup'
    const isWaSync = Array.isArray(data) && data[0]?.title
    const isWascript = Array.isArray(data.respostasRapidasAcao) || data.respostasRapidas

    let candidatos = []
    if (isNosso && Array.isArray(data.quick_replies)) {
      candidatos = data.quick_replies
    } else if (isWaSync) {
      candidatos = data.map(q => ({
        title: q.title, slug: q.slug,
        category: q.category || 'GERAL',
        body: q.body, is_shared: !!q.is_shared,
      }))
    } else if (isWascript) {
      mostrarToast('⚠️ Backup do Wascript: abra o CRM Kanban (📋 Atalhos → Abrir CRM) pra importar com senha.', 'aviso', 6000)
      return
    } else {
      mostrarToast('❌ Formato não reconhecido', 'erro', 4000)
      return
    }

    if (candidatos.length === 0) {
      mostrarToast('⚠️ Nenhuma mensagem no arquivo', 'erro')
      return
    }

    if (!confirm(`Importar ${candidatos.length} mensagem(ns)?\nMensagens duplicadas serão criadas duas vezes.`)) return

    const cfg = await chrome.storage.local.get(['vendedor_nome'])
    if (!cfg.vendedor_nome) { mostrarToast('⚠️ Configure o vendedor primeiro', 'erro'); return }

    mostrarToast(`📥 Importando ${candidatos.length}…`)
    let okCount = 0, falhas = 0
    for (const qr of candidatos) {
      if (!qr.title || !qr.body) { falhas++; continue }
      const payload = {
        vendedor_nome: cfg.vendedor_nome,
        title: String(qr.title).slice(0, 200),
        slug: qr.slug ? String(qr.slug).toLowerCase().replace(/[^a-z0-9_-]/g, '') : null,
        category: qr.category || 'GERAL',
        body: String(qr.body),
        is_shared: !!qr.is_shared,
      }
      try {
        const r = await fetch(QR_ENDPOINT, {
          method: 'POST',
          headers: { 'Authorization': 'Bearer ' + SECRET, 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        })
        if (r.ok) okCount++; else falhas++
      } catch { falhas++ }
    }
    mostrarToast(`✅ ${okCount} importadas${falhas ? ` · ${falhas} falhas` : ''}`, 'sucesso')
    await carregarQR()
  }

  // ===== Barra superior de etiquetas =====
  // Logo Branorte: tenta carregar PNG real; se falhar, usa SVG fallback.
  // NOTE: branorte-logo-color.png foi removida — usa a -white.png nas duas variantes.
  const LOGO_WHITE_URL = chrome.runtime.getURL('branorte-logo-white.png')
  const LOGO_COLOR_URL = LOGO_WHITE_URL
  function svgLogoFallback(norteColor) {
    return '<svg viewBox="0 0 240 42" height="22" xmlns="http://www.w3.org/2000/svg" style="display:block;">'
      + '<text x="0" y="34" font-family="Impact,Arial Black,Helvetica,sans-serif" font-size="40" font-weight="900" letter-spacing="-2" fill="#00a651">BRA</text>'
      + '<text x="86" y="34" font-family="Impact,Arial Black,Helvetica,sans-serif" font-size="40" font-weight="900" letter-spacing="-2" fill="' + norteColor + '">NORTE</text>'
      + '</svg>'
  }
  const LOGO_HTML =
    `<img class="btb-logo-img btb-logo-dark" data-fallback="dark" src="${LOGO_WHITE_URL}" alt="" />` +
    `<span class="btb-logo-svg btb-logo-svg-dark" style="display:none">${svgLogoFallback('#ffffff')}</span>` +
    `<img class="btb-logo-img btb-logo-light" data-fallback="light" src="${LOGO_COLOR_URL}" alt="" />` +
    `<span class="btb-logo-svg btb-logo-svg-light" style="display:none">${svgLogoFallback('#000000')}</span>`

  // Conecta error handlers (CSP do WA pode bloquear onerror inline)
  function conectarFallbackLogo(bar) {
    bar.querySelectorAll('img.btb-logo-img').forEach((img) => {
      img.addEventListener('error', () => {
        img.style.display = 'none'
        const tema = img.dataset.fallback
        const fb = bar.querySelector(`.btb-logo-svg-${tema}`)
        if (fb) fb.style.display = 'inline-flex'
      })
    })
  }

  function detectarTemaWA() {
    try {
      const bg = getComputedStyle(document.body).backgroundColor
      const m = bg.match(/\d+/g)
      if (!m) return 'dark'
      const [r, g, b] = m.map(Number)
      const lum = 0.299 * r + 0.587 * g + 0.114 * b
      return lum < 128 ? 'dark' : 'light'
    } catch {
      return 'dark'
    }
  }

  function aplicarTemaTopbar() {
    const tb = document.getElementById('branorte-topbar')
    if (tb) tb.dataset.theme = detectarTemaWA()
  }

  let topbarInjetado = false
  async function criarTopbar() {
    if (topbarInjetado) return
    if (!document.body) return
    topbarInjetado = true

    const bar = document.createElement('div')
    bar.id = 'branorte-topbar'
    bar.dataset.theme = detectarTemaWA()
    bar.innerHTML = `
      <span class="btb-logo">${LOGO_HTML}</span>
      <span class="btb-update" id="btb-update" style="display:none" title="Nova versão disponível"></span>
      <span class="btb-pills" id="btb-pills"><span class="btb-loading-text">carregando…</span></span>
      <button class="btb-burger" id="btb-burger" title="Pendências — agendamentos e lembretes" aria-label="Pendências">
        <svg class="btb-burger-icon btb-burger-icon-default" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
          <line x1="4" y1="7" x2="20" y2="7"/>
          <line x1="4" y1="12" x2="20" y2="12"/>
          <line x1="4" y1="17" x2="20" y2="17"/>
        </svg>
        <svg class="btb-burger-icon btb-burger-icon-bell" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
          <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/>
          <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>
        </svg>
        <span class="btb-burger-badge" id="btb-burger-badge" style="display:none" aria-live="polite">0</span>
      </button>
    `
    document.body.appendChild(bar)
    conectarFallbackLogo(bar)
    document.body.setAttribute('data-branorte-topbar', 'on')

    // Observa mudança de tema do WA (toggle dark/light) e reaplica
    const obsTema = new MutationObserver(aplicarTemaTopbar)
    obsTema.observe(document.body, { attributes: true, attributeFilter: ['class', 'data-theme', 'style'] })
    obsTema.observe(document.documentElement, { attributes: true, attributeFilter: ['class', 'data-theme', 'style'] })

    // Reage quando o background sync grava novos números (sem precisar polling)
    try {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== 'local') return
        if (changes.last_sync_at || changes.last_etiquetas) carregarEtiquetasNoTopbar()
        if (changes.update_disponivel || changes.update_versao) atualizarBannerUpdate()
      })
    } catch (_) { /* ignore — runtime indisponível */ }

    // Hamburger → abre menu rápido com contadores
    document.getElementById('btb-burger').addEventListener('click', (e) => {
      e.stopPropagation()
      abrirMenuBurger(e.currentTarget)
    })

    await carregarEtiquetasNoTopbar()
    await atualizarBadgeBurger()
    await atualizarBannerUpdate()
    // Polling de fallback a cada 30s (caso bg sync não rode por algum motivo)
    setInterval(carregarEtiquetasNoTopbar, 30_000)
    // Badge de pendências a cada 60s
    setInterval(atualizarBadgeBurger, 60_000)
    // Banner de update a cada 5min
    setInterval(atualizarBannerUpdate, 5 * 60_000)
  }

  // Banner "nova versão disponível" no topbar
  async function atualizarBannerUpdate() {
    try {
      const $ = document.getElementById('btb-update')
      if (!$) return
      const data = await chrome.storage.local.get(['update_disponivel', 'update_versao', 'update_versao_atual', 'update_download'])
      if (!data.update_disponivel || !data.update_versao) {
        $.style.display = 'none'
        return
      }
      $.style.display = 'inline-flex'
      $.innerHTML = `
        <span class="btb-update-pulse"></span>
        <span class="btb-update-txt">Nova versão <b>v${data.update_versao}</b> disponível</span>
        ${data.update_download ? `<a class="btb-update-btn" href="${data.update_download}" target="_blank" rel="noopener">Baixar</a>` : ''}
      `
      $.title = `Atual: v${data.update_versao_atual || '?'} → Nova: v${data.update_versao}. Clique no link para baixar e atualizar a extensão.`
    } catch {}
  }

  // Atualiza o badge do burger (vermelho + contagem se tiver pendências)
  let _ultimoCountBurger = { agd: 0, rem: 0 }
  async function atualizarBadgeBurger() {
    try {
      const cfg = await chrome.storage.local.get(['vendedor_nome'])
      if (!cfg.vendedor_nome) return
      const ven = cfg.vendedor_nome
      const [j1, j2] = await Promise.all([
        hubFetch('scheduled', { query: { vendedor: ven, status: 'pending' } }).catch(() => ({ items: [] })),
        hubFetch('reminders', { query: { vendedor: ven, status: 'pending' } }).catch(() => ({ items: [] })),
      ])
      const agd = (j1.items || []).length
      const rem = (j2.items || []).length
      _ultimoCountBurger = { agd, rem }
      const total = agd + rem
      const $burger = document.getElementById('btb-burger')
      const $badge = document.getElementById('btb-burger-badge')
      if (!$burger || !$badge) return
      if (total > 0) {
        $burger.classList.add('has-pendencias')
        $badge.style.display = 'inline-flex'
        $badge.textContent = total > 99 ? '99+' : String(total)
      } else {
        $burger.classList.remove('has-pendencias')
        $badge.style.display = 'none'
      }
    } catch (e) { /* silencioso */ }
  }

  function abrirMenuBurger(anchor) {
    // Toggle: se já está aberto, fecha
    const existing = document.getElementById('btb-burger-menu')
    if (existing) { existing.remove(); return }

    const { agd, rem } = _ultimoCountBurger
    const total = agd + rem
    const menu = document.createElement('div')
    menu.id = 'btb-burger-menu'
    menu.className = 'btb-burger-menu'
    menu.innerHTML = `
      <div class="btb-bm-header">
        <span class="btb-bm-title">Pendências</span>
        <span class="btb-bm-total ${total > 0 ? 'has' : ''}">${total}</span>
      </div>
      <button data-act="agendadas" class="btb-bm-row">
        <span class="btb-bm-icon-wrap" style="background:rgba(59,130,246,0.15);color:#3b82f6">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15 14"/></svg>
        </span>
        <span class="btb-bm-label">Mensagens agendadas</span>
        <span class="btb-bm-count ${agd > 0 ? 'red' : ''}">${agd}</span>
      </button>
      <button data-act="lembretes" class="btb-bm-row">
        <span class="btb-bm-icon-wrap" style="background:rgba(245,158,11,0.15);color:#f59e0b">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>
        </span>
        <span class="btb-bm-label">Lembretes</span>
        <span class="btb-bm-count ${rem > 0 ? 'red' : ''}">${rem}</span>
      </button>
      <button data-act="fixados" class="btb-bm-row">
        <span class="btb-bm-icon-wrap" style="background:rgba(234,179,8,0.15);color:#eab308">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="17" x2="12" y2="22"/><path d="M5 17h14l-1.5-3a3 3 0 0 1-.5-1.6V8a5 5 0 0 0-10 0v4.4c0 .56-.18 1.1-.5 1.6L5 17z"/></svg>
        </span>
        <span class="btb-bm-label">Conversas fixadas</span>
        <span class="btb-bm-count ${(_chatsFixadosCache || []).length > 0 ? 'has-fixados' : ''}">${(_chatsFixadosCache || []).length}</span>
      </button>
      <div class="btb-bm-sep"></div>
      <button data-act="sidebar" class="btb-bm-row">
        <span class="btb-bm-icon-wrap" style="background:rgba(16,185,129,0.15);color:#10b981">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="9" y1="3" x2="9" y2="21"/></svg>
        </span>
        <span class="btb-bm-label">Abrir CRM lateral</span>
      </button>
      <button data-act="atualizar" class="btb-bm-row">
        <span class="btb-bm-icon-wrap" style="background:rgba(99,102,241,0.15);color:#6366f1">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10"/><path d="M20.49 15a9 9 0 0 1-14.85 3.36L1 14"/></svg>
        </span>
        <span class="btb-bm-label">Atualizar agora</span>
      </button>
    `
    document.body.appendChild(menu)

    // Posiciona abaixo do botão (com clamp pra não estourar viewport)
    const r = anchor.getBoundingClientRect()
    menu.style.top = (r.bottom + 6) + 'px'
    menu.style.right = Math.max(8, window.innerWidth - r.right) + 'px'

    // Fecha com Escape
    const onEsc = (ev) => {
      if (ev.key === 'Escape') { menu.remove(); cleanup() }
    }
    // Click fora fecha — usa bubble (false) pra não interferir com o click no botão
    const onClickFora = (ev) => {
      if (menu.contains(ev.target)) return
      if (anchor.contains(ev.target)) return  // ignora click no próprio burger (toggle)
      menu.remove()
      cleanup()
    }
    function cleanup() {
      document.removeEventListener('click', onClickFora)
      document.removeEventListener('keydown', onEsc)
    }
    setTimeout(() => {
      document.addEventListener('click', onClickFora)
      document.addEventListener('keydown', onEsc)
    }, 0)

    menu.querySelectorAll('button').forEach(btn => {
      btn.addEventListener('click', async () => {
        const act = btn.dataset.act
        menu.remove()
        cleanup()
        if (act === 'agendadas') return abrirCentralPendencias('scheduled')
        if (act === 'lembretes') return abrirCentralPendencias('reminders')
        if (act === 'fixados') return abrirPainelFixados()
        if (act === 'sidebar') {
          const toggle = document.getElementById('branorte-sb-toggle')
          if (toggle) toggle.click()
          return
        }
        if (act === 'atualizar') {
          await Promise.all([carregarEtiquetasNoTopbar(), atualizarBadgeBurger()])
          toastTopbar('🔄 Atualizado', 'info', 1200)
        }
      })
    })
  }

  // Ordem oficial dos pills
  const ORDEM_PILLS = [
    '(SEM ETIQUETA)', 'PROSPECCAO', '2A TENTATIVA', 'NOVO LEAD', 'FOLLOW UP',
    'INTERESSE FUTURO', 'VENDIDO', 'LEAD QUENTE',
    'NAO RESPONDEU MAIS', 'NUNCA RESPONDEU', 'NAO TEM INTERESSE',
    'COMPROU DO CONCORRENTE', 'SO BASE DE PRECO', 'FORA DO ORCAMENTO',
    'NAO FABRICAMOS', 'OUTROS ASSUNTOS', 'ORCAMENTO ENVIADO', 'BRANORTE', 'RESOLVIDO',
  ]

  let retryTimerTopbar = null
  function agendarRetryTopbar(delay = 3000) {
    if (retryTimerTopbar) return // já tem retry agendado
    retryTimerTopbar = setTimeout(() => {
      retryTimerTopbar = null
      carregarEtiquetasNoTopbar()
    }, delay)
  }

  // Filtro ativo (pra manter pill destacada entre re-renders)
  let filtroAtivo = null

  function renderPills($pills, counts) {
    const todosNomes = Array.from(counts.keys())
    todosNomes.sort((a, b) => {
      const ia = ORDEM_PILLS.indexOf(a)
      const ib = ORDEM_PILLS.indexOf(b)
      return (ia === -1 ? 999 : ia) - (ib === -1 ? 999 : ib)
    })
    const pills = []
    for (const nome of todosNomes) {
      const ct = counts.get(nome) ?? 0
      if (ct === 0 && nome !== '(SEM ETIQUETA)') continue
      const ativo = nome === filtroAtivo ? ' is-active' : ''
      pills.push(`<span class="btb-pill${ativo}" data-cat="${escapeHtml(nome)}"><span class="nm">${escapeHtml(nome)}</span><span class="ct">${ct}</span></span>`)
    }
    $pills.innerHTML = pills.join('') || '<span style="color:#6b7280;font-size:11px;">(sem etiquetas)</span>'
    $pills.querySelectorAll('.btb-pill').forEach($p => {
      $p.addEventListener('click', () => onPillClick($p))
    })
  }

  function onPillClick($p) {
    const cat = $p.dataset.cat
    // Toggle: se já está ativo, limpa o filtro
    if (filtroAtivo === cat) {
      filtroAtivo = null
      $p.parentElement.querySelectorAll('.btb-pill').forEach(x => x.classList.remove('is-active'))
      limparFiltroWA()
      return
    }
    filtroAtivo = cat
    $p.parentElement.querySelectorAll('.btb-pill').forEach(x => x.classList.toggle('is-active', x === $p))
    filtrarPorEtiqueta(cat)
  }

  async function carregarDoCacheStorage($pills) {
    try {
      const cache = await chrome.storage.local.get(['last_etiquetas', 'last_sem_etiqueta'])
      const lista = cache.last_etiquetas || []
      if (!lista.length && typeof cache.last_sem_etiqueta !== 'number') return false
      const counts = new Map()
      counts.set('(SEM ETIQUETA)', cache.last_sem_etiqueta ?? 0)
      for (const e of lista) {
        const cat = canonicalize(e.name)
        counts.set(cat, (counts.get(cat) ?? 0) + (e.count || 0))
      }
      renderPills($pills, counts)
      return true
    } catch (_) { return false }
  }

  async function carregarEtiquetasNoTopbar() {
    const $pills = document.getElementById('btb-pills')
    if (!$pills) return
    try {
      const r = await chrome.runtime.sendMessage({ type: 'BRANORTE_GET_KANBAN_DATA' })
      if (!r?.ok) {
        // WPP ainda não pronto — usa cache do bg sync (se existir) e reagenda retry
        const usouCache = await carregarDoCacheStorage($pills)
        if (!usouCache) {
          $pills.innerHTML = '<span class="btb-loading-text">aguardando WhatsApp…</span>'
        }
        agendarRetryTopbar(3000)
        return
      }
      const { chats, labels } = r
      const idParaCanonico = new Map()
      for (const lbl of labels) idParaCanonico.set(String(lbl.id), canonicalize(lbl.name))

      const counts = new Map()
      counts.set('(SEM ETIQUETA)', 0)
      for (const c of chats) {
        const ls = c.labels || []
        if (ls.length === 0) counts.set('(SEM ETIQUETA)', counts.get('(SEM ETIQUETA)') + 1)
        for (const lid of ls) {
          const cat = idParaCanonico.get(String(lid)) ?? '?'
          counts.set(cat, (counts.get(cat) ?? 0) + 1)
        }
      }
      renderPills($pills, counts)
    } catch (e) {
      // Mesmo em erro, tenta cache antes de mostrar mensagem feia
      const usouCache = await carregarDoCacheStorage($pills)
      if (!usouCache) {
        $pills.innerHTML = `<span style="color:#ef4444;font-size:11px;">${escapeHtml(e.message)}</span>`
      }
      agendarRetryTopbar(5000)
    }
  }

  function _normalizar(s) {
    return String(s ?? '').normalize('NFKD').replace(/[̀-ͯ]/g, '').toUpperCase().trim().replace(/\s+/g, ' ')
  }

  function _sleep(ms) { return new Promise(r => setTimeout(r, ms)) }

  // Acha elemento clicável (varrendo roles comuns do WA) cujo texto bate com algum dos termos.
  function acharElementoClicavel(termos, matchMode) {
    const alvos = termos.map(_normalizar)
    const seletores = '[role="tab"], [role="button"], [role="option"], [role="menuitem"], [role="listitem"], button, div[tabindex], span[role="button"], li[tabindex]'
    const candidatos = document.querySelectorAll(seletores)
    for (const el of candidatos) {
      if (el.closest('#branorte-topbar, #branorte-sb-full, #branorte-sb')) continue
      const txt = _normalizar(el.textContent)
      if (!txt) continue
      for (const a of alvos) {
        if (matchMode === 'exact' && txt === a) return el
        if ((matchMode === 'starts' || !matchMode) && (txt === a || txt.startsWith(a + ' ') || txt.startsWith(a + '\n'))) return el
      }
    }
    return null
  }

  // Mantida pra compat — não usada mais (substituída por acharElementoClicavel)
  function acharFiltroNativoWA(nome) {
    const alvo = _normalizar(nome)
    const seletores = '[role="tab"], [role="button"], [role="option"], button, span[role="button"]'
    const candidatos = document.querySelectorAll(seletores)
    for (const el of candidatos) {
      // Ignora elementos da própria extensão
      if (el.closest('#branorte-topbar, #branorte-sb-full, #branorte-sb')) continue
      const txt = _normalizar(el.textContent)
      // Match exato ou começa com o nome (pra cobrir "VENDIDO 24")
      if (txt === alvo || txt.startsWith(alvo + ' ') || txt.startsWith(alvo + ' ')) {
        return el
      }
    }
    return null
  }

  // Limpa filtro: clica na aba "Tudo"
  function limparFiltroWA() {
    const tudo = acharElementoClicavel(['Tudo', 'Todas', 'All'], 'exact')
    if (tudo) { tudo.click(); return true }
    const search = document.querySelector('[contenteditable="true"][data-tab="3"], [contenteditable="true"][role="textbox"][title*="Pesquisar" i]')
    if (search) {
      search.focus()
      document.execCommand('selectAll', false, null)
      document.execCommand('delete', false, null)
    }
    return false
  }

  // WA é React → cliques sintéticos (.click()) muitas vezes não disparam handlers.
  // Despacha pointer + mouse events no elemento DOM real no ponto central (resolve event delegation).
  function clicarReal(el) {
    if (!el) return false
    el.scrollIntoView?.({ block: 'nearest', inline: 'nearest' })
    const rect = el.getBoundingClientRect()
    const x = Math.floor(rect.left + rect.width / 2)
    const y = Math.floor(rect.top + rect.height / 2)
    // Pega o elemento de fato no ponto (mais profundo) — pode ser um <span> dentro do botão
    const alvo = document.elementFromPoint(x, y) || el
    const opts = { bubbles: true, cancelable: true, view: window, button: 0, buttons: 1, clientX: x, clientY: y }
    const optsUp = { ...opts, buttons: 0 }
    try {
      alvo.dispatchEvent(new PointerEvent('pointerdown', { ...opts, pointerType: 'mouse', isPrimary: true }))
    } catch (_) {}
    alvo.dispatchEvent(new MouseEvent('mousedown', opts))
    try {
      alvo.dispatchEvent(new PointerEvent('pointerup', { ...optsUp, pointerType: 'mouse', isPrimary: true }))
    } catch (_) {}
    alvo.dispatchEvent(new MouseEvent('mouseup', optsUp))
    alvo.dispatchEvent(new MouseEvent('click', optsUp))
    return true
  }

  // Toast curto pra dar feedback visual sem abrir DevTools
  function toastTopbar(msg, tipo = 'info', ms = 2500) {
    let $t = document.getElementById('branorte-topbar-toast')
    if (!$t) {
      $t = document.createElement('div')
      $t.id = 'branorte-topbar-toast'
      $t.style.cssText = 'position:fixed;top:108px;right:16px;z-index:1000000;padding:10px 16px;border-radius:8px;font-size:12px;font-family:-apple-system,Segoe UI,Roboto,sans-serif;font-weight:600;box-shadow:0 6px 20px rgba(0,0,0,0.4);transition:opacity 0.2s;max-width:340px;'
      document.body.appendChild($t)
    }
    const cor = tipo === 'erro' ? '#ef4444' : tipo === 'aviso' ? '#f59e0b' : '#10b981'
    $t.style.background = cor
    $t.style.color = '#fff'
    $t.style.opacity = '1'
    $t.textContent = msg
    clearTimeout($t._timer)
    $t._timer = setTimeout(() => { $t.style.opacity = '0' }, ms)
  }

  // Localiza o botão "Etiquetas ▼" com 5 estratégias progressivamente mais agressivas.
  function acharBotaoEtiquetas() {
    const log = (...a) => console.log('[Branorte filter]', ...a)

    // (1) Seletor de roles comuns + texto match
    let el = acharElementoClicavel(['Etiquetas', 'Labels'], 'starts')
    if (el) { log('estratégia 1 (roles+texto):', el); return el }

    // (2) Botões com aria-haspopup (dropdown)
    const popups = document.querySelectorAll('[aria-haspopup="true"], [aria-haspopup="menu"], [aria-haspopup="listbox"]')
    for (const p of popups) {
      if (p.closest('#branorte-topbar, #branorte-sb-full, #branorte-sb')) continue
      const t = _normalizar(p.textContent)
      const a = _normalizar(p.getAttribute('aria-label') || '')
      if (t.startsWith('ETIQUETAS') || t.startsWith('LABELS') || a.startsWith('ETIQUETAS') || a.startsWith('LABELS')) {
        log('estratégia 2 (aria-haspopup):', p)
        return p
      }
    }

    // (3) aria-label match
    const ariaEls = document.querySelectorAll('[aria-label]')
    for (const e of ariaEls) {
      if (e.closest('#branorte-topbar, #branorte-sb-full, #branorte-sb')) continue
      if (!e.offsetParent) continue
      const a = _normalizar(e.getAttribute('aria-label'))
      if (a === 'ETIQUETAS' || a === 'LABELS' || a.startsWith('FILTRAR POR ETIQUETA') || a.startsWith('FILTER BY LABEL')) {
        const wrap = e.closest('[role="button"], button, div[tabindex]') || e
        log('estratégia 3 (aria-label):', wrap)
        return wrap
      }
    }

    // (4) TreeWalker — acha text node "Etiquetas" e devolve o pai (ou ancestral elegível)
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode: (n) => {
        const txt = _normalizar(n.nodeValue || '')
        if (txt === 'ETIQUETAS' || txt === 'LABELS') return NodeFilter.FILTER_ACCEPT
        return NodeFilter.FILTER_REJECT
      },
    })
    const candidatosTxt = []
    let node
    while ((node = walker.nextNode())) {
      const parent = node.parentElement
      if (!parent) continue
      if (parent.closest('#branorte-topbar, #branorte-sb-full, #branorte-sb')) continue
      if (!parent.offsetParent) continue
      candidatosTxt.push(parent)
    }
    log('estratégia 4 — text nodes "Etiquetas" achados:', candidatosTxt.length)
    for (const parent of candidatosTxt) {
      let cur = parent
      for (let i = 0; i < 6 && cur && cur !== document.body; i++) {
        if (cur.closest('#branorte-topbar, #branorte-sb-full, #branorte-sb')) break
        const r = cur.getAttribute && cur.getAttribute('role')
        const hasClick = !!cur.onclick || (cur.getAttribute && !!cur.getAttribute('jsaction'))
        const isClickable = r === 'button' || r === 'tab' || cur.tagName === 'BUTTON'
          || cur.tabIndex >= 0 || hasClick
        if (isClickable) { log('estratégia 4 (texto → ancestral clicável):', cur); return cur }
        cur = cur.parentElement
      }
    }
    // Sem ancestral marcado como clicável — devolve o pai direto (React event delegation deve cobrir)
    if (candidatosTxt.length) {
      log('estratégia 4 (texto → pai direto, sem role):', candidatosTxt[0])
      return candidatosTxt[0]
    }

    // (5) Último recurso — varre todos os elementos visíveis pequenos com textContent === "ETIQUETAS"
    const all = document.querySelectorAll('div, span, button, p, a')
    for (const e of all) {
      if (e.closest('#branorte-topbar, #branorte-sb-full, #branorte-sb')) continue
      if (!e.offsetParent) continue
      if (e.childElementCount > 8) continue
      const t = _normalizar(e.textContent || '')
      if (t === 'ETIQUETAS' || t === 'LABELS') {
        log('estratégia 5 (textContent exato):', e)
        return e
      }
    }

    log('TODAS as estratégias falharam — DOM não contém "Etiquetas" visível')
    return null
  }

  // Acha um item de dropdown/menu cujo texto seja exatamente o nome da etiqueta.
  // Usa a mesma estratégia agressiva de TreeWalker — necessária porque WA usa <div> sem role.
  function acharItemMenuPorTexto(alvoNormalizado, excluirEl) {
    const alvo = alvoNormalizado
    const log = (...a) => console.log('[Branorte filter]', ...a)

    // (A) Tenta seletores convencionais primeiro
    const seletores = '[role="menuitem"], [role="option"], [role="listitem"], li[tabindex], li, div[role="button"], div[tabindex="0"]'
    for (const el of document.querySelectorAll(seletores)) {
      if (el.closest('#branorte-topbar, #branorte-sb-full, #branorte-sb')) continue
      if (!el.offsetParent) continue
      if (excluirEl && (el === excluirEl || excluirEl.contains(el) || el.contains(excluirEl))) continue
      const txt = _normalizar(el.textContent)
      if (txt === alvo || txt.startsWith(alvo + ' ') || txt.startsWith(alvo + '\n')) {
        log('item achado (estratégia A — role):', el)
        return el
      }
    }

    // (B) TreeWalker — text node exato "FOLLOW UP" e devolve pai (React event delegation)
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode: (n) => {
        const txt = _normalizar(n.nodeValue || '')
        if (txt === alvo) return NodeFilter.FILTER_ACCEPT
        return NodeFilter.FILTER_REJECT
      },
    })
    const candidatos = []
    let node
    while ((node = walker.nextNode())) {
      const parent = node.parentElement
      if (!parent) continue
      if (parent.closest('#branorte-topbar, #branorte-sb-full, #branorte-sb')) continue
      if (!parent.offsetParent) continue
      if (excluirEl && (excluirEl.contains(parent) || parent.contains(excluirEl))) continue
      candidatos.push(parent)
    }
    log(`item — text nodes "${alvo}" achados:`, candidatos.length)

    // Pra cada candidato, sobe procurando ancestral clicável (até 8 níveis)
    for (const parent of candidatos) {
      let cur = parent
      for (let i = 0; i < 8 && cur && cur !== document.body; i++) {
        if (cur.closest('#branorte-topbar, #branorte-sb-full, #branorte-sb')) break
        const r = cur.getAttribute && cur.getAttribute('role')
        const hasClick = !!cur.onclick || (cur.getAttribute && !!cur.getAttribute('jsaction'))
        const isClickable = r === 'menuitem' || r === 'option' || r === 'listitem' || r === 'button'
          || cur.tagName === 'LI' || cur.tagName === 'BUTTON'
          || cur.tabIndex >= 0 || hasClick
        if (isClickable) { log('item achado (estratégia B — texto → ancestral):', cur); return cur }
        cur = cur.parentElement
      }
    }
    // Sem ancestral clicável → devolve o pai direto
    if (candidatos.length) {
      log('item achado (estratégia B — texto → pai direto):', candidatos[0])
      return candidatos[0]
    }

    // (C) textContent exato em qualquer div/span/li
    for (const e of document.querySelectorAll('div, span, li, button, p, a')) {
      if (e.closest('#branorte-topbar, #branorte-sb-full, #branorte-sb')) continue
      if (!e.offsetParent) continue
      if (e.childElementCount > 5) continue
      if (excluirEl && (excluirEl.contains(e) || e.contains(excluirEl))) continue
      const t = _normalizar(e.textContent || '')
      if (t === alvo) { log('item achado (estratégia C — textContent):', e); return e }
    }

    return null
  }

  async function filtrarPorEtiqueta(nome) {
    console.log('[Branorte filter]', '→ filtrar:', nome)

    if (nome === '(SEM ETIQUETA)') {
      limparFiltroWA()
      return
    }

    // 1) Acha o botão "Etiquetas" — 4 estratégias progressivamente mais agressivas
    let btnEtiquetas = acharBotaoEtiquetas()
    console.log('[Branorte filter]', 'btnEtiquetas:', btnEtiquetas)
    if (!btnEtiquetas) {
      toastTopbar('❌ Botão "Etiquetas" não encontrado — usando busca', 'aviso')
      filtrarBuscaWA(nome)
      return
    }

    // Sobe pra encontrar o wrapper clicável (button | role=button) caso o texto esteja em filho
    const wrapper = btnEtiquetas.closest('[role="button"], button') || btnEtiquetas

    // 2) Clica pra abrir o dropdown
    clicarReal(wrapper)
    await _sleep(200)

    // 3) Procura o item da etiqueta no dropdown que abriu (TreeWalker brute force)
    const alvo = _normalizar(nome)
    let menuItem = null

    for (let i = 0; i < 25; i++) {
      menuItem = acharItemMenuPorTexto(alvo, wrapper)
      if (menuItem) break
      await _sleep(100)
    }

    console.log('[Branorte filter]', 'menuItem:', menuItem)
    if (menuItem) {
      clicarReal(menuItem)
      toastTopbar(`✓ Filtrado por ${nome}`, 'info', 1500)
    } else {
      toastTopbar(`❌ Etiqueta "${nome}" não achada no menu`, 'erro', 3000)
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }))
      filtrarBuscaWA(nome)
    }
  }

  function filtrarBuscaWA(termo) {
    if (!termo) return
    const search = document.querySelector('[contenteditable="true"][data-tab="3"], [contenteditable="true"][role="textbox"][title*="Pesquisar" i]')
    if (!search) {
      const btn = document.querySelector('[aria-label*="Pesquisar" i], button[title*="Pesquisar" i]')
      if (btn) btn.click()
      return
    }
    search.focus()
    document.execCommand('selectAll', false, null)
    document.execCommand('insertText', false, termo)
  }

  function canonicalize(nome) {
    const n = String(nome ?? '').normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[‎‏]/g, '').toUpperCase().trim()
    const ALIASES = { 'FALLOW UP':'FOLLOW UP','FALLOWUP':'FOLLOW UP','FOLLOWUP':'FOLLOW UP',
      'COMPROU DO COMCORRENTE':'COMPROU DO CONCORRENTE','PROSPECCOES':'PROSPECCAO',
      'NOVOS LEADS':'NOVO LEAD','LEAD NOVO':'NOVO LEAD','VENDIDOS':'VENDIDO','RESOLVIDOS':'RESOLVIDO' }
    return ALIASES[n] ?? n
  }

  // Sincroniza atributo do body pro CSS encolher #app quando sidebar abre
  function sincronizarBodyAttr(aberto) {
    if (aberto) document.body.setAttribute('data-branorte-sidebar', 'open')
    else document.body.removeAttribute('data-branorte-sidebar')
  }

  // ===== Botões flutuantes ao lado do microfone (absolutos no footer) =====
  let botaoRaio = null
  function injetarBotaoRaio() {
    // Se já tem container, ignora (e ainda existe no DOM)
    const existente = document.querySelector('.branorte-compose-toolbar')
    if (existente && existente.isConnected) return

    // Procura o footer da área de composição
    const footer = document.querySelector('footer')
    if (!footer) return

    // Procura o MICROFONE pra calcular posição correta
    const alvoIcone = footer.querySelector('[data-icon="ptt"]')
                 || footer.querySelector('[data-icon="ptt-rounded"]')
                 || footer.querySelector('[data-icon="mic"]')
                 || footer.querySelector('button[aria-label*="ssagem de voz"]')
                 || footer.querySelector('button[aria-label*="oice message"]')
                 || footer.querySelector('[data-icon="send"]')
    const btnMic = alvoIcone?.closest('button') || alvoIcone?.closest('[role="button"]')

    // Garante que o footer permite posicionamento absoluto interno
    const cs = window.getComputedStyle(footer)
    if (cs.position === 'static') footer.style.position = 'relative'

    // Container flutuante à direita, encostado no microfone
    const toolbar = document.createElement('div')
    toolbar.className = 'branorte-compose-toolbar'

    botaoRaio = document.createElement('button')
    botaoRaio.className = 'branorte-compose-btn'
    botaoRaio.title = 'Branorte CRM (abrir/fechar)'
    botaoRaio.type = 'button'
    botaoRaio.innerHTML = '<span class="branorte-btn-icon">⚡</span>'
    botaoRaio.addEventListener('click', (e) => {
      e.stopPropagation()
      e.preventDefault()
      const full = document.getElementById('branorte-sb-full')
      if (full) {
        const aberto = full.classList.toggle('open')
        botaoRaio.classList.toggle('active', aberto)
        const toggle = document.getElementById('branorte-sb-toggle')
        if (toggle) toggle.classList.toggle('active', aberto)
        sincronizarBodyAttr(aberto)
        if (aberto) {
          atualizarChatAtivo().then(iniciarPolling)
          // Ao abrir pelo raio, vai direto pra aba "Msgs" (qr)
          const tabQr = full.querySelector('.tabs button[data-tab="qr"]')
          if (tabQr) tabQr.click()
        } else pararPolling()
      }
    })

    const botaoCorrigir = document.createElement('button')
    botaoCorrigir.className = 'branorte-compose-btn branorte-compose-corrigir'
    botaoCorrigir.title = 'Corrigir ortografia/gramática do texto digitado'
    botaoCorrigir.type = 'button'
    botaoCorrigir.innerHTML = '<span class="branorte-btn-icon">✨</span>'
    botaoCorrigir.addEventListener('click', async (e) => {
      e.stopPropagation()
      e.preventDefault()
      await corrigirTextoComposicaoInline(botaoCorrigir)
    })

    toolbar.appendChild(botaoCorrigir)
    toolbar.appendChild(botaoRaio)
    footer.appendChild(toolbar)

    // Reposiciona: à ESQUERDA do microfone (não dá pra ir à direita pq mic está no edge)
    const reposicionar = () => {
      if (!toolbar.isConnected) return
      const mic = btnMic && btnMic.isConnected ? btnMic : (footer.querySelector('[data-icon="ptt"], [data-icon="ptt-rounded"], [data-icon="mic"], [data-icon="send"]')?.closest('button'))
      if (mic) {
        const fr = footer.getBoundingClientRect()
        const mr = mic.getBoundingClientRect()
        const tr = toolbar.getBoundingClientRect()
        const right = Math.max(8, Math.round(fr.right - mr.left + 8))
        // Top exato pra centralizar com o microfone (com offset pra cima)
        const micCenterY = mr.top + mr.height / 2
        const top = Math.round(micCenterY - fr.top - tr.height / 2 - 4)
        toolbar.style.right = right + 'px'
        toolbar.style.left = 'auto'
        toolbar.style.top = top + 'px'
        toolbar.style.transform = 'none'
      } else {
        toolbar.style.right = '70px'
        toolbar.style.left = 'auto'
        toolbar.style.top = '50%'
        toolbar.style.transform = 'translateY(-50%)'
      }
    }
    reposicionar()
    setTimeout(reposicionar, 200)
    setTimeout(reposicionar, 800)
    window.addEventListener('resize', reposicionar)
  }

  // Corrige texto direto no campo de composição do WA — sem painel.
  async function corrigirTextoComposicaoInline($btn) {
    const composer = document.querySelector('footer [contenteditable="true"][role="textbox"], div[contenteditable="true"][data-tab="10"], div[contenteditable="true"][data-tab="1"]')
    if (!composer) {
      mostrarToast('⚠️ Não achei o campo de mensagem', 'erro', 2000)
      return
    }
    const original = composer.innerText.trim()
    if (!original) {
      mostrarToast('⚠️ Digite algo antes', 'aviso', 1500)
      return
    }
    if ($btn.dataset.busy === '1') return
    $btn.dataset.busy = '1'
    $btn.classList.add('busy')
    const labelBak = $btn.innerHTML
    $btn.innerHTML = '⏳'
    try {
      const cfg = await chrome.storage.local.get(['vendedor_nome'])
      const r = await fetch(IA_ENDPOINT, {
        method: 'POST',
        headers: { 'Authorization': 'Bearer ' + SECRET, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: 'corrigir',
          vendedor_nome: cfg.vendedor_nome || 'SHARED',
          texto: original,
          contexto: 'Corrija APENAS ortografia, gramática, pontuação e capitalização da mensagem do vendedor abaixo, mantendo o tom original (informal/formal), gírias e estilo. NÃO reescreva, NÃO adicione conteúdo, NÃO traduza. Devolva SOMENTE o texto corrigido, sem explicações nem aspas.',
          pergunta: original,
        }),
      })
      if (!r.ok) throw new Error('HTTP ' + r.status)
      const j = await r.json().catch(() => ({}))
      const corrigido = (j.resposta || j.text || j.answer || '').trim()
      if (!corrigido) throw new Error('resposta vazia')
      // Substitui texto no campo (helper robusto)
      await substituirTextoComposer(composer, corrigido)
      // Flash verde sutil
      const old = composer.style.boxShadow
      composer.style.transition = 'box-shadow 0.4s'
      composer.style.boxShadow = 'inset 0 0 0 2px #10b981'
      setTimeout(() => { composer.style.boxShadow = old }, 600)
    } catch (e) {
      mostrarToast('❌ ' + e.message, 'erro', 2500)
    } finally {
      $btn.dataset.busy = '0'
      $btn.classList.remove('busy')
      $btn.innerHTML = labelBak
    }
  }

  function observarComposicao() {
    // Re-injeta sempre que mudar de chat (DOM é recriado)
    const obs = new MutationObserver(() => {
      injetarBotaoRaio()
      injetarBotoesTranscricaoAudio()
      injetarPinChatList()
    })
    obs.observe(document.body, { childList: true, subtree: true })
    // Tenta injetar imediatamente também
    // Carrega fixados antes da primeira injeção pra pin já aparecer correto
    loadChatsFixados().catch(() => {})
    setTimeout(() => { injetarBotaoRaio(); injetarBotoesTranscricaoAudio(); injetarPinChatList() }, 1000)
    // Polling de fallback (alguns updates não disparam mutation visível)
    setInterval(() => { injetarBotoesTranscricaoAudio(); injetarPinChatList() }, 2500)
  }

  // ===== Fixar conversas (ilimitado) — sobrepõe a limitação de 3 do WA =====
  let _chatsFixadosCache = null

  async function loadChatsFixados() {
    if (_chatsFixadosCache) return _chatsFixadosCache
    const r = await chrome.storage.local.get('chats_fixados_branorte')
    _chatsFixadosCache = r.chats_fixados_branorte || []
    return _chatsFixadosCache
  }
  async function saveChatsFixados(list) {
    _chatsFixadosCache = list
    await chrome.storage.local.set({ chats_fixados_branorte: list })
  }

  function ehChatListId(dataId) {
    if (!dataId || typeof dataId !== 'string') return false
    // Mensagens têm formato "false_xxx@c.us_yyy" → ignora
    if (dataId.startsWith('false_') || dataId.startsWith('true_')) return false
    return /@(c\.us|g\.us|lid|l\.id|broadcast|newsletter)$/i.test(dataId)
  }

  function injetarPinChatList() {
    // Lista de conversas: container `#pane-side` ou `[aria-label="Lista de conversas" i]`
    const rows = document.querySelectorAll('#pane-side [data-id], [aria-label*="ist" i][role="grid"] [data-id], [role="listitem"][data-id]')
    if (!rows.length) return
    const fixados = _chatsFixadosCache || []
    const idsFixados = new Set(fixados.map(p => p.id))

    for (const row of rows) {
      const dataId = row.getAttribute('data-id')
      if (!ehChatListId(dataId)) continue
      let pin = row.querySelector('.branorte-pin-icon')
      if (!pin) {
        pin = document.createElement('button')
        pin.className = 'branorte-pin-icon'
        pin.title = 'Fixar (Branorte) — sem limite de 3'
        pin.dataset.id = dataId
        pin.type = 'button'
        pin.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" pointer-events="none"><line x1="12" y1="17" x2="12" y2="22"/><path d="M5 17h14l-1.5-3a3 3 0 0 1-.5-1.6V8a5 5 0 0 0-10 0v4.4c0 .56-.18 1.1-.5 1.6L5 17z"/></svg>'
        // Bloqueia TODOS os tipos de evento pra não disparar handlers do WA (React)
        const blockAll = (e) => {
          e.stopPropagation()
          if (e.stopImmediatePropagation) e.stopImmediatePropagation()
        }
        const eventos = ['mousedown', 'mouseup', 'click', 'pointerdown', 'pointerup',
                         'touchstart', 'touchend', 'contextmenu', 'auxclick', 'dblclick']
        for (const evt of eventos) {
          // useCapture: true → roda ANTES de qualquer handler delegado do React do WA
          pin.addEventListener(evt, blockAll, true)
        }
        // Handler real só no click (capture phase)
        pin.addEventListener('click', (e) => {
          e.preventDefault()
          blockAll(e)
          togglePinChat(dataId, row)
        }, true)
        // Posiciona no canto superior direito da row (CSS faz absolute)
        row.style.position = row.style.position || 'relative'
        row.appendChild(pin)
      }
      // Atualiza estado visual
      if (idsFixados.has(dataId)) {
        pin.classList.add('is-pinned')
        row.classList.add('branorte-pinned-row')
      } else {
        pin.classList.remove('is-pinned')
        row.classList.remove('branorte-pinned-row')
      }
    }
  }

  async function togglePinChat(chatId, row) {
    await loadChatsFixados()
    const list = [..._chatsFixadosCache]
    const idx = list.findIndex(p => p.id === chatId)
    let foiFixado = false
    if (idx >= 0) {
      list.splice(idx, 1)
    } else {
      // Pega nome do chat na DOM
      const nome = row?.querySelector('span[title]')?.title
        || row?.querySelector('[aria-label]')?.getAttribute('aria-label')
        || chatId
      list.unshift({ id: chatId, name: nome, pinnedAt: Date.now() })
      foiFixado = true
    }
    await saveChatsFixados(list)
    injetarPinChatList()
    atualizarBadgeBurger()
    mostrarToast(foiFixado ? `📌 Fixado: ${list[0].name}` : '📌 Desafixado', 'sucesso', 1500)
  }

  function abrirChatPorId(chatId) {
    // Tenta clicar na row do chat na lista. Se não estiver visível, scroll até.
    const row = document.querySelector(`#pane-side [data-id="${CSS.escape(chatId)}"], [role="listitem"][data-id="${CSS.escape(chatId)}"]`)
    if (row) {
      row.scrollIntoView({ block: 'center', behavior: 'smooth' })
      // Click sintético no header da row (o componente clicável)
      const inner = row.querySelector('[role="row"], [tabindex="-1"], div')
      if (inner) clicarReal(inner)
      else clicarReal(row)
      return true
    }
    return false
  }

  async function abrirPainelFixados() {
    const list = await loadChatsFixados()
    const overlay = document.createElement('div')
    overlay.className = 'bsb-qr-modal-overlay'
    overlay.innerHTML = `
      <div class="bsb-qr-modal" style="width:480px;max-height:75vh;display:flex;flex-direction:column">
        <div class="bsb-qr-modal-head">
          <span>📌 Conversas fixadas (${list.length})</span>
          <button class="bsb-qr-modal-close">✕</button>
        </div>
        <div class="bsb-qr-modal-body" id="bsb-fixados-list" style="flex:1;overflow-y:auto"></div>
      </div>`
    document.body.appendChild(overlay)
    overlay.querySelector('.bsb-qr-modal-close').addEventListener('click', () => overlay.remove())
    overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove() })

    const $list = overlay.querySelector('#bsb-fixados-list')
    if (list.length === 0) {
      $list.innerHTML = `<div class="bsb-empty" style="padding:30px 16px;text-align:center;">📌 Nenhuma conversa fixada.<br><small style="color:#9ca3af;font-style:italic;font-size:11px">Clique no ícone de pin em qualquer conversa da lista.</small></div>`
      return
    }
    $list.innerHTML = list.map(p => `
      <div class="bsb-fixado-row" data-id="${escapeHtml(p.id)}">
        <div class="bsb-fixado-info">
          <div class="bsb-fixado-name">${escapeHtml(p.name)}</div>
          <div class="bsb-fixado-meta">${escapeHtml(p.id)}</div>
        </div>
        <button class="bsb-fixado-open" title="Abrir conversa">↗</button>
        <button class="bsb-fixado-unpin" title="Desafixar">✕</button>
      </div>
    `).join('')
    $list.querySelectorAll('.bsb-fixado-row').forEach($row => {
      const id = $row.dataset.id
      $row.querySelector('.bsb-fixado-open').addEventListener('click', () => {
        const ok = abrirChatPorId(id)
        if (ok) overlay.remove()
        else mostrarToast('⚠️ Conversa não está visível na lista. Talvez ela tenha sido arquivada.', 'aviso', 3500)
      })
      $row.querySelector('.bsb-fixado-unpin').addEventListener('click', async () => {
        const fresh = await loadChatsFixados()
        const novo = fresh.filter(p => p.id !== id)
        await saveChatsFixados(novo)
        injetarPinChatList()
        atualizarBadgeBurger()
        $row.style.opacity = '0.4'
        $row.style.pointerEvents = 'none'
        setTimeout(() => $row.remove(), 200)
        const $hd = overlay.querySelector('.bsb-qr-modal-head span')
        if ($hd) $hd.textContent = `📌 Conversas fixadas (${novo.length})`
      })
    })
  }

  // ===== Botões de transcrever áudio injetados nas mensagens =====
  function ehMensagemDeAudio(el) {
    if (!el || !el.querySelector) return false
    // Áudios nativos do WA
    if (el.querySelector('audio')) return true
    // Botão de play com aria-label tipicamente "Reproduzir mensagem de voz"
    const playWa = el.querySelector('[role="button"][aria-label*="reproduzir" i], [role="button"][aria-label*="play" i]')
    if (!playWa) return false
    // Tem que ter um slider (linha de progresso) — exclui imagens com botão de play
    if (!el.querySelector('[role="slider"]')) return false
    // Exclui vídeos
    if (el.querySelector('video')) return false
    return true
  }

  // Acha o "bolha" do áudio dentro de uma mensagem pra colocar o botão logo abaixo
  function acharContainerBolhaAudio(msgRow) {
    // Procura o ancestral mais próximo do <audio>/[role="slider"] que tem padding/borda
    const audioEl = msgRow.querySelector('audio') || msgRow.querySelector('[role="slider"]')
    if (!audioEl) return msgRow
    let cur = audioEl
    for (let i = 0; i < 8 && cur && cur !== msgRow; i++) {
      // Sobe até achar um div com classe que indique bubble (heurística simples)
      const cls = cur.className || ''
      if (typeof cls === 'string' && (cls.length > 30 || cur.getBoundingClientRect().width > 200)) {
        return cur
      }
      cur = cur.parentElement
    }
    return msgRow
  }

  function injetarBotoesTranscricaoAudio() {
    const linhas = document.querySelectorAll('[data-id]')
    for (const row of linhas) {
      // Skip se já tem nosso elemento
      if (row.querySelector('.branorte-transcrever-wrap')) continue
      if (!ehMensagemDeAudio(row)) continue
      const dataId = row.getAttribute('data-id')
      if (!dataId) continue

      const wrap = document.createElement('div')
      wrap.className = 'branorte-transcrever-wrap'
      wrap.dataset.id = dataId
      wrap.innerHTML = `
        <button type="button" class="branorte-transcrever-btn" title="Transcrever áudio">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-2px;margin-right:4px"><polygon points="14 2 18 6 7 17 3 17 3 13"/><line x1="3" y1="22" x2="21" y2="22"/></svg>
          Transcrever
        </button>
        <div class="branorte-transcrever-resultado" style="display:none"></div>
      `
      const bolha = acharContainerBolhaAudio(row)
      // Tenta inserir DEPOIS da bolha (não dentro dela, pra não bagunçar layout)
      if (bolha.parentElement) {
        bolha.parentElement.insertBefore(wrap, bolha.nextSibling)
      } else {
        row.appendChild(wrap)
      }
      const $btn = wrap.querySelector('.branorte-transcrever-btn')
      $btn.addEventListener('click', (e) => {
        e.stopPropagation()
        transcreverAudioInline(wrap, dataId)
      })
    }
  }

  async function transcreverAudioInline(wrap, dataId) {
    const $btn = wrap.querySelector('.branorte-transcrever-btn')
    const $res = wrap.querySelector('.branorte-transcrever-resultado')
    if ($btn.disabled) return
    $btn.disabled = true
    const labelOriginal = $btn.innerHTML
    $btn.innerHTML = '⏳ Baixando…'
    $res.style.display = 'none'

    try {
      // Garante chat ativo (passa também o data-id)
      if (!chatAtivo) await atualizarChatAtivo()
      const chatId = chatAtivo?.id

      // Baixa o áudio via background (passa data-id; bg tenta resolver)
      const dl = await chrome.runtime.sendMessage({
        type: 'BRANORTE_DOWNLOAD_MEDIA',
        chatId,
        msgId: dataId,
      })
      if (!dl?.ok || !dl.dataUrl) throw new Error(dl?.erro || 'falha no download')

      $btn.innerHTML = '⏳ Transcrevendo…'
      const cfg = await chrome.storage.local.get(['vendedor_nome'])
      const tr = await fetch(TRANSCRIBE_ENDPOINT, {
        method: 'POST',
        headers: { 'Authorization': 'Bearer ' + SECRET, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          vendedor_nome: cfg.vendedor_nome || 'SHARED',
          chat_id: chatId,
          dataUrl: dl.dataUrl,
          mimetype: dl.mimetype || 'audio/ogg',
          language: 'pt',
        }),
      })
      if (!tr.ok) {
        const t = await tr.text()
        throw new Error(`HTTP ${tr.status} — ${t.slice(0, 200)}`)
      }
      const j = await tr.json().catch(() => ({}))
      const texto = j.text || j.transcription || j.transcript || ''
      if (!texto) throw new Error('resposta vazia')

      $res.innerHTML = `
        <div class="branorte-transcrever-header">
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-1px"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
          TRANSCRIÇÃO
          <button class="branorte-transcrever-copy" title="Copiar">📋</button>
        </div>
        <div class="branorte-transcrever-texto"></div>
      `
      $res.querySelector('.branorte-transcrever-texto').textContent = texto
      $res.style.display = 'block'
      $res.querySelector('.branorte-transcrever-copy').addEventListener('click', async (e) => {
        e.stopPropagation()
        try { await navigator.clipboard.writeText(texto); mostrarToast('📋 Copiado', 'sucesso', 1200) } catch {}
      })
      // Esconde o botão "Transcrever" depois de transcrever (já fez o trabalho)
      $btn.style.display = 'none'
    } catch (e) {
      $res.style.display = 'block'
      $res.innerHTML = `<div class="branorte-transcrever-erro">❌ ${escapeHtml(e.message)}</div>`
      $btn.disabled = false
      $btn.innerHTML = labelOriginal
    }
  }

  // ===== Bootstrap =====
  function tentarInjetar() {
    if (document.body) {
      criar()
      criarTopbar()
      observarComposicao()
      return true
    }
    return false
  }
  if (!tentarInjetar()) {
    const obs = new MutationObserver(() => { if (tentarInjetar()) obs.disconnect() })
    obs.observe(document.documentElement, { childList: true })
  }
})()
