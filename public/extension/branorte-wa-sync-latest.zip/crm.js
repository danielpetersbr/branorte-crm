// crm.js — Kanban completo com drag-and-drop, busca, foto, ações

const $board = document.getElementById('board')
const $status = document.getElementById('status')
const $vendor = document.getElementById('vendor')
const $reload = document.getElementById('reload')
const $search = document.getElementById('search')
const $theme = document.getElementById('theme')
const $toast = document.getElementById('toast')

let dadosAtuais = null   // último resultado completo
let forecastsPorChatId = new Map()  // chat_id -> {prob, saude, estagio, motivo}
let labelsMap = new Map() // id -> { name, color }
let ordenacao = localStorage.getItem('branorte-crm-ordem') || 'antigo'  // 'antigo' | 'recente'
let modoAcao = localStorage.getItem('branorte-crm-modo-acao') === '1'   // esconde fresco quando true

// Filtro de etiquetas visíveis. null = todas. Set<string> = só essas (canônicas).
let etiquetasVisiveis = (() => {
  try {
    const raw = localStorage.getItem('branorte-crm-etiquetas-visiveis')
    if (!raw) return null
    const arr = JSON.parse(raw)
    return Array.isArray(arr) ? new Set(arr) : null
  } catch { return null }
})()
function salvarFiltroEtiquetas() {
  if (etiquetasVisiveis === null) localStorage.removeItem('branorte-crm-etiquetas-visiveis')
  else localStorage.setItem('branorte-crm-etiquetas-visiveis', JSON.stringify([...etiquetasVisiveis]))
}

// ===== Constantes (mesmas do CRM Vercel) =====
const ORDEM_FUNIL = [
  '(SEM ETIQUETA)',
  'PROSPECCAO',
  '2A TENTATIVA',
  'NOVO LEAD',
  'FOLLOW UP',
  'INTERESSE FUTURO',
  'VENDIDO',
  'NAO RESPONDEU MAIS',
  'NUNCA RESPONDEU',
  'NAO TEM INTERESSE',
  'COMPROU DO CONCORRENTE',
  'SO BASE DE PRECO',
  'FORA DO ORCAMENTO',
  'NAO FABRICAMOS',
  'OUTROS ASSUNTOS',
  'ORCAMENTO ENVIADO',
  'LEAD QUENTE',
]

const CORES_FUNIL = {
  '(SEM ETIQUETA)':     '#94a3b8',
  'PROSPECCAO':         '#3b82f6',
  '2A TENTATIVA':       '#06b6d4',
  'NOVO LEAD':          '#8b5cf6',
  'FOLLOW UP':          '#f59e0b',
  'INTERESSE FUTURO':   '#facc15',
  'VENDIDO':            '#10b981',
  'NAO RESPONDEU MAIS': '#64748b',
  'NUNCA RESPONDEU':    '#71717a',
  'NAO TEM INTERESSE':  '#a78bfa',
  'COMPROU DO CONCORRENTE': '#ef4444',
  'SO BASE DE PRECO':   '#f97316',
  'FORA DO ORCAMENTO':  '#fb7185',
  'NAO FABRICAMOS':     '#0ea5e9',
  'OUTROS ASSUNTOS':    '#71717a',
  'ORCAMENTO ENVIADO':  '#22d3ee',
  'LEAD QUENTE':        '#dc2626',
}

const ALIASES = {
  'FALLOW UP': 'FOLLOW UP',
  'FALLOWUP': 'FOLLOW UP',
  'FOLLOWUP': 'FOLLOW UP',
  'COMPROU DO COMCORRENTE': 'COMPROU DO CONCORRENTE',
  'PROSPECCOES': 'PROSPECCAO',
  'NOVOS LEADS': 'NOVO LEAD',
  'LEAD NOVO': 'NOVO LEAD',
  'VENDIDOS': 'VENDIDO',
  'RESOLVIDOS': 'RESOLVIDO',
}

// ===== Utils =====
function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]))
}
function normalize(s) {
  return String(s ?? '').normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[‎‏]/g, '').toUpperCase().trim()
}
function canonicalize(nome) {
  const n = normalize(nome)
  return ALIASES[n] ?? n
}
function corDaColuna(nomeNormalizado) {
  return CORES_FUNIL[nomeNormalizado] ?? '#6b7280'
}
function iniciais(nome) {
  if (!nome) return '?'
  const partes = nome.trim().split(/\s+/)
  return ((partes[0]?.[0] ?? '') + (partes[1]?.[0] ?? '')).toUpperCase() || '?'
}
// Formata "há X" baseado em ms timestamp
function fmtAgo(ts) {
  if (!ts) return ''
  const diff = Date.now() - ts
  if (diff < 60_000) return 'agora'
  if (diff < 3600_000) return `${Math.floor(diff / 60000)}min`
  if (diff < 86400_000) return `${Math.floor(diff / 3600000)}h`
  const d = Math.floor(diff / 86400000)
  if (d < 30) return `${d}d`
  return `${Math.floor(d / 30)}m`
}

// Cor de "frescura" baseado no tempo
function frescuraDoChat(ts) {
  if (!ts) return { cor: '#6b7280', label: '?' }
  const diff = Date.now() - ts
  if (diff < 86400_000) return { cor: '#10b981', label: 'fresco' }      // < 1 dia
  if (diff < 3 * 86400_000) return { cor: '#22d3ee', label: 'recente' }  // < 3 dias
  if (diff < 7 * 86400_000) return { cor: '#fbbf24', label: 'atenção' } // < 7 dias
  return { cor: '#ef4444', label: 'parado' }                              // > 7 dias
}

function previewMensagem(msg) {
  if (!msg) return ''
  if (msg.type === 'chat' || msg.type === 'text') return msg.body ?? ''
  if (msg.type === 'image') return '🖼️ Imagem'
  if (msg.type === 'video') return '🎥 Vídeo'
  if (msg.type === 'audio' || msg.type === 'ptt') return '🎙️ Áudio'
  if (msg.type === 'document') return '📄 Documento'
  if (msg.type === 'sticker') return '🩷 Figurinha'
  if (msg.type === 'location') return '📍 Localização'
  if (msg.type === 'vcard') return '👤 Contato'
  return msg.body ?? `[${msg.type}]`
}
function showToast(msg, tipo = '') {
  $toast.textContent = msg
  $toast.className = 'toast show ' + tipo
  setTimeout(() => $toast.classList.remove('show'), 2400)
}

// ===== Tema =====
function carregarTema() {
  const t = localStorage.getItem('branorte-crm-theme') || 'dark'
  if (t === 'light') {
    document.body.classList.add('light')
    $theme.textContent = '☀️'
  } else {
    document.body.classList.remove('light')
    $theme.textContent = '🌙'
  }
}
$theme.addEventListener('click', () => {
  const dark = !document.body.classList.contains('light') === false  // estamos em dark?
  if (document.body.classList.contains('light')) {
    document.body.classList.remove('light')
    $theme.textContent = '🌙'
    localStorage.setItem('branorte-crm-theme', 'dark')
  } else {
    document.body.classList.add('light')
    $theme.textContent = '☀️'
    localStorage.setItem('branorte-crm-theme', 'light')
  }
})

// ===== Busca/filtro =====
let filterTerm = ''
$search.addEventListener('input', (e) => {
  filterTerm = e.target.value.toLowerCase().trim()
  if (dadosAtuais) render(dadosAtuais)
})

// ===== Filtro de etiquetas (dropdown) =====
const $btnFiltro = document.getElementById('btnFiltroEtiquetas')
const $dropdown = document.getElementById('filtroDropdown')
const $listaFiltro = document.getElementById('filtroList')
const $badgeFiltro = document.getElementById('filtroBadge')

$btnFiltro.addEventListener('click', (e) => {
  e.stopPropagation()
  $dropdown.classList.toggle('open')
})
document.addEventListener('click', (e) => {
  if (!$dropdown.contains(e.target) && e.target !== $btnFiltro) {
    $dropdown.classList.remove('open')
  }
})

// Botões de ação rápida
document.querySelectorAll('#filtroDropdown .filtro-actions button').forEach(btn => {
  btn.addEventListener('click', () => {
    const act = btn.dataset.act
    if (!dadosAtuais) return
    if (act === 'all') {
      etiquetasVisiveis = null
    } else if (act === 'none') {
      etiquetasVisiveis = new Set()
    } else if (act === 'funil') {
      // Só as 5 etiquetas principais do funil
      etiquetasVisiveis = new Set(['PROSPECCAO', '2A TENTATIVA', 'NOVO LEAD', 'FOLLOW UP', 'INTERESSE FUTURO', 'VENDIDO', 'LEAD QUENTE'])
    }
    salvarFiltroEtiquetas()
    render(dadosAtuais)
  })
})

function renderDropdownFiltro(todosNomes, chatsPorEtiqueta) {
  // Atualiza badge
  if (etiquetasVisiveis === null) {
    $badgeFiltro.textContent = 'todas'
  } else {
    $badgeFiltro.textContent = `${etiquetasVisiveis.size} de ${todosNomes.length}`
  }

  // Lista
  $listaFiltro.innerHTML = ''
  for (const nome of todosNomes) {
    const count = (chatsPorEtiqueta.get(nome) ?? []).length
    const cor = corDaColuna(nome)
    const visivel = etiquetasVisiveis === null || etiquetasVisiveis.has(nome)
    const $row = document.createElement('label')
    $row.className = 'filtro-row'
    $row.innerHTML = `
      <input type="checkbox" ${visivel ? 'checked' : ''} />
      <span class="fr-dot" style="background:${cor}"></span>
      <span class="fr-name">${escapeHtml(nome)}</span>
      <span class="fr-count">${count}</span>
      <span class="fr-solo" data-solo="${escapeHtml(nome)}">só essa</span>
    `
    const $cb = $row.querySelector('input')
    $cb.addEventListener('change', (e) => {
      e.stopPropagation()
      if (etiquetasVisiveis === null) {
        // Era "todas" - converte pra Set explícito
        etiquetasVisiveis = new Set(todosNomes)
      }
      if ($cb.checked) etiquetasVisiveis.add(nome)
      else etiquetasVisiveis.delete(nome)
      salvarFiltroEtiquetas()
      render(dadosAtuais)
    })
    // Botão "só essa"
    $row.querySelector('.fr-solo').addEventListener('click', (e) => {
      e.preventDefault()
      e.stopPropagation()
      etiquetasVisiveis = new Set([nome])
      salvarFiltroEtiquetas()
      render(dadosAtuais)
    })
    $listaFiltro.appendChild($row)
  }
}

// ===== Buscar dados via background =====
async function buscarDados() {
  $status.textContent = 'Carregando…'
  const r = await chrome.runtime.sendMessage({ type: 'BRANORTE_GET_KANBAN_DATA' })
  if (!r?.ok) {
    $board.innerHTML = `<div class="loading">⚠️ ${escapeHtml(r?.erro ?? 'erro desconhecido')}</div>`
    $status.textContent = 'Erro'
    return null
  }
  return r
}

// ===== Click no card abre conversa no WhatsApp =====
async function abrirChat(chatId) {
  if (!chatId) return
  // Tenta achar a aba do WhatsApp e ativar + abrir o chat
  const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' })
  if (!tabs.length) {
    showToast('Abra web.whatsapp.com primeiro', 'error')
    return
  }
  const tab = tabs[0]
  await chrome.tabs.update(tab.id, { active: true })
  await chrome.windows.update(tab.windowId, { focused: true })
  // Roda openChat via WPP
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: 'MAIN',
      func: async (id) => {
        if (window.WPP?.chat?.openChatBottom) {
          await window.WPP.chat.openChatBottom(id)
        } else if (window.WPP?.chat?.openChatAt) {
          await window.WPP.chat.openChatAt(id)
        }
      },
      args: [chatId],
    })
  } catch (e) {
    showToast('Erro ao abrir chat: ' + e.message, 'error')
  }
}

// ===== Drag-and-drop: muda etiqueta =====
let dragging = null  // { chatId, fromColuna }

// ============================================================================
// MENU DE CONTEXTO: trocar etiqueta com botão direito
// ============================================================================
let _menuAberto = null  // referência do menu atual pra fechar
function fecharMenuEtiquetas() {
  if (_menuAberto) { _menuAberto.remove(); _menuAberto = null }
  document.removeEventListener('click', fecharMenuEtiquetas)
  document.removeEventListener('contextmenu', fecharMenuEtiquetas)
  window.removeEventListener('scroll', fecharMenuEtiquetas, true)
}

function abrirMenuEtiquetas(chat, x, y) {
  fecharMenuEtiquetas()
  if (!dadosAtuais) return

  const { labels } = dadosAtuais
  const idParaCanonico = new Map()
  const canonicoParaId = new Map()
  for (const lbl of labels) {
    const c = canonicalize(lbl.name)
    idParaCanonico.set(String(lbl.id), c)
    if (!canonicoParaId.has(c)) canonicoParaId.set(c, String(lbl.id))
  }
  const ativasIds = new Set((chat.labels || []).map(String))
  const ativasCanonicas = new Set([...ativasIds].map(id => idParaCanonico.get(id)).filter(Boolean))

  // Lista canônica ordenada pelo funil
  const todasCanonicas = Array.from(canonicoParaId.keys())
  todasCanonicas.sort((a, b) => {
    const ia = ORDEM_FUNIL.indexOf(a)
    const ib = ORDEM_FUNIL.indexOf(b)
    return (ia === -1 ? 999 : ia) - (ib === -1 ? 999 : ib)
  })

  const $menu = document.createElement('div')
  $menu.className = 'card-ctx-menu'
  $menu.innerHTML = `
    <div class="ctx-head">
      <span class="ctx-head-nome">${escapeHtml(chat.name || chat.number || '?')}</span>
      <button class="ctx-close" title="Fechar">✕</button>
    </div>
    <div class="ctx-sub">Trocar etiqueta:</div>
    <div class="ctx-items">
      ${ativasCanonicas.size > 0 ? `
        <button class="ctx-item ctx-item-rm" data-action="remove-all" title="Remove todas as etiquetas">
          <span class="ctx-dot" style="background:#94a3b8"></span>
          <span class="ctx-name">(Sem etiqueta)</span>
          <span class="ctx-check">${ativasCanonicas.size === 0 ? '✓' : ''}</span>
        </button>
      ` : ''}
      ${todasCanonicas.map(c => {
        const id = canonicoParaId.get(c)
        const cor = corDaColuna(c)
        const ativo = ativasCanonicas.has(c)
        return `
          <button class="ctx-item ${ativo ? 'is-active' : ''}" data-cat="${escapeHtml(c)}" data-id="${escapeHtml(id)}">
            <span class="ctx-dot" style="background:${cor}"></span>
            <span class="ctx-name">${escapeHtml(c)}</span>
            <span class="ctx-check">${ativo ? '✓' : ''}</span>
          </button>`
      }).join('')}
    </div>`

  document.body.appendChild($menu)
  _menuAberto = $menu

  // Posiciona o menu (tenta não estourar a tela)
  const rect = $menu.getBoundingClientRect()
  const w = rect.width || 240
  const h = rect.height || 300
  let px = x
  let py = y
  if (px + w > window.innerWidth - 10) px = window.innerWidth - w - 10
  if (py + h > window.innerHeight - 10) py = window.innerHeight - h - 10
  $menu.style.left = px + 'px'
  $menu.style.top = py + 'px'

  // Fechar ao clicar fora (timeout pra não disparar imediatamente)
  setTimeout(() => {
    document.addEventListener('click', fecharMenuEtiquetas)
    document.addEventListener('contextmenu', fecharMenuEtiquetas)
    window.addEventListener('scroll', fecharMenuEtiquetas, true)
  }, 0)

  $menu.addEventListener('click', e => e.stopPropagation())
  $menu.querySelector('.ctx-close').addEventListener('click', fecharMenuEtiquetas)

  $menu.querySelectorAll('.ctx-item[data-cat]').forEach($it => {
    $it.addEventListener('click', async () => {
      const cat = $it.dataset.cat
      const novoId = $it.dataset.id
      const ativo = $it.classList.contains('is-active')
      fecharMenuEtiquetas()

      // Remove TODAS as etiquetas atuais e adiciona só a nova (substitui)
      // Se já está ativa, só remove (vira sem etiqueta)
      if (ativo) {
        showToast(`Removendo "${cat}"…`)
        const r = await aplicarMudancaEtiqueta(chat.id, null, novoId)
        if (r.ok) {
          showToast(`Removida "${cat}"`, 'success')
          const novo = await buscarDados()
          if (novo) render(novo)
        } else {
          showToast('Falhou: ' + (r.motivo || 'erro'), 'error')
        }
      } else {
        // Substituir: remove a primeira ativa e adiciona a nova
        const removerId = ativasIds.size > 0 ? [...ativasIds][0] : null
        showToast(`Mudando pra "${cat}"…`)
        const r = await aplicarMudancaEtiqueta(chat.id, novoId, removerId)
        if (r.ok) {
          showToast(`Mudou pra "${cat}"`, 'success')
          const novo = await buscarDados()
          if (novo) render(novo)
        } else {
          showToast('Falhou: ' + (r.motivo || 'erro'), 'error')
        }
      }
    })
  })

  // "Sem etiqueta" → remove todas
  const $semEt = $menu.querySelector('[data-action="remove-all"]')
  if ($semEt) {
    $semEt.addEventListener('click', async () => {
      fecharMenuEtiquetas()
      showToast('Removendo etiquetas…')
      // Remove uma por uma (API só remove 1 por chamada)
      let okAll = true
      for (const id of ativasIds) {
        const r = await aplicarMudancaEtiqueta(chat.id, null, id)
        if (!r.ok) okAll = false
      }
      if (okAll) {
        showToast('Etiquetas removidas', 'success')
        const novo = await buscarDados()
        if (novo) render(novo)
      } else {
        showToast('Algumas etiquetas falharam', 'error')
      }
    })
  }
}

async function aplicarMudancaEtiqueta(chatId, etiquetaIdAdd, etiquetaIdRemove) {
  const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' })
  if (!tabs.length) { showToast('Abra web.whatsapp.com', 'error'); return { ok: false } }
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      world: 'MAIN',
      func: async (chatId, addId, removeId) => {
        const log = []
        try {
          // wa-js v4: parâmetro CORRETO é { labelId, type } (não 'id'!)
          const ops = []
          if (addId) ops.push({ labelId: String(addId), type: 'add' })
          if (removeId) ops.push({ labelId: String(removeId), type: 'remove' })
          if (!ops.length) return { ok: false, motivo: 'no_ops' }

          // Garante que o chat está no Store local antes de chamar
          let chatModel = window.WPP.chat.get(chatId)
          if (!chatModel) {
            log.push({ etapa: 'chat-nao-carregado', tentando: 'find' })
            try {
              chatModel = await window.WPP.chat.find(chatId)
            } catch (e) {
              log.push({ etapa: 'find-falhou', erro: String(e).slice(0, 200) })
            }
          }

          let resultado = null, erroApi = null
          try {
            resultado = await window.WPP.labels.addOrRemoveLabels([chatId], ops)
          } catch (e) {
            erroApi = String(e).slice(0, 200)
          }
          log.push({ etapa: 'api-call', ops, resultado, erroApi })

          // Aguarda propagação e re-lê
          await new Promise(res => setTimeout(res, 1200))
          const chatDepois = window.WPP.chat.get(chatId)
          const labelsAtuais = (chatDepois?.labels || []).map(String)
          const conferiuAdd = !addId || labelsAtuais.includes(String(addId))
          const conferiuRemove = !removeId || !labelsAtuais.includes(String(removeId))

          return {
            ok: conferiuAdd && conferiuRemove,
            labelsAtuais,
            chatId,
            addId,
            removeId,
            log,
            wpp_version: window.WPP?.version,
            isSMB: window.Store?.Conn?.isSMB,
            platform: window.Store?.Conn?.platform,
          }
        } catch (e) {
          return { ok: false, motivo: String(e), log }
        }
      },
      args: [chatId, etiquetaIdAdd, etiquetaIdRemove],
    })
    console.log('[Branorte CRM] addOrRemoveLabels result:', result)
    return result ?? { ok: false }
  } catch (e) {
    showToast('Erro: ' + e.message, 'error')
    return { ok: false, motivo: e.message }
  }
}

// ===== Render =====
function render(data) {
  dadosAtuais = data
  const { chats, labels, vendedor } = data
  $vendor.textContent = vendedor ?? '—'

  labelsMap.clear()
  for (const lbl of labels) {
    labelsMap.set(String(lbl.id), { name: lbl.name, canonical: canonicalize(lbl.name), color: lbl.color })
  }

  // Filtragem
  const term = filterTerm
  const chatsVisiveis = term
    ? chats.filter(c => {
        const nome = (c.name || c.pushname || '').toLowerCase()
        const num = (c.number || '').toLowerCase()
        return nome.includes(term) || num.includes(term)
      })
    : chats

  $status.textContent = term
    ? `${chatsVisiveis.length} de ${chats.length} chats`
    : `${chats.length} chats · ${labels.length} etiquetas`

  // Agrupa por etiqueta canônica
  const chatsPorEtiqueta = new Map()
  chatsPorEtiqueta.set('(SEM ETIQUETA)', [])
  for (const lbl of labels) {
    const c = canonicalize(lbl.name)
    if (!chatsPorEtiqueta.has(c)) chatsPorEtiqueta.set(c, [])
  }
  const idParaCanonico = new Map()
  for (const lbl of labels) idParaCanonico.set(String(lbl.id), canonicalize(lbl.name))

  for (const chat of chatsVisiveis) {
    const ls = chat.labels || []
    if (ls.length === 0) {
      chatsPorEtiqueta.get('(SEM ETIQUETA)').push(chat)
    } else {
      for (const lid of ls) {
        const cat = idParaCanonico.get(String(lid))
        if (!cat) continue
        if (!chatsPorEtiqueta.has(cat)) chatsPorEtiqueta.set(cat, [])
        chatsPorEtiqueta.get(cat).push(chat)
      }
    }
  }

  // Mapa nome canônico → primeiro labelId real (pra usar no drag-drop add)
  const canonicoParaId = new Map()
  for (const [id, cat] of idParaCanonico) {
    if (!canonicoParaId.has(cat)) canonicoParaId.set(cat, id)
  }

  // Ordena pelo funil
  const todosNomes = Array.from(chatsPorEtiqueta.keys())
  todosNomes.sort((a, b) => {
    const ia = ORDEM_FUNIL.indexOf(a)
    const ib = ORDEM_FUNIL.indexOf(b)
    return (ia === -1 ? 999 : ia) - (ib === -1 ? 999 : ib)
  })

  // Aplica filtro de etiquetas visíveis (se definido)
  const nomesParaRender = etiquetasVisiveis === null
    ? todosNomes
    : todosNomes.filter(n => etiquetasVisiveis.has(n))

  // Atualiza dropdown de filtros (com contagem real)
  renderDropdownFiltro(todosNomes, chatsPorEtiqueta)

  // Render
  $board.innerHTML = ''
  if (nomesParaRender.length === 0) {
    $board.innerHTML = '<div class="loading">Nenhuma etiqueta selecionada. Clica em <b>🏷️ Etiquetas</b> no topo pra escolher.</div>'
    return
  }
  for (const nome of nomesParaRender) {
    const lista = chatsPorEtiqueta.get(nome) ?? []
    const cor = corDaColuna(nome)
    const labelId = canonicoParaId.get(nome) ?? null

    // Breakdown por status temporal + direção da ultima msg
    const breakdown = { fresco: 0, recente: 0, atencao: 0, parado: 0, semDado: 0 }
    let aguardandoCount = 0
    for (const c of lista) {
      if (!c.lastTs) { breakdown.semDado++ }
      else {
        const f = frescuraDoChat(c.lastTs).label
        if (f === 'fresco') breakdown.fresco++
        else if (f === 'recente') breakdown.recente++
        else if (f === 'atenção') breakdown.atencao++
        else if (f === 'parado') breakdown.parado++
        else breakdown.semDado++
      }
      if (c.lastMessage && c.lastMessage.fromMe === false) aguardandoCount++
    }
    const pctParado = lista.length > 0 ? Math.round((breakdown.parado / lista.length) * 100) : 0
    const alertaClass = pctParado >= 50 ? ' col-alerta' : ''

    const $col = document.createElement('div')
    $col.className = 'col' + alertaClass
    $col.dataset.coluna = nome
    $col.dataset.labelId = labelId ?? ''
    $col.innerHTML = `
      <div class="col-header" style="border-top-color: ${cor}">
        <div class="col-header-row">
          <span class="name" style="color: ${cor}">${escapeHtml(nome)}</span>
          <span class="count">${lista.length}</span>
        </div>
        <div class="col-breakdown">
          ${aguardandoCount   > 0 ? `<span class="bd bd-aguardando" title="${aguardandoCount} aguardando sua resposta">↙ ${aguardandoCount}</span>` : ''}
          ${breakdown.parado  > 0 ? `<span class="bd bd-parado"  title="${breakdown.parado} parados (>7d)">🔴 ${breakdown.parado}</span>` : ''}
          ${breakdown.atencao > 0 ? `<span class="bd bd-atencao" title="${breakdown.atencao} em atenção (3-7d)">🟡 ${breakdown.atencao}</span>` : ''}
          ${breakdown.recente > 0 ? `<span class="bd bd-recente" title="${breakdown.recente} recentes (1-3d)">🔵 ${breakdown.recente}</span>` : ''}
          ${breakdown.fresco  > 0 ? `<span class="bd bd-fresco"  title="${breakdown.fresco} frescos (<24h)">🟢 ${breakdown.fresco}</span>` : ''}
        </div>
      </div>
      <div class="col-body"></div>
    `

    // Drag-over feedback + drop
    $col.addEventListener('dragover', (e) => { e.preventDefault(); $col.classList.add('drag-over') })
    $col.addEventListener('dragleave', () => $col.classList.remove('drag-over'))
    $col.addEventListener('drop', async (e) => {
      e.preventDefault()
      $col.classList.remove('drag-over')
      if (!dragging) return
      const { chatId, fromColuna, fromLabelId } = dragging
      const toColuna = nome
      const toLabelId = labelId
      if (fromColuna === toColuna) return

      // Compõe operações
      let addId = null, removeId = null
      if (toColuna !== '(SEM ETIQUETA)' && toLabelId) addId = toLabelId
      if (fromColuna !== '(SEM ETIQUETA)' && fromLabelId) removeId = fromLabelId

      showToast('Movendo chat…')
      const r = await aplicarMudancaEtiqueta(chatId, addId, removeId)
      console.log('[Branorte CRM] mudança resultado:', r)
      if (r.ok) {
        showToast(`Movido pra ${toColuna}`, 'success')
        const novo = await buscarDados()
        if (novo) render(novo)
      } else {
        const det = r.motivo || JSON.stringify(r.tentativas?.[0] ?? {}).slice(0, 80)
        showToast('Falhou: ' + det, 'error')
      }
    })

    const $body = $col.querySelector('.col-body')
    // Modo ação: se a coluna não tem PARADO/ATENÇÃO/RECENTE, pula inteira
    if (modoAcao) {
      const acionaveis = lista.filter(c => {
        if (!c.lastTs) return false
        const lbl = frescuraDoChat(c.lastTs).label
        return lbl === 'parado' || lbl === 'atenção' || lbl === 'recente'
      })
      if (acionaveis.length === 0) continue
    }
    if (lista.length === 0) {
      $body.innerHTML = '<div class="empty">vazio</div>'
    } else {
      // Agrupa por status temporal pra organizar em seções
      const grupos = { parado: [], atencao: [], recente: [], fresco: [], semDado: [] }
      for (const c of lista) {
        if (!c.lastTs) { grupos.semDado.push(c); continue }
        const lbl = frescuraDoChat(c.lastTs).label
        if (lbl === 'fresco') grupos.fresco.push(c)
        else if (lbl === 'recente') grupos.recente.push(c)
        else if (lbl === 'atenção') grupos.atencao.push(c)
        else if (lbl === 'parado') grupos.parado.push(c)
        else grupos.semDado.push(c)
      }
      // Ordena dentro de cada grupo
      const sortFn = (a, b) => {
        const ta = a.lastTs ?? 0
        const tb = b.lastTs ?? 0
        return ordenacao === 'antigo' ? ta - tb : tb - ta
      }
      for (const k of Object.keys(grupos)) grupos[k].sort(sortFn)

      // Ordem dos grupos depende da seleção:
      //   "Mais antigo" → PARADO primeiro (action priority — atender quem tá esperando há mais tempo)
      //   "Recente"     → FRESCO primeiro (recém ativos)
      const ordemGruposPriority = [
        { key: 'parado',  label: 'Parados',   emoji: '🔴', cor: '#ef4444' },
        { key: 'atencao', label: 'Atenção',   emoji: '🟡', cor: '#fbbf24' },
        { key: 'recente', label: 'Recentes',  emoji: '🔵', cor: '#22d3ee' },
        { key: 'fresco',  label: 'Frescos',   emoji: '🟢', cor: '#10b981' },
        { key: 'semDado', label: 'Sem dado',  emoji: '⚫', cor: '#6b7280' },
      ]
      let ordemGrupos = ordenacao === 'antigo'
        ? ordemGruposPriority
        : [...ordemGruposPriority].reverse()
      // Modo ação: esconde fresco e sem-dado (foca em quem precisa de atenção)
      if (modoAcao) {
        ordemGrupos = ordemGrupos.filter(g => g.key !== 'fresco' && g.key !== 'semDado')
      }
      let totalRender = 0
      const LIMITE_TOTAL = 200
      for (const g of ordemGrupos) {
        const arr = grupos[g.key]
        if (arr.length === 0) continue
        if (totalRender >= LIMITE_TOTAL) break

        // Separador do grupo (só se houver pelo menos 2 grupos com itens)
        const $sep = document.createElement('div')
        $sep.className = 'col-group-sep'
        $sep.style.borderColor = g.cor + '55'
        $sep.style.color = g.cor
        $sep.innerHTML = `<span>${g.emoji} ${g.label}</span><span class="col-group-count">${arr.length}</span>`
        $body.appendChild($sep)

        const podeMostrar = LIMITE_TOTAL - totalRender
        for (const chat of arr.slice(0, podeMostrar)) {
          $body.appendChild(criarCard(chat, nome, labelId))
          totalRender++
        }
        if (arr.length > podeMostrar) {
          const $more = document.createElement('div')
          $more.className = 'empty'
          $more.textContent = `+${arr.length - podeMostrar} ${g.label.toLowerCase()} não exibidos`
          $body.appendChild($more)
          break
        }
      }
    }
    $board.appendChild($col)
  }
  // Após renderizar Kanban, dispara carregamento async dos forecasts
  // (no-op se forecastsPorChatId já populado — aplicarBadgesForecast é idempotente)
  if (forecastsPorChatId.size === 0) {
    carregarForecasts()
  } else {
    aplicarBadgesForecast()
  }
}

function criarCard(chat, fromColuna, fromLabelId) {
  const $card = document.createElement('div')
  const fresc = frescuraDoChat(chat.lastTs)
  // classe de frescura
  const classeFresc =
    fresc.label === 'fresco'   ? 'fresh' :
    fresc.label === 'recente'  ? 'recente' :
    fresc.label === 'atenção'  ? 'atencao' :
    fresc.label === 'parado'   ? 'parado' : ''
  // (computado abaixo, mas usado já aqui pra adicionar classe extra)
  const _fromMe = chat.lastMessage?.fromMe === true
  const _semMsg = !chat.lastMessage
  const classeAguarda = (!_fromMe && !_semMsg) ? ' aguardando-resposta' : ''
  $card.className = `card ${classeFresc}${classeAguarda}`
  $card.draggable = true
  $card.dataset.chatId = chat.id

  const nome = chat.name || chat.pushname || chat.formattedTitle || chat.number || 'Sem nome'
  const preview = previewMensagem(chat.lastMessage)
  const inits = iniciais(nome)
  const unread = chat.unreadCount > 0
    ? `<span class="badge-unread">${chat.unreadCount > 99 ? '99+' : chat.unreadCount}</span>`
    : ''
  const ago = chat.lastTs ? fmtAgo(chat.lastTs) : '—'
  const dataFull = chat.lastTs ? new Date(chat.lastTs).toLocaleString('pt-BR') : 'Sem mensagens'

  // Direção da última mensagem (CRÍTICO pra saber quem deve responder)
  const fromMe = chat.lastMessage?.fromMe === true
  const semMsg = !chat.lastMessage
  const dirCls   = semMsg ? 'dir-none' : (fromMe ? 'dir-eu' : 'dir-cliente')
  const dirIcon  = semMsg ? '·'        : (fromMe ? '↗' : '↙')
  const dirLabel = semMsg ? '—'        : (fromMe ? 'Você' : 'Cliente')
  const dirTitle = semMsg ? 'Sem mensagens' : (fromMe ? 'Última mensagem foi sua — aguardando cliente' : 'Última mensagem foi do cliente — você precisa responder')
  // Adiciona classe extra no card se cliente tá esperando resposta
  const aguardandoResposta = !fromMe && !semMsg

  // Foto de perfil — coloca placeholder e tenta carregar async
  const photoId = `ph-${chat.id.replace(/[^a-z0-9]/gi, '_')}`

  // Forecast badge (se disponível)
  const fc = forecastsPorChatId.get(chat.id)
  let badgeFc = ''
  if (fc && fc.prob > 5) {
    const cls = fc.prob >= 60 ? 'fc-hot' : fc.prob >= 30 ? 'fc-warm' : 'fc-cold'
    const emo = fc.prob >= 60 ? '🔥' : fc.prob >= 30 ? '♨️' : '❄️'
    const motivoEsc = escapeHtml(fc.motivo || '')
    badgeFc = `<div class="fc-badge ${cls}" title="${motivoEsc}">${emo} ${fc.prob}%</div>`
  }

  $card.innerHTML = `
    ${badgeFc}
    <div class="row1">
      <div class="avatar" id="${photoId}">${escapeHtml(inits)}</div>
      <div class="info">
        <div class="nm">${escapeHtml(nome)}${unread}</div>
        <div class="preview">
          <span class="msg-dir ${dirCls}" title="${escapeHtml(dirTitle)}">${dirIcon}</span>
          ${escapeHtml(preview)}
        </div>
        <div class="meta-row">
          <span class="ago" style="background:${fresc.cor}" title="${escapeHtml(dataFull)}">${ago}</span>
          <span style="font-size:9px;color:var(--text-faint);text-transform:uppercase;letter-spacing:0.5px">${fresc.label}</span>
          <span class="dir-label ${dirCls}" title="${escapeHtml(dirTitle)}">${dirIcon} ${dirLabel}</span>
        </div>
      </div>
    </div>
    <div class="card-actions">
      <button data-action="open" title="Abrir conversa">💬</button>
      <button data-action="send" title="Enviar mensagem rápida">📤</button>
      <button data-action="copy" title="Copiar telefone">📋</button>
    </div>
  `

  // Click no card (não nos botões) abre PREVIEW do chat
  $card.addEventListener('click', (e) => {
    if (e.target.closest('button')) return
    abrirChatPreview(chat)
  })

  // Botões de ação
  $card.querySelectorAll('button[data-action]').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation()
      const action = btn.dataset.action
      if (action === 'open') {
        abrirChat(chat.id)
      } else if (action === 'send') {
        abrirModalEnvio(chat)
      } else if (action === 'copy') {
        const id = chat.id || ''
        // Background já tenta resolver LID → número real. Aqui só usa.
        let numero = chat.number || ''
        // Pra @c.us, se ainda vazio, pega do próprio id
        if (!numero && id.endsWith('@c.us')) {
          numero = id.split('@')[0]
        }
        // Sanitiza só dígitos
        numero = String(numero).replace(/[^\d]/g, '')

        if (id.endsWith('@g.us')) {
          showToast('Grupo não tem telefone único', 'error')
          return
        }
        if (!numero || numero.length < 10) {
          // Última tentativa: resolver LID via background novamente (chat pode ter sido recém-recebido)
          showToast('Buscando número…')
          try {
            const r = await chrome.runtime.sendMessage({
              type: 'BRANORTE_RESOLVER_LID',
              chatId: id,
            })
            if (r?.numero && String(r.numero).length >= 10) {
              numero = String(r.numero).replace(/[^\d]/g, '')
            }
          } catch (_) {}
        }
        if (!numero || numero.length < 10) {
          showToast('Contato sem número público (LID não resolvido)', 'error')
          return
        }
        // Formata: +5548999...
        const formatado = numero.startsWith('+') ? numero : '+' + numero
        try {
          await navigator.clipboard.writeText(formatado)
          showToast(`Copiado: ${formatado}`, 'success')
        } catch (e) {
          // Fallback: usa textarea + execCommand
          try {
            const ta = document.createElement('textarea')
            ta.value = formatado
            document.body.appendChild(ta)
            ta.select()
            document.execCommand('copy')
            ta.remove()
            showToast(`Copiado: ${formatado}`, 'success')
          } catch {
            showToast('Falhou ao copiar: ' + e.message, 'error')
          }
        }
      }
    })
  })

  // Drag start/end
  $card.addEventListener('dragstart', (e) => {
    dragging = { chatId: chat.id, fromColuna, fromLabelId }
    $card.classList.add('dragging')
    e.dataTransfer.effectAllowed = 'move'
  })
  $card.addEventListener('dragend', () => {
    dragging = null
    $card.classList.remove('dragging')
  })

  // Botão direito → menu de etiquetas
  $card.addEventListener('contextmenu', (e) => {
    e.preventDefault()
    abrirMenuEtiquetas(chat, e.clientX, e.clientY)
  })

  // Foto: pede pro background buscar
  buscarFotoPerfil(chat.id).then(url => {
    if (url) {
      const $ph = document.getElementById(photoId)
      if ($ph) $ph.innerHTML = `<img src="${url}" alt="">`
    }
  })

  return $card
}

// Cache de fotos pra evitar pedir múltiplas vezes na mesma sessão
const fotoCache = new Map()
async function buscarFotoPerfil(chatId) {
  if (fotoCache.has(chatId)) return fotoCache.get(chatId)
  try {
    const r = await chrome.runtime.sendMessage({ type: 'BRANORTE_GET_PHOTO', chatId })
    const url = r?.url ?? null
    fotoCache.set(chatId, url)
    return url
  } catch {
    fotoCache.set(chatId, null)
    return null
  }
}

// ===== Botão de ordenação =====
const $ordem = document.getElementById('ordem')
function atualizarBotaoOrdem() {
  $ordem.textContent = ordenacao === 'antigo' ? '🕒 Mais antigo' : '⏰ Mais recente'
  $ordem.title = ordenacao === 'antigo'
    ? 'Mostrando os mais antigos primeiro (chats parados precisam de atenção)'
    : 'Mostrando os mais recentes primeiro'
}
$ordem.addEventListener('click', () => {
  ordenacao = ordenacao === 'antigo' ? 'recente' : 'antigo'
  localStorage.setItem('branorte-crm-ordem', ordenacao)
  atualizarBotaoOrdem()
  if (dadosAtuais) render(dadosAtuais)
})

// ===== Botão "Modo ação" (esconde frescos pra focar em quem precisa) =====
const $modoAcao = document.getElementById('modoAcao')
function atualizarBotaoModoAcao() {
  if (modoAcao) {
    $modoAcao.textContent = '🎯 Modo ação ON'
    $modoAcao.classList.add('ativo')
    $modoAcao.title = 'Mostrando só PARADO/ATENÇÃO/RECENTE (clique pra mostrar todos)'
  } else {
    $modoAcao.textContent = '🎯 Modo ação'
    $modoAcao.classList.remove('ativo')
    $modoAcao.title = 'Esconder frescos (clique pra ver só quem precisa de ação)'
  }
}
$modoAcao.addEventListener('click', () => {
  modoAcao = !modoAcao
  localStorage.setItem('branorte-crm-modo-acao', modoAcao ? '1' : '0')
  atualizarBotaoModoAcao()
  if (dadosAtuais) render(dadosAtuais)
})
atualizarBotaoModoAcao()

// ============================================================================
// MENSAGENS RÁPIDAS
// ============================================================================
const QR_ENDPOINT = 'https://flwbeevtvjiouxdjmziv.supabase.co/functions/v1/quick-replies'
const QR_SECRET = 'branorte-wa-sync-2026'
let quickReplies = []
let qrSearchTerm = ''

const $qrPanel = document.getElementById('qrPanel')
const $qrSearch = document.getElementById('qrSearch')
const $qrList = document.getElementById('qrList')
const $qrModal = document.getElementById('qrModal')
const $sendModal = document.getElementById('sendModal')

async function fetchQuickReplies() {
  const cfg = await chrome.storage.local.get(['vendedor_nome'])
  if (!cfg.vendedor_nome) return []
  try {
    const r = await fetch(`${QR_ENDPOINT}?vendedor=${encodeURIComponent(cfg.vendedor_nome)}`, {
      headers: { 'Authorization': `Bearer ${QR_SECRET}` },
    })
    const j = await r.json()
    return j.items ?? []
  } catch (e) {
    console.error('[QR] fetch err', e)
    return []
  }
}

async function carregarQuickReplies() {
  $qrList.innerHTML = '<div class="empty" style="padding:30px 16px;">Carregando…</div>'
  quickReplies = await fetchQuickReplies()
  renderQuickReplies()
}

function renderQuickReplies() {
  const term = qrSearchTerm.toLowerCase()
  const items = term
    ? quickReplies.filter(qr =>
        (qr.title ?? '').toLowerCase().includes(term) ||
        (qr.body ?? '').toLowerCase().includes(term) ||
        (qr.slug ?? '').toLowerCase().includes(term) ||
        (qr.category ?? '').toLowerCase().includes(term)
      )
    : quickReplies

  if (items.length === 0) {
    $qrList.innerHTML = `<div class="empty" style="padding:30px 16px;">${
      quickReplies.length === 0
        ? 'Nenhuma mensagem rápida ainda.<br>Clica + Nova pra criar.'
        : 'Nenhuma corresponde ao filtro.'
    }</div>`
    return
  }

  $qrList.innerHTML = items.map(qr => `
    <div class="qr-item" data-id="${qr.id}">
      <div class="ti">
        ${qr.slug ? `<span style="color:var(--accent)">/${escapeHtml(qr.slug)}</span>·` : ''}
        ${escapeHtml(qr.title)}
      </div>
      <div class="bd">${escapeHtml(qr.body.slice(0, 80))}${qr.body.length > 80 ? '…' : ''}</div>
      <div class="meta">
        <span class="qr-cat">${escapeHtml(qr.category || 'GERAL')}</span>
        <div class="qr-actions">
          <button data-act="copy" title="Copiar texto">📋</button>
          <button data-act="edit" title="Editar">✏️</button>
          <button data-act="del" class="del" title="Apagar">🗑</button>
        </div>
      </div>
    </div>
  `).join('')

  // Bind eventos
  $qrList.querySelectorAll('.qr-item').forEach($el => {
    const id = $el.dataset.id
    const qr = quickReplies.find(q => q.id === id)
    $el.querySelectorAll('button[data-act]').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation()
        const act = btn.dataset.act
        if (act === 'copy') {
          await navigator.clipboard.writeText(qr.body)
          showToast('Copiado pra área de transferência', 'success')
        } else if (act === 'edit') {
          abrirModalQR(qr)
        } else if (act === 'del') {
          if (!confirm(`Apagar "${qr.title}"?`)) return
          const r = await fetch(`${QR_ENDPOINT}?id=${qr.id}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${QR_SECRET}` },
          })
          if (r.ok) {
            showToast('Apagado', 'success')
            await carregarQuickReplies()
          } else {
            showToast('Falhou ao apagar', 'error')
          }
        }
      })
    })
  })
}

document.getElementById('quickReplies').addEventListener('click', () => {
  $qrPanel.classList.toggle('open')
  if ($qrPanel.classList.contains('open')) carregarQuickReplies()
})
document.getElementById('qrClose').addEventListener('click', () => $qrPanel.classList.remove('open'))
$qrSearch.addEventListener('input', e => { qrSearchTerm = e.target.value; renderQuickReplies() })

// Modal de QR (criar/editar)
function abrirModalQR(qr) {
  document.getElementById('qrModalTitle').textContent = qr ? 'Editar mensagem rápida' : 'Nova mensagem rápida'
  document.getElementById('qrId').value = qr?.id ?? ''
  document.getElementById('qrTitle').value = qr?.title ?? ''
  document.getElementById('qrSlug').value = qr?.slug ?? ''
  document.getElementById('qrCategory').value = qr?.category ?? 'GERAL'
  document.getElementById('qrBody').value = qr?.body ?? ''
  document.getElementById('qrShared').checked = !!qr?.is_shared
  document.getElementById('qrDelete').style.display = qr ? 'inline-block' : 'none'
  $qrModal.classList.add('open')
}
function fecharModalQR() { $qrModal.classList.remove('open') }

document.getElementById('qrNew').addEventListener('click', () => abrirModalQR(null))
document.getElementById('qrCancel').addEventListener('click', fecharModalQR)
document.getElementById('qrModalClose').addEventListener('click', fecharModalQR)

// ===== Export/Import de Backup =====
document.getElementById('qrExport').addEventListener('click', exportarBackup)
document.getElementById('qrImport').addEventListener('click', () => {
  document.getElementById('qrImportFile').click()
})
document.getElementById('qrImportFile').addEventListener('change', async (e) => {
  const file = e.target.files?.[0]
  if (!file) return
  await importarBackup(file)
  e.target.value = ''  // permite re-selecionar mesmo arquivo
})

async function exportarBackup() {
  const cfg = await chrome.storage.local.get(['vendedor_nome'])
  if (!cfg.vendedor_nome) { showToast('Configure o vendedor no popup primeiro', 'error'); return }
  showToast('📦 Gerando backup…')
  const replies = await fetchQuickReplies()
  const dump = {
    formato: 'branorte-crm-backup',
    versao: '1.0',
    exportado_em: new Date().toISOString(),
    vendedor_nome: cfg.vendedor_nome,
    quick_replies: replies.map(qr => ({
      title: qr.title,
      slug: qr.slug,
      category: qr.category,
      body: qr.body,
      is_shared: qr.is_shared,
    })),
    snapshot_etiquetas: dadosAtuais ? dadosAtuais.labels.map(l => ({
      name: l.name,
      color: l.color,
    })) : [],
  }
  const blob = new Blob([JSON.stringify(dump, null, 2)], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)
  a.href = url
  a.download = `branorte-backup-${cfg.vendedor_nome}-${ts}.json`
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
  showToast(`✅ ${replies.length} mensagens exportadas`, 'success')
}

async function importarBackup(file) {
  showToast('📥 Lendo arquivo…')
  let texto, data
  try {
    texto = await file.text()
    data = JSON.parse(texto)
  } catch (e) {
    showToast('❌ Arquivo não é JSON válido', 'error')
    return
  }

  // Detecta formato
  const isNosso = data.formato === 'branorte-crm-backup'
  const isWascript = Array.isArray(data.respostasRapidasAcao) || Array.isArray(data.agendamentos) || data.respostasRapidas
  const isWaSync = Array.isArray(data) && data.length > 0 && data[0].title  // array direto de QRs

  let candidatos = []  // {title, slug, category, body, is_shared}

  if (isNosso && Array.isArray(data.quick_replies)) {
    candidatos = data.quick_replies
  } else if (isWaSync) {
    candidatos = data.map(q => ({
      title: q.title,
      slug: q.slug,
      category: q.category || 'GERAL',
      body: q.body,
      is_shared: !!q.is_shared,
    }))
  } else if (isWascript) {
    // Wascript criptografa respostasRapidas com AES (CryptoJS Salted__).
    // Tenta descriptar pedindo senha ao usuário.
    if (typeof CryptoJS === 'undefined') {
      showToast('❌ CryptoJS não carregado. Reload a página.', 'error', 4000)
      return
    }
    const counts = []
    if (data.respostasRapidasAcao) counts.push(`${data.respostasRapidasAcao.length} ações`)
    if (data.agendamentos) counts.push(`${data.agendamentos.length} agendamentos`)
    if (data.agendamentosNaoDisparados) counts.push(`${data.agendamentosNaoDisparados.length} pendentes`)

    const senha = prompt(`Backup do Wascript detectado.\nConteúdo: ${counts.join(', ')}.\n\nDigite a senha do Wascript pra descriptografar mensagens rápidas:`)
    if (!senha) {
      showToast('Cancelado', 'error')
      return
    }
    let textoDecifrado = null
    try {
      const dec = CryptoJS.AES.decrypt(data.respostasRapidas, senha)
      textoDecifrado = dec.toString(CryptoJS.enc.Utf8)
      if (!textoDecifrado || textoDecifrado.length < 2) throw new Error('senha incorreta')
    } catch (e) {
      showToast('❌ Senha incorreta — não conseguiu descriptografar.', 'error', 4500)
      return
    }
    // O conteúdo decifrado é JSON com as mensagens rápidas do Wascript
    let qrsWascript
    try {
      qrsWascript = JSON.parse(textoDecifrado)
    } catch {
      showToast('❌ Senha correta mas formato inesperado.', 'error', 4500)
      return
    }
    // Wascript estrutura cada QR em { titulo, mensagem, atalho, categoria, ... }
    const arr = Array.isArray(qrsWascript) ? qrsWascript : (qrsWascript.items || qrsWascript.respostas || [])
    candidatos = arr.map(qr => ({
      title: qr.titulo || qr.title || qr.name || 'Sem título',
      slug: qr.atalho || qr.slug || null,
      category: (qr.categoria || qr.category || 'WASCRIPT').toUpperCase().replace(/[^A-Z0-9]/g, '_').slice(0, 30),
      body: qr.mensagem || qr.body || qr.text || '',
      is_shared: false,
    })).filter(qr => qr.body)
    if (candidatos.length === 0) {
      showToast('⚠️ Senha correta mas nenhuma mensagem encontrada', 'error')
      return
    }
  } else {
    showToast('❌ Formato de backup não reconhecido', 'error')
    return
  }

  if (candidatos.length === 0) {
    showToast('⚠️ Nenhuma mensagem rápida no arquivo', 'error')
    return
  }

  if (!confirm(`Importar ${candidatos.length} mensagem(ns) rápida(s) pra sua conta?\n\nMensagens com mesmo título serão duplicadas.`)) return

  const cfg = await chrome.storage.local.get(['vendedor_nome'])
  if (!cfg.vendedor_nome) { showToast('Configure o vendedor primeiro', 'error'); return }

  showToast(`📥 Importando ${candidatos.length}…`)
  let okCount = 0, falhas = 0
  for (const qr of candidatos) {
    if (!qr.title || !qr.body) { falhas++; continue }
    const payload = {
      vendedor_nome: cfg.vendedor_nome,
      title: String(qr.title).slice(0, 200),
      slug: qr.slug ? String(qr.slug).toLowerCase().replace(/[^a-z0-9_-]/g, '') : null,
      category: qr.category || 'GERAL',
      body: String(qr.body),
      is_shared: !!qr.is_shared,
    }
    try {
      const r = await fetch(QR_ENDPOINT, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${QR_SECRET}`, 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      if (r.ok) okCount++; else falhas++
    } catch { falhas++ }
  }
  showToast(`✅ ${okCount} importadas${falhas ? ` · ${falhas} falhas` : ''}`, 'success')
  await carregarQuickReplies()
}

document.getElementById('qrSave').addEventListener('click', async () => {
  const cfg = await chrome.storage.local.get(['vendedor_nome'])
  if (!cfg.vendedor_nome) { showToast('Configure o vendedor no popup primeiro', 'error'); return }
  const id = document.getElementById('qrId').value || undefined
  const payload = {
    id,
    vendedor_nome: cfg.vendedor_nome,
    title: document.getElementById('qrTitle').value.trim(),
    slug: document.getElementById('qrSlug').value.trim().toLowerCase().replace(/[^a-z0-9_-]/g, '') || null,
    category: document.getElementById('qrCategory').value,
    body: document.getElementById('qrBody').value,
    is_shared: document.getElementById('qrShared').checked,
  }
  if (!payload.title || !payload.body) { showToast('Título e texto são obrigatórios', 'error'); return }
  const r = await fetch(QR_ENDPOINT, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${QR_SECRET}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  })
  if (r.ok) {
    showToast(id ? 'Atualizado' : 'Criado', 'success')
    fecharModalQR()
    await carregarQuickReplies()
  } else {
    const j = await r.json().catch(() => ({}))
    showToast('Falhou: ' + (j.error ?? r.status), 'error')
  }
})

document.getElementById('qrDelete').addEventListener('click', async () => {
  const id = document.getElementById('qrId').value
  if (!id) return
  if (!confirm('Apagar mensagem?')) return
  const r = await fetch(`${QR_ENDPOINT}?id=${id}`, {
    method: 'DELETE',
    headers: { 'Authorization': `Bearer ${QR_SECRET}` },
  })
  if (r.ok) {
    showToast('Apagado', 'success')
    fecharModalQR()
    await carregarQuickReplies()
  }
})

// ===== Modal de envio =====
function abrirModalEnvio(chat) {
  document.getElementById('sendChatId').value = chat.id
  document.getElementById('sendChatName').value = chat.name || chat.pushname || chat.number || ''
  document.getElementById('sendTo').value = chat.name || chat.pushname || chat.number || chat.id
  document.getElementById('sendBody').value = ''
  document.getElementById('sendPreview').style.display = 'none'

  // Popula picker com quick replies
  const $picker = document.getElementById('sendPicker')
  $picker.innerHTML = '<option value="">— escolher —</option>'
  // Carrega async se ainda não tem
  if (quickReplies.length === 0) {
    fetchQuickReplies().then(items => {
      quickReplies = items
      preencherPicker(items)
    })
  } else {
    preencherPicker(quickReplies)
  }
  function preencherPicker(items) {
    for (const qr of items) {
      const opt = document.createElement('option')
      opt.value = qr.id
      opt.textContent = (qr.category ? `[${qr.category}] ` : '') + qr.title
      $picker.appendChild(opt)
    }
  }

  $sendModal.classList.add('open')
}
function fecharModalEnvio() { $sendModal.classList.remove('open') }

function resolverVariaveis(texto, chat, vendedor) {
  const nomeChat = chat.name || chat.pushname || chat.number || ''
  const primeiro = nomeChat.split(/\s+/)[0] || ''
  return texto
    .replace(/\{\{nome\}\}/gi, nomeChat)
    .replace(/\{\{primeiro_nome\}\}/gi, primeiro)
    .replace(/\{\{vendedor\}\}/gi, vendedor || '')
}

document.getElementById('sendCancel').addEventListener('click', fecharModalEnvio)
document.getElementById('sendModalClose').addEventListener('click', fecharModalEnvio)

document.getElementById('sendPicker').addEventListener('change', async (e) => {
  const id = e.target.value
  if (!id) return
  const qr = quickReplies.find(q => q.id === id)
  if (!qr) return
  const cfg = await chrome.storage.local.get(['vendedor_nome'])
  const chatId = document.getElementById('sendChatId').value
  const chat = dadosAtuais?.chats?.find(c => c.id === chatId) ?? { id: chatId, name: document.getElementById('sendChatName').value }
  const resolvido = resolverVariaveis(qr.body, chat, cfg.vendedor_nome)
  document.getElementById('sendBody').value = resolvido
})

document.getElementById('sendBody').addEventListener('input', (e) => {
  const $p = document.getElementById('sendPreview')
  if (!e.target.value.includes('{{')) { $p.style.display = 'none'; return }
  $p.style.display = 'block'
  $p.textContent = 'Preview: ' + e.target.value.replace(/\{\{[^}]+\}\}/g, '___')
})

document.getElementById('sendNow').addEventListener('click', async () => {
  const chatId = document.getElementById('sendChatId').value
  let texto = document.getElementById('sendBody').value
  if (!texto.trim()) { showToast('Texto vazio', 'error'); return }
  const cfg = await chrome.storage.local.get(['vendedor_nome'])
  const chat = dadosAtuais?.chats?.find(c => c.id === chatId) ?? { id: chatId, name: '' }
  texto = resolverVariaveis(texto, chat, cfg.vendedor_nome)

  const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' })
  if (!tabs.length) { showToast('Abra web.whatsapp.com', 'error'); return }

  // Identifica qual quick reply foi usado (se foi)
  const qrId = document.getElementById('sendPicker').value
  const $btn = document.getElementById('sendNow')
  $btn.disabled = true; $btn.textContent = 'Enviando…'
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      world: 'MAIN',
      func: async (chatId, mensagem) => {
        try {
          await window.WPP.chat.sendTextMessage(chatId, mensagem)
          return { ok: true }
        } catch (e) {
          return { ok: false, erro: String(e) }
        }
      },
      args: [chatId, texto],
    })
    if (result?.ok) {
      showToast('Mensagem enviada!', 'success')
      // Registra uso da quick reply
      if (qrId) {
        fetch(QR_ENDPOINT, {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${QR_SECRET}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'use', id_uso: qrId }),
        }).catch(() => {})
      }
      fecharModalEnvio()
    } else {
      showToast('Falhou: ' + (result?.erro ?? 'erro'), 'error')
    }
  } catch (e) {
    showToast('Erro: ' + e.message, 'error')
  } finally {
    $btn.disabled = false; $btn.textContent = '📤 Enviar agora'
  }
})

// ============================================================================
// COACH IA
// ============================================================================
const SUPA_FUNCS = 'https://flwbeevtvjiouxdjmziv.supabase.co/functions/v1'
const IA_ENDPOINT = `${SUPA_FUNCS}/coach-ia`
const FB_ENDPOINT = `${SUPA_FUNCS}/coach-feedback`
const ACT_ENDPOINT = `${SUPA_FUNCS}/coach-actions-execute`
const BRIEF_ENDPOINT = `${SUPA_FUNCS}/briefing-diario`
const RAG_ENDPOINT = `${SUPA_FUNCS}/wa-chat-rag`
const FORECAST_LIST_ENDPOINT = `${SUPA_FUNCS}/coach-forecasts-list`

// Carrega forecasts da carteira do vendedor e popula Map global; aplica badges em cards já no DOM
async function carregarForecasts() {
  try {
    const cfg = await chrome.storage.local.get(['vendedor_nome'])
    const vendedor_nome = cfg.vendedor_nome
    if (!vendedor_nome) return
    const r = await fetch(FORECAST_LIST_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${QR_SECRET}` },
      body: JSON.stringify({ vendedor_nome }),
    })
    if (!r.ok) return
    const j = await r.json()
    forecastsPorChatId.clear()
    for (const f of (j.forecasts || [])) forecastsPorChatId.set(f.chat_id, f)
    aplicarBadgesForecast()
  } catch (_) { /* silent */ }
}

// Injeta badge nos cards já presentes no DOM (idempotente)
function aplicarBadgesForecast() {
  document.querySelectorAll('.card[data-chat-id]').forEach($c => {
    const id = $c.dataset.chatId
    const f = forecastsPorChatId.get(id)
    const $old = $c.querySelector('.fc-badge')
    if ($old) $old.remove()
    if (!f || f.prob <= 5) return
    const cls = f.prob >= 60 ? 'fc-hot' : f.prob >= 30 ? 'fc-warm' : 'fc-cold'
    const emo = f.prob >= 60 ? '🔥' : f.prob >= 30 ? '♨️' : '❄️'
    const $b = document.createElement('div')
    $b.className = `fc-badge ${cls}`
    $b.title = f.motivo || ''
    $b.textContent = `${emo} ${f.prob}%`
    $c.insertBefore($b, $c.firstChild)
  })
}
const $iaPanel = document.getElementById('iaPanel')
const $iaMsgs = document.getElementById('iaMsgs')
const $iaInput = document.getElementById('iaInput')
const $iaSend = document.getElementById('iaSend')

let iaHistorico = []
let ultimaInteracaoIA = null  // {pergunta, resposta, estagio, saude, contexto_resumo, chat_id, nome_contato}

document.getElementById('iaCoach').addEventListener('click', () => {
  $iaPanel.classList.toggle('open')
})
document.getElementById('iaClose').addEventListener('click', () => $iaPanel.classList.remove('open'))

document.getElementById('iaSuggestions').addEventListener('click', async (e) => {
  const btnAct = e.target.closest('button[data-action]')
  if (btnAct) {
    const act = btnAct.dataset.action
    if (act === 'briefing') return pedirBriefing()
    if (act === 'rag-prompt') {
      const q = prompt('Buscar trecho semântico nesse chat (precisa estar com chat aberto):')
      if (q && q.trim()) buscarSemantica(q.trim())
      return
    }
    if (act === 'rag-pre-index') {
      const conf = confirm('Indexar os top 100 chats quentes/mornos do vendedor?\n\nVai levar 2-3 min e acelera todas as buscas semânticas futuras.\nCusto: ~$0,15 em embeddings.')
      if (conf) preIndexarTopQuentes(100, 50)
      return
    }
    return
  }
  // Pergunta agregada (data-pid) — rota dedicada com SQL específica
  const btnPid = e.target.closest('button[data-pid]')
  if (btnPid) return enviarPerguntaAgregada(btnPid.dataset.pid, btnPid.textContent.trim())
  const btn = e.target.closest('button[data-q]')
  if (!btn) return
  $iaInput.value = btn.dataset.q
  enviarPergunta()
})

// ============================================================================
// Pergunta agregada — rota dedicada (coach-pergunta-agregada)
// ============================================================================
const AGG_ENDPOINT = `${SUPA_FUNCS}/coach-pergunta-agregada`

async function enviarPerguntaAgregada(pergunta_id, label) {
  adicionarMsg('user', label)
  iaHistorico.push({ role: 'user', content: label })
  const $thinking = adicionarMsg('bot', '⏳ buscando clientes reais da carteira…')
  $thinking.classList.add('thinking')
  try {
    const cfg = await chrome.storage.local.get(['vendedor_nome'])
    const vendedor_nome = cfg.vendedor_nome || 'VENDEDOR'
    const r = await fetch(AGG_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${QR_SECRET}` },
      body: JSON.stringify({ pergunta_id, vendedor_nome }),
    })
    $thinking.remove()
    if (!r.ok) {
      const j = await r.json().catch(() => ({}))
      adicionarMsg('bot', '⚠️ Erro: ' + (j.error || j.detail || r.status))
      return
    }
    const j = await r.json()
    adicionarRespostaIA({
      texto: j.resposta || '(sem resposta)',
      sub_agent: j.sub_agent || 'AGREGADO',
      // Pra agregada, NÃO mostra forecast badge (sem chat focado faz 0% mentir)
      forecast: null,
      actions: [],
      vision_used: false,
      golden_used: 0,
      meta: { vendedor_nome, chat_id: null, nome_contato: null, pergunta: label },
      // extra: clientes resolvidos pra UI poder linkar "abrir chat"
      clientes_agregada: j.clientes,
    })
    iaHistorico.push({ role: 'assistant', content: j.resposta || '' })
  } catch (e) {
    $thinking.remove()
    adicionarMsg('bot', '⚠️ ' + e.message)
  }
}

$iaInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault()
    enviarPergunta()
  }
})
$iaSend.addEventListener('click', enviarPergunta)

function renderMarkdownLeve(md) {
  // Renderização leve: headers, bold, listas, msg, mantém quebras
  let html = String(md || '')
    .replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]))
    // Headers
    .replace(/^##\s+(.+)$/gm, '<h4 class="ia-h">$1</h4>')
    .replace(/^#\s+(.+)$/gm, '<h3 class="ia-h">$1</h3>')
    // Bold
    .replace(/\*\*([^\*]+)\*\*/g, '<b>$1</b>')
    // Italic
    .replace(/\*([^\*\n]+)\*/g, '<i>$1</i>')
    // <msg> blocks → cards destacados (com botão Copiar)
    .replace(/&lt;msg&gt;([\s\S]*?)&lt;\/msg&gt;/gi, (_, body) => {
      const txt = body.trim()
      const enc = encodeURIComponent(txt)
      return `<div class="ia-msgsug" data-msg="${enc}"><div class="ia-msgsug-head"><span>📤 MENSAGEM PRONTA</span><button class="ia-msgsug-copy" type="button">📋 Copiar</button></div><div class="ia-msgsug-body">${txt}</div></div>`
    })
    // Bullets
    .replace(/^[\-\*]\s+(.+)$/gm, '<li>$1</li>')
    .replace(/(<li>.+<\/li>\n?)+/g, m => '<ul class="ia-ul">' + m + '</ul>')
    // Quebras
    .replace(/\n{2,}/g, '<br><br>')
    .replace(/\n/g, '<br>')
  return html
}

function adicionarMsg(role, texto) {
  const $m = document.createElement('div')
  $m.className = `ia-msg ${role === 'user' ? 'user' : 'bot'}`
  if (role === 'user') {
    $m.textContent = texto
  } else {
    $m.innerHTML = renderMarkdownLeve(texto)
    // Wire copy buttons nos cards de <msg>
    $m.querySelectorAll('.ia-msgsug').forEach($card => {
      const $btn = $card.querySelector('.ia-msgsug-copy')
      if (!$btn) return
      $btn.addEventListener('click', async (ev) => {
        ev.stopPropagation()
        try {
          const enc = $card.getAttribute('data-msg') || ''
          const txt = decodeURIComponent(enc)
          await navigator.clipboard.writeText(txt)
          const orig = $btn.textContent
          $btn.textContent = '✅ Copiado'
          $btn.classList.add('copiado')
          setTimeout(() => {
            $btn.textContent = orig
            $btn.classList.remove('copiado')
          }, 1800)
        } catch (e) {
          $btn.textContent = '⚠️ Falhou'
          setTimeout(() => { $btn.textContent = '📋 Copiar' }, 1500)
        }
      })
    })
  }
  $iaMsgs.appendChild($m)
  $iaMsgs.scrollTop = $iaMsgs.scrollHeight
  return $m
}

async function gerarContextoCRM(opts = {}) {
  if (!dadosAtuais) return '(sem dados carregados)'
  const { chats, labels } = dadosAtuais
  const incluirMensagens = opts.incluirMensagens !== false  // default = TRUE
  const idParaCanonico = new Map()
  for (const lbl of labels) idParaCanonico.set(String(lbl.id), canonicalize(lbl.name))

  // Counts por etiqueta
  const counts = new Map()
  let semEtiqueta = 0
  for (const c of chats) {
    const ls = c.labels || []
    if (ls.length === 0) semEtiqueta++
    for (const lid of ls) {
      const cat = idParaCanonico.get(String(lid)) ?? '(?)'
      counts.set(cat, (counts.get(cat) ?? 0) + 1)
    }
  }

  let resumo = `📊 RESUMO DO FUNIL\n` +
               `Total de chats: ${chats.length}\n` +
               `Sem etiqueta (inbox): ${semEtiqueta}\n\nPor etiqueta:\n`
  const nomes = Array.from(counts.keys())
  nomes.sort((a, b) => {
    const ia = ORDEM_FUNIL.indexOf(a)
    const ib = ORDEM_FUNIL.indexOf(b)
    return (ia === -1 ? 999 : ia) - (ib === -1 ? 999 : ib)
  })
  for (const n of nomes) resumo += `  • ${n}: ${counts.get(n)}\n`

  // Top 15 chats relevantes (priorizando LEAD QUENTE > FOLLOW UP > NOVO LEAD)
  const PRIORIDADE = { 'LEAD QUENTE': 1, 'FOLLOW UP': 2, 'NOVO LEAD': 3, 'INTERESSE FUTURO': 4, 'ORCAMENTO ENVIADO': 5, 'PROSPECCAO': 6, '2A TENTATIVA': 7 }
  const ATIVOS = new Set(Object.keys(PRIORIDADE))
  const relevantes = chats.filter(c => {
    const ls = c.labels || []
    return ls.some(lid => ATIVOS.has(idParaCanonico.get(String(lid))))
  }).map(c => {
    const ls = c.labels || []
    const cats = ls.map(lid => idParaCanonico.get(String(lid))).filter(Boolean)
    const minPrio = Math.min(...cats.map(cat => PRIORIDADE[cat] ?? 99))
    return { chat: c, cats, prio: minPrio }
  }).sort((a, b) => {
    if (a.prio !== b.prio) return a.prio - b.prio  // mais prioritário primeiro
    return (a.chat.lastTs ?? 0) - (b.chat.lastTs ?? 0)  // mais antigo primeiro
  }).slice(0, 15)

  resumo += `\n🎯 TOP 15 CHATS ATIVOS (ordenados: prioridade do funil + tempo parado):\n`
  for (const r of relevantes) {
    const c = r.chat
    const nome = c.name || c.pushname || c.number || '?'
    const dias = c.lastTs ? Math.floor((Date.now() - c.lastTs) / 86400_000) : '?'
    const ult = c.lastMessage?.body ? c.lastMessage.body.slice(0, 60) : (c.lastMessage?.type ?? '')
    resumo += `  • ${nome} | ${r.cats.join(', ')} | ${dias}d parado | "${ult}"\n`
  }

  // ============================================================
  // INCLUI ÚLTIMAS MENSAGENS DOS TOP 8 (pra IA ler conversa real)
  // ============================================================
  if (incluirMensagens) {
    const TOP_PARA_LER = relevantes.slice(0, 8)
    const cfg = await chrome.storage.local.get(['vendedor_nome'])
    const vendedor = cfg.vendedor_nome || 'VENDEDOR'

    resumo += `\n💬 ÚLTIMAS MENSAGENS DOS TOP 8 CLIENTES (🟢 EU = vendedor, 🔵 CLIENTE):\n`

    // Busca em paralelo (5 simultâneos)
    const fila = [...TOP_PARA_LER]
    const blocos = []
    async function worker() {
      while (fila.length > 0) {
        const r = fila.shift()
        if (!r) continue
        const c = r.chat
        const nome = c.name || c.pushname || c.number || '?'
        try {
          const msgs = await chrome.runtime.sendMessage({
            type: 'BRANORTE_GET_MESSAGES',
            chatId: c.id,
            count: 5,
          })
          if (!msgs?.ok || !msgs.mensagens?.length) {
            blocos.push(`\n— ${nome} | ${r.cats.join(', ')}: (sem mensagens)`)
            continue
          }
          const linhas = [`\n— ${nome} | ${r.cats.join(', ')}:`]
          const ord = [...msgs.mensagens].sort((a, b) => (a.t ?? 0) - (b.t ?? 0))
          for (const m of ord) {
            const tag = m.fromMe ? `🟢 ${vendedor}` : `🔵 ${nome.split(/\s+/)[0]}`
            let conteudo = ''
            if (m.type === 'chat' || m.type === 'text') conteudo = (m.body || '').slice(0, 200)
            else if (m.type === 'audio' || m.type === 'ptt') conteudo = `[ÁUDIO ${m.duration ? Math.round(m.duration) + 's' : ''} - sem transcrição]`
            else if (m.type === 'image') conteudo = `[IMAGEM${m.caption ? ': ' + m.caption.slice(0, 60) : ''}]`
            else if (m.type === 'video') conteudo = `[VÍDEO]`
            else if (m.type === 'document') conteudo = `[DOC: ${(m.filename || '').slice(0, 40)}]`
            else conteudo = `[${m.type}]`
            linhas.push(`  ${tag}: ${conteudo}`)
          }
          blocos.push(linhas.join('\n'))
        } catch (e) {
          blocos.push(`\n— ${nome}: (erro lendo)`)
        }
      }
    }
    await Promise.all([worker(), worker(), worker(), worker(), worker()])
    resumo += blocos.join('\n')
  }

  return resumo
}

// Detecta se a pergunta livre é agregada (sobre carteira) e roteia
// automaticamente pra coach-pergunta-agregada quando NÃO tem chat focado.
function detectarPerguntaAgregada(p) {
  const s = String(p || '').toLowerCase()
  // Se o vendedor está em 1 chat focado, é provável que ele queira sobre AQUELE cliente
  // (mesmo perguntando "tá quente?"). Só roteia agregada se NÃO há chat focado.
  if (typeof chatAtual !== 'undefined' && chatAtual) return null
  if (/\b(fechar hoje|quem (vai|esta|t[aá]) (mais )?(quente|perto)|fechar agora|quem fechar)\b/.test(s)) return 'fechar_hoje'
  if (/\b(quebrar obje|obje[cç][aã]o|t[aá] caro|pre[cç]o caro|excu[s]?as)\b/.test(s)) return 'quebrar_objecao'
  if (/\b(reanim|sumiu|parados?|esfri|silen|reaproxim)\b/.test(s)) return 'reanimar_parados'
  if (/\b(spin|qualific|needs analysis|qualifica)\b/.test(s)) return 'aplicar_spin'
  if (/\b(diagn[oó]stico|funil|gargalo|onde tr[aá]va|distribui[cç][aã]o)\b/.test(s)) return 'diagnostico_funil'
  if (/\b(risco|escapando|perdendo|fugindo|amea[cç]a)\b/.test(s)) return 'em_risco'
  if (/\b(reativar quente|quente[s]? parad|esfriou|esquent)\b/.test(s)) return 'reativar_quentes'
  return null
}

async function enviarPergunta() {
  const pergunta = $iaInput.value.trim()
  if (!pergunta) return
  $iaInput.value = ''
  // Roteia perguntas livres agregadas (carteira) pra rota dedicada
  const pid = detectarPerguntaAgregada(pergunta)
  if (pid) return enviarPerguntaAgregada(pid, pergunta)
  adicionarMsg('user', pergunta)
  iaHistorico.push({ role: 'user', content: pergunta })

  const $thinking = adicionarMsg('bot', '⏳ lendo conversas dos top clientes…')
  $thinking.classList.add('thinking')

  $iaSend.disabled = true
  try {
    const cfg = await chrome.storage.local.get(['vendedor_nome'])
    const vendedor_nome = cfg.vendedor_nome || 'VENDEDOR'
    const contexto = await gerarContextoCRM({ incluirMensagens: true })
    // chat focado: se há preview aberto, foca; senão null
    const chatFocado = (typeof chatAtual !== 'undefined' && chatAtual) ? chatAtual : null
    const chat_id = chatFocado?.id || null
    const nome_contato = chatFocado ? (chatFocado.name || chatFocado.pushname || chatFocado.number || null) : null
    // últimas mensagens do chat focado (se houver)
    let mensagens_chat = null
    let imagens_url = null
    if (chat_id) {
      try {
        const msgs = await chrome.runtime.sendMessage({ type: 'BRANORTE_GET_MESSAGES', chatId: chat_id, count: 30 })
        if (msgs?.ok && Array.isArray(msgs.mensagens)) {
          mensagens_chat = msgs.mensagens
          // colhe URLs públicas de imagens recentes (até 3)
          const imgs = msgs.mensagens.filter(m => m.type === 'image' && (m.url || m.deprecatedMms3Url)).slice(-3)
          if (imgs.length) imagens_url = imgs.map(m => m.url || m.deprecatedMms3Url).filter(Boolean)
        }
      } catch (_) { /* ignore */ }
    }
    $thinking.textContent = '⏳ analisando…'
    const r = await fetch(IA_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${QR_SECRET}` },
      body: JSON.stringify({
        vendedor_nome,
        pergunta,
        contexto,
        historico: iaHistorico.slice(-6, -1),
        chat_id,
        nome_contato,
        mensagens_chat,
        imagens_url,
      }),
    })
    $thinking.remove()
    if (!r.ok) {
      const j = await r.json().catch(() => ({}))
      adicionarMsg('bot', '⚠️ Erro: ' + (j.error || j.detail || r.status))
      return
    }
    const j = await r.json()
    const resp = j.resposta || '(sem resposta)'
    // Adiciona resposta enriquecida (sub-agent badge + forecast + actions + feedback)
    adicionarRespostaIA({
      texto: resp,
      sub_agent: j.sub_agent,
      estagio: j.estagio,
      saude: j.saude,
      forecast: j.forecast,
      actions: Array.isArray(j.actions) ? j.actions : [],
      vision_used: j.vision_used,
      golden_used: j.golden_used,
      meta: { vendedor_nome, chat_id, nome_contato, pergunta },
    })
    iaHistorico.push({ role: 'assistant', content: resp })
    ultimaInteracaoIA = {
      vendedor_nome, chat_id, nome_contato,
      pergunta, resposta: resp,
      estagio: j.estagio, saude: j.saude,
      contexto_resumo: pergunta + ' | ' + (nome_contato || 'carteira'),
    }
  } catch (e) {
    $thinking.remove()
    adicionarMsg('bot', '⚠️ Erro: ' + e.message)
  } finally {
    $iaSend.disabled = false
  }
}

// ============================================================================
// Resposta enriquecida da IA: badges + actions + feedback
// ============================================================================
function adicionarRespostaIA(dados) {
  const $m = document.createElement('div')
  $m.className = 'ia-msg bot'
  $m.innerHTML = renderMarkdownLeve(dados.texto)
  // Wire copy buttons nos cards de <msg>
  $m.querySelectorAll('.ia-msgsug').forEach($card => {
    const $btn = $card.querySelector('.ia-msgsug-copy')
    if (!$btn) return
    $btn.addEventListener('click', async (ev) => {
      ev.stopPropagation()
      try {
        const enc = $card.getAttribute('data-msg') || ''
        const txt = decodeURIComponent(enc)
        await navigator.clipboard.writeText(txt)
        $btn.textContent = '✅ Copiado'
        $btn.classList.add('copiado')
        setTimeout(() => { $btn.textContent = '📋 Copiar'; $btn.classList.remove('copiado') }, 1800)
      } catch (e) {
        $btn.textContent = '⚠️ Falhou'
        setTimeout(() => { $btn.textContent = '📋 Copiar' }, 1500)
      }
    })
  })
  // Footer enriquecido
  const $foot = document.createElement('div')
  $foot.className = 'ia-foot'
  // Badges
  const badges = []
  if (dados.sub_agent) badges.push(`<span class="ia-badge ia-badge-sub" title="Sub-agente acionado">🤖 ${dados.sub_agent}</span>`)
  if (dados.forecast && typeof dados.forecast.probabilidade === 'number') {
    const p = dados.forecast.probabilidade
    const cor = p >= 60 ? 'hot' : p >= 30 ? 'warm' : 'cold'
    const emo = p >= 60 ? '🔥' : p >= 30 ? '♨️' : '❄️'
    badges.push(`<span class="ia-badge ia-badge-${cor}" title="${dados.forecast.motivo || ''}">${emo} ${p}% chance fechar</span>`)
  }
  if (dados.vision_used) badges.push(`<span class="ia-badge ia-badge-vision" title="Analisei imagens do cliente">👁️ vision</span>`)
  if (dados.golden_used > 0) badges.push(`<span class="ia-badge ia-badge-golden" title="Usei ${dados.golden_used} exemplo(s) que você curtiu antes">⭐ ${dados.golden_used} golden</span>`)
  if (badges.length) $foot.insertAdjacentHTML('beforeend', `<div class="ia-badges">${badges.join('')}</div>`)
  // Actions cards
  if (dados.actions && dados.actions.length > 0) {
    const $actBox = document.createElement('div')
    $actBox.className = 'ia-actions'
    $actBox.innerHTML = `<div class="ia-actions-head">🛠️ Ações sugeridas — você aprova:</div>`
    for (const a of dados.actions) {
      $actBox.appendChild(renderActionCard(a, dados.meta))
    }
    $foot.appendChild($actBox)
  }
  // Feedback
  const $fb = document.createElement('div')
  $fb.className = 'ia-fb'
  $fb.innerHTML = `<span class="ia-fb-label">útil?</span>
    <button class="ia-fb-btn" data-fb="1" type="button" title="Curtir resposta">👍</button>
    <button class="ia-fb-btn" data-fb="-1" type="button" title="Não curtir">👎</button>`
  $fb.addEventListener('click', async (ev) => {
    const $b = ev.target.closest('button[data-fb]')
    if (!$b) return
    const rating = parseInt($b.dataset.fb, 10)
    $fb.querySelectorAll('button').forEach(x => x.disabled = true)
    $b.classList.add('ativo')
    try {
      await fetch(FB_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${QR_SECRET}` },
        body: JSON.stringify({
          vendedor_nome: dados.meta.vendedor_nome,
          chat_id: dados.meta.chat_id,
          nome_contato: dados.meta.nome_contato,
          pergunta: dados.meta.pergunta,
          resposta: dados.texto,
          estagio: dados.estagio,
          saude: dados.saude,
          rating,
          contexto_resumo: dados.meta.pergunta + ' | ' + (dados.meta.nome_contato || ''),
        }),
      })
      $fb.insertAdjacentHTML('beforeend', `<span class="ia-fb-ok">${rating === 1 ? '⭐ salvo como exemplo' : 'feedback registrado'}</span>`)
    } catch (e) {
      $fb.insertAdjacentHTML('beforeend', `<span class="ia-fb-err">⚠️</span>`)
    }
  })
  $foot.appendChild($fb)
  $m.appendChild($foot)
  $iaMsgs.appendChild($m)
  $iaMsgs.scrollTop = $iaMsgs.scrollHeight
}

function renderActionCard(a, meta) {
  const $c = document.createElement('div')
  $c.className = 'ia-act-card'
  const tipoIcon = {
    criar_lembrete: '⏰',
    salvar_nota: '📝',
    agendar_followup_draft: '📤',
    marcar_etiqueta_sugerida: '🏷️',
    propor_kanban: '📌',
  }[a.action_type || a.type] || '🔧'
  const tipoLabel = {
    criar_lembrete: 'Criar lembrete',
    salvar_nota: 'Salvar nota',
    agendar_followup_draft: 'Preparar draft de follow-up',
    marcar_etiqueta_sugerida: 'Sugerir etiqueta',
    propor_kanban: 'Sugerir mover Kanban',
  }[a.action_type || a.type] || (a.action_type || a.type)
  const p = a.payload || a  // backend pode enviar com ou sem wrap
  const detalhes = []
  if (p.quando_relativo) detalhes.push(`📅 <b>${escapeHtml(p.quando_relativo)}</b>`)
  if (p.mensagem) detalhes.push(`💬 ${escapeHtml(p.mensagem)}`)
  if (p.texto) detalhes.push(`📝 ${escapeHtml(p.texto)}`)
  if (p.texto_msg) detalhes.push(`✉️ "${escapeHtml(p.texto_msg.slice(0, 140))}${p.texto_msg.length > 140 ? '…' : ''}"`)
  if (p.etiqueta) detalhes.push(`🏷️ <b>${escapeHtml(p.etiqueta)}</b>`)
  if (p.coluna) detalhes.push(`📌 → <b>${escapeHtml(p.coluna)}</b>`)
  if (p.motivo) detalhes.push(`<i>motivo: ${escapeHtml(p.motivo)}</i>`)
  $c.innerHTML = `
    <div class="ia-act-head"><span class="ia-act-icon">${tipoIcon}</span><b>${tipoLabel}</b></div>
    <div class="ia-act-body">${detalhes.join('<br>')}</div>
    <div class="ia-act-foot">
      <button class="ia-act-btn ia-act-ok" type="button" ${a.id ? '' : 'disabled title="Action sem id, não persistida"'}>✅ Executar</button>
      <button class="ia-act-btn ia-act-no" type="button" ${a.id ? '' : 'disabled'}>❌ Rejeitar</button>
      <span class="ia-act-status"></span>
    </div>`
  if (!a.id) return $c
  const $ok = $c.querySelector('.ia-act-ok')
  const $no = $c.querySelector('.ia-act-no')
  const $st = $c.querySelector('.ia-act-status')
  async function decidir(decisao) {
    $ok.disabled = true; $no.disabled = true
    $st.textContent = decisao === 'approve' ? '⏳ executando…' : '⏳ rejeitando…'
    try {
      const r = await fetch(ACT_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${QR_SECRET}` },
        body: JSON.stringify({ action_id: a.id, decisao }),
      })
      const j = await r.json().catch(() => ({}))
      if (j.ok) {
        $st.innerHTML = decisao === 'approve' ? '✅ <b>executado</b>' : '🚫 rejeitado'
        $c.classList.add(decisao === 'approve' ? 'ia-act-done' : 'ia-act-skip')
      } else {
        $st.innerHTML = `⚠️ ${j.error || j.erro || 'erro'}`
      }
    } catch (e) {
      $st.textContent = '⚠️ ' + e.message
    }
  }
  $ok.addEventListener('click', () => decidir('approve'))
  $no.addEventListener('click', () => decidir('reject'))
  return $c
}

function escapeHtml(s) {
  return String(s || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]))
}

// ============================================================================
// Briefing diário — botão dispara modal/inline com resumo da carteira
// ============================================================================
async function pedirBriefing(forceRegen = false) {
  const cfg = await chrome.storage.local.get(['vendedor_nome'])
  const vendedor_nome = cfg.vendedor_nome || 'VENDEDOR'
  const $thinking = adicionarMsg('bot', '🌅 montando briefing diário…')
  $thinking.classList.add('thinking')
  try {
    const r = await fetch(BRIEF_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${QR_SECRET}` },
      body: JSON.stringify({ vendedor_nome, force_regen: forceRegen }),
    })
    $thinking.remove()
    if (!r.ok) { adicionarMsg('bot', '⚠️ erro briefing'); return }
    const j = await r.json()
    const md = j?.briefing?.resumo_md || '(sem briefing)'
    // Converte WhatsApp-bold (*texto*) → markdown ** + headers
    const adaptado = md.replace(/\*([^*\n]+)\*/g, '**$1**')
    adicionarMsg('bot', `## 🌅 Briefing diário\n${adaptado}\n\n${j.cached ? '_(cache de hoje — ✨ pra regerar use o botão de novo)_' : '_(geradinho agora)_'}`)
  } catch (e) {
    $thinking.remove()
    adicionarMsg('bot', '⚠️ ' + e.message)
  }
}

// ============================================================================
// RAG — busca semântica nas mensagens do chat aberto
// ============================================================================
// ============================================================================
// Pré-indexar top N chats quentes pra acelerar primeira busca semântica
// Roda no FRONTEND (acesso direto às mensagens via wa-js)
// ============================================================================
async function preIndexarTopQuentes(maxChats = 100, msgsPorChat = 50) {
  const cfg = await chrome.storage.local.get(['vendedor_nome'])
  const vendedor_nome = cfg.vendedor_nome || 'VENDEDOR'
  // Top N chats com forecast prob >= 30 (ativos quentes/mornos)
  const candidatos = Array.from(forecastsPorChatId.entries())
    .filter(([_, f]) => f.prob >= 30)
    .sort((a, b) => b[1].prob - a[1].prob)
    .slice(0, maxChats)
    .map(([chat_id]) => chat_id)
  if (candidatos.length === 0) {
    return adicionarMsg('bot', '⚠️ Nenhum chat ativo com forecast ≥ 30%. Carrega o Kanban primeiro.')
  }
  const $thinking = adicionarMsg('bot', `🧠 indexando ${candidatos.length} chats… (vai levar 2-3 min)`)
  $thinking.classList.add('thinking')
  let ok = 0, falha = 0, vazio = 0
  const CONCORRENCIA = 3
  let cursor = 0
  async function worker() {
    while (cursor < candidatos.length) {
      const chat_id = candidatos[cursor++]
      try {
        const msgs = await chrome.runtime.sendMessage({ type: 'BRANORTE_GET_MESSAGES', chatId: chat_id, count: msgsPorChat })
        if (!msgs?.ok || !Array.isArray(msgs.mensagens) || msgs.mensagens.length === 0) {
          vazio++; continue
        }
        const r = await fetch(RAG_ENDPOINT, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${QR_SECRET}` },
          body: JSON.stringify({ op: 'index', chat_id, vendedor_nome, mensagens: msgs.mensagens }),
        })
        if (r.ok) ok++; else falha++
      } catch (_) { falha++ }
      if ((ok + falha + vazio) % 10 === 0) {
        $thinking.textContent = `🧠 ${ok + falha + vazio}/${candidatos.length} (✅${ok} · ⚠️${falha} · 🤷${vazio})`
      }
    }
  }
  await Promise.all(Array.from({ length: CONCORRENCIA }, () => worker()))
  $thinking.remove()
  adicionarMsg('bot', `## ✅ Indexação concluída\n- **${ok}** chats indexados\n- **${falha}** falhas\n- **${vazio}** sem mensagens\n\nAgora a busca semântica (🔎) acha trechos antigos sem precisar abrir o chat antes.`)
}

async function buscarSemantica(query) {
  if (!chatAtual) return adicionarMsg('bot', '⚠️ Abre um chat primeiro pra buscar nele.')
  const $thinking = adicionarMsg('bot', '🔍 buscando…')
  $thinking.classList.add('thinking')
  try {
    // Indexa antes (best-effort)
    const msgs = await chrome.runtime.sendMessage({ type: 'BRANORTE_GET_MESSAGES', chatId: chatAtual.id, count: 200 })
    if (msgs?.ok && Array.isArray(msgs.mensagens)) {
      const cfg = await chrome.storage.local.get(['vendedor_nome'])
      fetch(RAG_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${QR_SECRET}` },
        body: JSON.stringify({ op: 'index', chat_id: chatAtual.id, vendedor_nome: cfg.vendedor_nome || 'VENDEDOR', mensagens: msgs.mensagens }),
      }).catch(() => {})
    }
    const r = await fetch(RAG_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${QR_SECRET}` },
      body: JSON.stringify({ op: 'search', chat_id: chatAtual.id, query, limit: 5 }),
    })
    $thinking.remove()
    if (!r.ok) { adicionarMsg('bot', '⚠️ erro RAG'); return }
    const j = await r.json()
    const hits = j.hits || []
    if (!hits.length) { adicionarMsg('bot', '🤷 Não achei nada similar nesse chat.'); return }
    let md = `## 🔍 ${hits.length} trechos mais similares\n`
    for (const h of hits) {
      const tag = h.from_me ? '🟢 EU' : '🔵 CLIENTE'
      const data = h.data_msg ? new Date(h.data_msg).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : ''
      md += `\n- **${tag}** _(${data}, ${Math.round(h.similarity * 100)}% match)_:\n  "${h.conteudo.slice(0, 250)}"\n`
    }
    adicionarMsg('bot', md)
  } catch (e) {
    $thinking.remove()
    adicionarMsg('bot', '⚠️ ' + e.message)
  }
}

// ============================================================================
// CHAT PREVIEW MODAL
// ============================================================================
const $chatBg = document.getElementById('chatBg')
const $chatNm = document.getElementById('chatNm')
const $chatPh = document.getElementById('chatPh')
const $chatAv = document.getElementById('chatAv')
const $chatMsgs = document.getElementById('chatMsgs')
const $chatInput = document.getElementById('chatInput')
const $chatSend = document.getElementById('chatSend')
const $lightbox = document.getElementById('lightbox')
const $lightboxImg = document.getElementById('lightboxImg')

let chatAtual = null  // chat object atualmente aberto no preview

function fecharChatPreview() { $chatBg.classList.remove('open') }
document.getElementById('chatClose').addEventListener('click', fecharChatPreview)
$chatBg.addEventListener('click', (e) => { if (e.target === $chatBg) fecharChatPreview() })

document.getElementById('chatRefresh').addEventListener('click', async () => {
  if (chatAtual) await abrirChatPreview(chatAtual)
})
document.getElementById('chatOpenWA').addEventListener('click', () => {
  if (chatAtual) abrirChat(chatAtual.id)
})
document.getElementById('chatQrPick').addEventListener('click', () => {
  if (chatAtual) abrirModalEnvio(chatAtual)
})

// ===== Chat IA Modal =====
const $chatIaModal = document.getElementById('chatIaModal')
const $chatIaName = document.getElementById('chatIaName')
const $chatIaInput = document.getElementById('chatIaInput')
const $chatIaSend = document.getElementById('chatIaSend')
const $chatIaResp = document.getElementById('chatIaResp')

document.getElementById('chatIaBtn').addEventListener('click', () => {
  if (!chatAtual) return
  $chatIaName.textContent = chatAtual.name || chatAtual.pushname || chatAtual.number || 'cliente'
  $chatIaInput.value = ''
  $chatIaResp.textContent = '👋 Escolhe uma opção rápida acima ou pergunta livre. A IA vai analisar a conversa toda do cliente.'
  $chatIaModal.classList.add('open')
})
document.getElementById('chatIaClose').addEventListener('click', () => $chatIaModal.classList.remove('open'))

document.querySelectorAll('.qia-quick').forEach(btn => {
  btn.addEventListener('click', () => {
    $chatIaInput.value = btn.dataset.q
    perguntarIaSobreChat()
  })
})

$chatIaSend.addEventListener('click', perguntarIaSobreChat)
$chatIaInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault()
    perguntarIaSobreChat()
  }
})

async function perguntarIaSobreChat() {
  if (!chatAtual) return
  const pergunta = $chatIaInput.value.trim()
  if (!pergunta) return

  $chatIaSend.disabled = true
  $chatIaResp.textContent = '⏳ Lendo conversa e analisando…'

  try {
    // Busca mensagens fresh (até 100)
    const r = await chrome.runtime.sendMessage({
      type: 'BRANORTE_GET_MESSAGES',
      chatId: chatAtual.id,
      count: 100,
    })
    if (!r?.ok) {
      $chatIaResp.textContent = '⚠️ Não consegui ler as mensagens: ' + (r?.erro ?? 'erro')
      return
    }

    const cfg = await chrome.storage.local.get(['vendedor_nome'])
    const nome = chatAtual.name || chatAtual.pushname || chatAtual.number || 'cliente'

    const ia = await fetch(IA_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${QR_SECRET}`,
      },
      body: JSON.stringify({
        vendedor_nome: cfg.vendedor_nome || 'VENDEDOR',
        pergunta,
        nome_contato: nome,
        mensagens_chat: r.mensagens,
        contexto: `Cliente: ${nome}, etiquetas: ${(chatAtual.labels || []).join(', ') || '(nenhuma)'}, dias parado: ${chatAtual.lastTs ? Math.floor((Date.now() - chatAtual.lastTs) / 86400000) : '?'}.`,
      }),
    })

    if (!ia.ok) {
      const j = await ia.json().catch(() => ({}))
      $chatIaResp.textContent = '⚠️ Erro IA: ' + (j.error || j.detail || ia.status)
      return
    }
    const j = await ia.json()
    $chatIaResp.textContent = j.resposta || '(sem resposta)'
  } catch (e) {
    $chatIaResp.textContent = '⚠️ ' + e.message
  } finally {
    $chatIaSend.disabled = false
  }
}

$lightbox.addEventListener('click', () => $lightbox.classList.remove('open'))

function fmtTimestamp(ms) {
  if (!ms) return ''
  const d = new Date(ms)
  const hoje = new Date()
  const sameDay = d.toDateString() === hoje.toDateString()
  if (sameDay) return d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
  return d.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })
}

async function abrirChatPreview(chat) {
  chatAtual = chat
  $chatBg.classList.add('open')

  const nome = chat.name || chat.pushname || chat.formattedTitle || chat.number || 'Sem nome'
  $chatNm.textContent = nome
  $chatPh.textContent = chat.number ? `+${chat.number}` : ''
  $chatAv.innerHTML = iniciais(nome)
  // tenta foto
  buscarFotoPerfil(chat.id).then(url => {
    if (url) $chatAv.innerHTML = `<img src="${url}" alt="">`
  })

  $chatMsgs.innerHTML = '<div class="loading-msg">⏳ Carregando mensagens…</div>'
  $chatInput.value = ''

  const r = await chrome.runtime.sendMessage({
    type: 'BRANORTE_GET_MESSAGES',
    chatId: chat.id,
    count: 50,
  })
  if (!r?.ok) {
    $chatMsgs.innerHTML = `<div class="loading-msg">⚠️ ${escapeHtml(r?.erro ?? 'erro')}</div>`
    return
  }
  renderMensagens(r.mensagens, chat.id)
}

function renderMensagens(msgs, chatId) {
  if (!msgs.length) {
    $chatMsgs.innerHTML = '<div class="loading-msg">Sem mensagens ainda</div>'
    return
  }
  // ordena por timestamp asc
  const ordenadas = [...msgs].sort((a, b) => (a.t ?? 0) - (b.t ?? 0))
  const $list = document.createElement('div')
  $list.className = 'msgs-list'

  let ultimoDia = ''
  for (const m of ordenadas) {
    const tsMs = (m.t ?? 0) * 1000
    const dia = tsMs ? new Date(tsMs).toLocaleDateString('pt-BR') : ''
    if (dia && dia !== ultimoDia) {
      const $sep = document.createElement('div')
      $sep.className = 'chat-bubble system'
      $sep.textContent = dia
      $list.appendChild($sep)
      ultimoDia = dia
    }
    $list.appendChild(criarBubble(m, chatId))
  }
  $chatMsgs.innerHTML = ''
  $chatMsgs.appendChild($list)
  // scroll pro fim
  $chatMsgs.scrollTop = $chatMsgs.scrollHeight
}

function criarBubble(m, chatId) {
  const $b = document.createElement('div')
  $b.className = `chat-bubble ${m.fromMe ? 'me' : 'them'}`
  const ts = m.t ? fmtTimestamp(m.t * 1000) : ''

  if (m.type === 'chat' || m.type === 'text') {
    $b.innerHTML = `<div>${escapeHtml(m.body)}</div><div class="ts">${ts}</div>`
  } else if (m.type === 'audio' || m.type === 'ptt') {
    $b.innerHTML = `
      <div style="display:flex; align-items:center; gap:6px; cursor:pointer;">
        <span>🎙️</span>
        <span class="placeholder" data-msg-id="${m.id}">Áudio (clica pra carregar)</span>
      </div>
      <div class="ts">${ts}</div>
    `
    $b.querySelector('span[data-msg-id]').addEventListener('click', async (e) => {
      const $ph = e.target
      $ph.textContent = '⏳ Baixando…'
      const url = await downloadMediaToObjectURL(chatId, m.id)
      if (url) {
        const $audio = document.createElement('audio')
        $audio.controls = true
        $audio.src = url
        $audio.style.maxWidth = '280px'
        $audio.style.height = '40px'
        $audio.addEventListener('error', () => {
          $audio.replaceWith(Object.assign(document.createElement('span'), { textContent: '⚠️ Não toca neste navegador', className: 'placeholder' }))
        })
        $ph.replaceWith($audio)
      } else {
        $ph.textContent = '⚠️ Falhou'
      }
    })
  } else if (m.type === 'image') {
    $b.innerHTML = `
      <div style="display:flex; align-items:center; gap:6px; cursor:pointer;" data-msg-id="${m.id}">
        <span>🖼️</span>
        <span class="placeholder">Imagem (clica pra ver)</span>
      </div>
      ${m.caption ? `<div class="caption">${escapeHtml(m.caption)}</div>` : ''}
      <div class="ts">${ts}</div>
    `
    $b.querySelector('[data-msg-id]').addEventListener('click', async (e) => {
      const $row = e.currentTarget
      $row.innerHTML = '<span>⏳ Baixando imagem…</span>'
      const url = await downloadMediaToObjectURL(chatId, m.id)
      if (url) {
        const $img = document.createElement('img')
        $img.className = 'media'
        $img.src = url
        $img.addEventListener('click', () => {
          $lightboxImg.src = url
          $lightbox.classList.add('open')
        })
        $row.replaceWith($img)
      } else {
        $row.innerHTML = '<span>⚠️ Falhou</span>'
      }
    })
  } else if (m.type === 'video') {
    $b.innerHTML = `
      <div style="display:flex; align-items:center; gap:6px; cursor:pointer;" data-msg-id="${m.id}">
        <span>🎥</span>
        <span class="placeholder">Vídeo (clica pra carregar)</span>
      </div>
      ${m.caption ? `<div class="caption">${escapeHtml(m.caption)}</div>` : ''}
      <div class="ts">${ts}</div>
    `
    $b.querySelector('[data-msg-id]').addEventListener('click', async (e) => {
      const $row = e.currentTarget
      $row.innerHTML = '<span>⏳ Baixando vídeo…</span>'
      const url = await downloadMediaToObjectURL(chatId, m.id)
      if (url) {
        const $v = document.createElement('video')
        $v.className = 'media'
        $v.controls = true
        $v.src = url
        $row.replaceWith($v)
      } else {
        $row.innerHTML = '<span>⚠️ Falhou</span>'
      }
    })
  } else if (m.type === 'document') {
    $b.innerHTML = `
      <div class="doc" data-msg-id="${m.id}">
        <span>📄</span>
        <div>
          <div style="font-size:12px;font-weight:600;">${escapeHtml(m.filename ?? 'Documento')}</div>
          <div style="font-size:10px;opacity:0.6;">${escapeHtml(m.mimetype ?? '')}</div>
        </div>
      </div>
      <div class="ts">${ts}</div>
    `
    $b.querySelector('.doc').addEventListener('click', async () => {
      showToast('Baixando documento…')
      const url = await downloadMediaToObjectURL(chatId, m.id)
      if (url) {
        const a = document.createElement('a')
        a.href = url
        a.download = m.filename || 'documento'
        a.click()
        showToast('Pronto', 'success')
      } else { showToast('Falhou', 'error') }
    })
  } else if (m.type === 'sticker') {
    $b.innerHTML = `<div>🩷 Figurinha</div><div class="ts">${ts}</div>`
  } else if (m.type === 'location') {
    $b.innerHTML = `<div>📍 Localização</div><div class="ts">${ts}</div>`
  } else if (m.type === 'vcard') {
    $b.innerHTML = `<div>👤 Contato compartilhado</div><div class="ts">${ts}</div>`
  } else {
    $b.innerHTML = `<div class="placeholder">[${escapeHtml(m.type)}]</div><div class="ts">${ts}</div>`
  }
  return $b
}

// Enviar mensagem inline
$chatInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault()
    enviarMensagemInline()
  }
})
$chatSend.addEventListener('click', enviarMensagemInline)

async function enviarMensagemInline() {
  if (!chatAtual) return
  const texto = $chatInput.value.trim()
  if (!texto) return
  $chatSend.disabled = true
  try {
    const r = await chrome.runtime.sendMessage({
      type: 'BRANORTE_SEND_TEXT',
      chatId: chatAtual.id,
      texto,
    })
    if (r?.ok) {
      $chatInput.value = ''
      // Adiciona msg na UI imediatamente (otimista)
      const $list = $chatMsgs.querySelector('.msgs-list')
      if ($list) {
        $list.appendChild(criarBubble({
          id: 'tmp_' + Date.now(),
          type: 'chat',
          body: texto,
          t: Math.floor(Date.now() / 1000),
          fromMe: true,
        }, chatAtual.id))
        $chatMsgs.scrollTop = $chatMsgs.scrollHeight
      }
      showToast('Enviado', 'success')
    } else {
      showToast('Falhou: ' + (r?.erro ?? 'erro'), 'error')
    }
  } catch (e) {
    showToast('Erro: ' + e.message, 'error')
  } finally {
    $chatSend.disabled = false
  }
}

// ===== Init =====
async function init() {
  carregarTema()
  atualizarBotaoOrdem()
  $reload.addEventListener('click', async () => {
    $reload.disabled = true
    fotoCache.clear()
    const data = await buscarDados()
    if (data) render(data)
    $reload.disabled = false
  })

  const data = await buscarDados()
  if (data) render(data)

  // Abre painel/coach automaticamente baseado no hash da URL (vindo da sidebar do WA)
  const hash = window.location.hash.toLowerCase()
  if (hash === '#qr') {
    setTimeout(() => {
      $qrPanel.classList.add('open')
      carregarQuickReplies()
    }, 200)
  } else if (hash === '#ia') {
    setTimeout(() => $iaPanel.classList.add('open'), 200)
  } else if (hash === '#analyze') {
    // Abre análise do chat atualmente ativo no WhatsApp Web
    const cfg = await chrome.storage.local.get(['analyze_target'])
    const target = cfg.analyze_target
    if (target?.id) {
      setTimeout(async () => {
        // Abre o chat preview (busca o chat completo dos dados se já tiver)
        const chat = data?.chats?.find(c => c.id === target.id) ?? {
          id: target.id,
          name: target.name,
          number: target.number,
          labels: target.labels,
          unreadCount: 0,
        }
        await abrirChatPreview(chat)
        // Após preview carregar, abre IA modal
        setTimeout(() => {
          chatAtual = chat
          document.getElementById('chatIaBtn').click()
        }, 800)
      }, 300)
      // limpa
      chrome.storage.local.remove('analyze_target')
    }
  }
}

init()
