// popup.js — UI do popup
const $vendedor = document.getElementById('vendedor')
const $btn = document.getElementById('syncNow')
const $stats = document.getElementById('stats')
const $list = document.getElementById('etiquetas-list')
const $liveDot = document.getElementById('live-dot')
const $liveText = document.getElementById('live-text')

function fmtAgo(ts) {
  if (!ts) return 'nunca'
  const sec = Math.round((Date.now() - ts) / 1000)
  if (sec < 5) return 'agora'
  if (sec < 60) return `há ${sec}s`
  const min = Math.round(sec / 60)
  if (min < 60) return `há ${min} min`
  const h = Math.round(min / 60)
  if (h < 24) return `há ${h}h`
  return `há ${Math.round(h / 24)}d`
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]))
}

// Classificação simplificada (mesma lógica do CRM)
function classify(name) {
  const n = String(name).normalize('NFKD').replace(/[̀-ͯ]/g, '').toUpperCase().trim()
  if (n === 'VENDIDO' || n === 'VENDIDOS' || n.startsWith('CLIENTES ')) return 'vendido'
  if (n.startsWith('ORCAMENTO')) return 'orcamento'
  if (['PROSPECCAO', 'FOLLOW UP', 'FOLLOWUP', 'FALLOW UP', 'INTERESSE FUTURO',
       '2A TENTATIVA', 'LEAD QUENTE', 'QUENTE', 'AGENDAMENTO'].includes(n)) return 'quente'
  if (['NOVO LEAD', 'NOVOS LEADS', 'LEAD NOVO'].includes(n)) return 'novo'
  if (['NUNCA RESPONDEU', 'NAO RESPONDEU MAIS', 'NAO TEM INTERESSE', 'COMPROU DO CONCORRENTE',
       'NAO FABRICAMOS', 'FORA DO ORCAMENTO', 'SO BASE DE PRECO', 'RESOLVIDO', 'RESOLVIDOS'].includes(n)) return 'morto'
  return 'outros'
}

async function carregar() {
  const cfg = await chrome.storage.local.get([
    'vendedor_nome', 'last_sync_at', 'last_count', 'last_total_contatos',
    'last_etiquetas', 'last_error', 'last_error_at',
    'mode_realtime', 'mode_polling_ms', 'wpp_version', 'last_status_at',
    'last_heartbeat_at', 'last_chats_total',
    'last_sem_etiqueta', 'last_total_chats',
    'bg_status', 'bg_status_at', 'bg_tabs_ok', 'bg_tabs_total',
  ])
  if (cfg.vendedor_nome) $vendedor.value = cfg.vendedor_nome

  // ===== Live indicator no header =====
  const sinceHeartbeat = cfg.last_heartbeat_at ? Date.now() - cfg.last_heartbeat_at : Infinity
  const sinceBgTick = cfg.bg_status_at ? Date.now() - cfg.bg_status_at : Infinity

  if (sinceHeartbeat < 40 * 1000) {
    // Heartbeat recente — aba ativa, sync direto
    $liveDot.className = 'dot live'
    $liveText.textContent = cfg.mode_realtime ? 'Real-time + sync 30s' : 'Sync 30s ativo'
  } else if (sinceBgTick < 60 * 1000 && cfg.bg_status === 'ok') {
    // Background SW rodou recente, sync OK
    $liveDot.className = 'dot live'
    $liveText.textContent = 'Background sync 30s'
  } else if (sinceBgTick < 60 * 1000 && cfg.bg_status === 'recarregando') {
    $liveDot.className = 'dot warn'
    $liveText.textContent = 'Recarregando aba do WA…'
  } else if (cfg.bg_status === 'sem_wa_aberto') {
    $liveDot.className = 'dot err'
    $liveText.textContent = 'Abre web.whatsapp.com'
  } else if (cfg.last_sync_at) {
    $liveDot.className = 'dot warn'
    $liveText.textContent = 'Aguardando próximo sync (30s)'
  } else {
    $liveDot.className = 'dot err'
    $liveText.textContent = 'Aguardando WhatsApp Web'
  }

  // ===== Stats =====
  const linhas = []
  linhas.push(`<div class="row"><span class="k">Última verificação</span><span class="v">${fmtAgo(cfg.last_heartbeat_at ?? cfg.last_sync_at)}</span></div>`)
  linhas.push(`<div class="row"><span class="k">Última mudança</span><span class="v">${fmtAgo(cfg.last_sync_at)}</span></div>`)
  if (cfg.last_count !== undefined) {
    linhas.push(`<div class="row"><span class="k">Etiquetas ativas</span><span class="v">${cfg.last_count}</span></div>`)
  }
  const totalChats = cfg.last_total_chats ?? cfg.last_chats_total
  if (totalChats) {
    linhas.push(`<div class="row"><span class="k">Chats varridos</span><span class="v">${totalChats}</span></div>`)
  }
  if (typeof cfg.last_sem_etiqueta === 'number') {
    const cls = cfg.last_sem_etiqueta > 20 ? 'warn' : (cfg.last_sem_etiqueta > 0 ? '' : 'ok')
    linhas.push(`<div class="row"><span class="k">📥 Sem etiqueta</span><span class="v ${cls}">${cfg.last_sem_etiqueta}</span></div>`)
  }
  if (cfg.last_error) {
    linhas.push(`<div class="row"><span class="k">Erro</span><span class="v err" title="${escapeHtml(cfg.last_error)}">${escapeHtml(cfg.last_error.slice(0, 30))}…</span></div>`)
  }
  $stats.innerHTML = linhas.join('')

  // ===== Lista de etiquetas =====
  if (Array.isArray(cfg.last_etiquetas) && cfg.last_etiquetas.length > 0) {
    const total = cfg.last_etiquetas.reduce((s, e) => s + (e.count || 0), 0)
    const items = cfg.last_etiquetas.map(e => {
      const cat = classify(e.name)
      return `<div class="it">
        <span class="nm"><span class="cdot ${cat}"></span>${escapeHtml(e.name)}</span>
        <span class="ct ${e.count === 0 ? 'zero' : ''}">${e.count}</span>
      </div>`
    }).join('')
    $list.innerHTML = `<div class="etlist">
      <div class="head"><span>Etiqueta</span><span>Contatos</span></div>
      ${items}
      <div class="total"><span class="k">Total</span><span class="v">${total}</span></div>
    </div>`
  } else {
    $list.innerHTML = `<div class="etlist"><div class="head" style="text-align:center; display:block; padding:18px;">Nenhuma etiqueta sincronizada ainda</div></div>`
  }
}

$vendedor.addEventListener('change', async () => {
  await chrome.storage.local.set({ vendedor_nome: $vendedor.value, enabled: true })
  carregar()
})

document.getElementById('openCrm').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('crm.html') })
})

$btn.addEventListener('click', async () => {
  if (!$vendedor.value) {
    $btn.textContent = 'Escolhe vendedor primeiro'
    setTimeout(() => $btn.textContent = 'Sincronizar agora', 1500)
    return
  }
  $btn.disabled = true
  $btn.textContent = 'Sincronizando…'
  try {
    // Pede pro service worker fazer sync agora
    await chrome.runtime.sendMessage({ type: 'BRANORTE_FORCE_SYNC' })
    setTimeout(carregar, 1500)
  } catch (e) {
    $btn.textContent = String(e).slice(0, 30)
  } finally {
    setTimeout(() => {
      $btn.disabled = false
      $btn.textContent = 'Sincronizar agora'
    }, 2000)
  }
})

carregar()
setInterval(carregar, 1000)
