// content.js — roda no contexto isolado da extensão.
// Faz 3 coisas:
//  1. Injeta wppconnect-wa.js + inject.js no contexto da página (pra acessar window.Store).
//  2. Escuta postMessages de inject.js com os labels lidos.
//  3. Envia pro backend (edge function Supabase) com o nome do vendedor configurado.

const VERSION = '0.3.1'
console.log('[Branorte WA Sync]', VERSION)

const CONFIG = {
  // Edge function que recebe os labels — vai ser preenchida depois do deploy
  endpoint: 'https://flwbeevtvjiouxdjmziv.supabase.co/functions/v1/wa-sync-labels',
  // Token compartilhado (validação simples no edge). Trocar quando publicar.
  shared_secret: 'branorte-wa-sync-2026',
  // Intervalo de sync automático (5 min)
  interval_ms: 5 * 60 * 1000,
}

// ---------- 1. Injetar scripts no contexto da página ----------
// IMPORTANTE: outras extensões (Wascript) também injetam wa-js. Pra evitar conflito,
// só injetamos nosso wa-js se NINGUÉM mais carregou ainda. Se Wascript ja carregou
// um window.WPP, usamos o dela.

function injectScript(file) {
  return new Promise((resolve, reject) => {
    const s = document.createElement('script')
    s.src = chrome.runtime.getURL(file)
    s.onload = () => { s.remove(); resolve() }
    s.onerror = reject
    ;(document.head || document.documentElement).appendChild(s)
  })
}

// Detector: aguarda até 20s pra ver se alguma outra extensão expõe window.WPP
// (Wascript pode demorar 10-15s pra carregar wa-js dela completamente)
function injetarDetectorWPP() {
  return new Promise((resolve) => {
    const s = document.createElement('script')
    s.textContent = `
      (function(){
        let avisou = false;
        function avisar(fonte) {
          if (avisou) return; avisou = true;
          window.postMessage({ type: 'BRANORTE_WPP_DETECTED', fonte }, '*');
        }
        if (window.WPP) { avisar('imediato'); return; }
        const inicio = Date.now();
        const it = setInterval(() => {
          if (window.WPP) { clearInterval(it); avisar('detectado'); }
          else if (Date.now() - inicio > 20000) { clearInterval(it); avisar('timeout'); }
        }, 300);
      })();
    `
    ;(document.head || document.documentElement).appendChild(s)
    s.remove()

    const onMsg = (ev) => {
      if (ev.source !== window || ev.data?.type !== 'BRANORTE_WPP_DETECTED') return
      window.removeEventListener('message', onMsg)
      resolve(ev.data.fonte)
    }
    window.addEventListener('message', onMsg)
    setTimeout(() => { window.removeEventListener('message', onMsg); resolve('timeout-fallback') }, 22000)
  })
}

;(async () => {
  try {
    const fonte = await injetarDetectorWPP()
    if (fonte === 'imediato' || fonte === 'detectado') {
      console.log('[Branorte WA Sync] WPP já existe (', fonte, ') — reusando, sem injetar wa-js')
      // Outra extensão (provavelmente Wascript) já carregou wa-js
      // Vamos só carregar inject.js que usa window.WPP existente
      await injectScript('inject.js')
    } else {
      console.log('[Branorte WA Sync] WPP não detectado — injetando nosso wa-js')
      await injectScript('wppconnect-wa.js')
      await injectScript('inject.js')
    }
    console.log('[Branorte WA Sync] scripts injected')
  } catch (e) {
    console.error('[Branorte WA Sync] inject failed', e)
  }
})()

// ---------- 2. Escuta resposta do inject.js via postMessage ----------

window.addEventListener('message', async (ev) => {
  if (ev.source !== window || !ev.data) return
  const { type, payload } = ev.data

  if (type === 'BRANORTE_WA_STATUS') {
    await chrome.storage.local.set({
      mode_realtime: !!ev.data.realtime,
      mode_polling_ms: ev.data.polling_ms,
      wpp_version: ev.data.wpp_version,
      last_status_at: Date.now(),
    })
    console.log('[Branorte WA Sync] status:', ev.data.realtime ? 'REAL-TIME + polling' : 'POLLING ONLY')
    return
  }

  if (type === 'BRANORTE_WA_HEARTBEAT') {
    // Heartbeat: extensão viva, varreu chats, verificou — pode ou não ter enviado POST
    // Atualiza também info de modo (caso BRANORTE_WA_STATUS tenha sido perdido)
    await chrome.storage.local.set({
      last_heartbeat_at: Date.now(),
      last_heartbeat_changed: ev.data.changed,
      last_chats_total: ev.data.chats_total,
      // Info de modo via heartbeat (sempre atualizado)
      mode_realtime: !!ev.data.realtime,
      mode_polling_ms: ev.data.polling_ms,
      wpp_version: ev.data.wpp_version,
      last_status_at: Date.now(),
    })
    return
  }

  if (type !== 'BRANORTE_WA_LABELS') return

  console.log('[Branorte WA Sync] labels recebidos:', payload?.length)

  const cfg = await chrome.storage.local.get(['vendedor_nome', 'enabled'])
  if (!cfg.vendedor_nome) {
    console.warn('[Branorte WA Sync] vendedor_nome não configurado — abre o popup pra setar')
    return
  }
  if (cfg.enabled === false) return

  await enviarPraBackend(cfg.vendedor_nome, payload)
})

// ---------- 3. Envia pro backend ----------

async function enviarPraBackend(vendedor_nome, etiquetas) {
  try {
    const r = await fetch(CONFIG.endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${CONFIG.shared_secret}`,
      },
      body: JSON.stringify({
        vendedor_nome: vendedor_nome.toUpperCase(),
        etiquetas,
        client_version: VERSION,
        ts: new Date().toISOString(),
      }),
    })

    const txt = await r.text()
    if (!r.ok) {
      console.error('[Branorte WA Sync] backend rejected', r.status, txt)
      await chrome.storage.local.set({ last_error: txt, last_error_at: Date.now() })
      return
    }

    console.log('[Branorte WA Sync] enviado', r.status, txt.slice(0, 100))
    // Salva detalhe pra popup mostrar
    const sortedDetail = [...etiquetas]
      .map(e => ({ name: e.name, count: e.count || 0 }))
      .sort((a, b) => b.count - a.count)
    await chrome.storage.local.set({
      last_sync_at: Date.now(),
      last_count: etiquetas.length,
      last_total_contatos: etiquetas.reduce((s, e) => s + (e.count || 0), 0),
      last_etiquetas: sortedDetail,
      last_error: null,
    })
  } catch (e) {
    console.error('[Branorte WA Sync] fetch failed', e)
    await chrome.storage.local.set({ last_error: String(e), last_error_at: Date.now() })
  }
}

// ---------- 4. Comunicação com popup ----------

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === 'BRANORTE_SYNC_NOW' || msg?.type === 'BRANORTE_BG_SYNC') {
    // BG_SYNC vem do service worker (chrome.alarms a cada 30s, mesmo aba em background)
    console.log('[Branorte WA Sync]', msg.type)
    window.postMessage({ type: 'BRANORTE_TRIGGER_READ' }, '*')
    sendResponse({ ok: true })
    return true
  }
  if (msg?.type === 'BRANORTE_PING') {
    sendResponse({ ok: true, version: VERSION, url: location.href })
    return true
  }
  return false
})
